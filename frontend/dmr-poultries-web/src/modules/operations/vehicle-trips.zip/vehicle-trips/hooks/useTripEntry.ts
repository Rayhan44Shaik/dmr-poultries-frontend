import { useState } from "react";
import type { Trip, ShopDelivery } from "../types/trip";
import { tripService } from "../services/tripService";

const getNextTripNo = () => {
  const count = tripService.getAll().length + 1;
  return `TRP-${String(count).padStart(5, "0")}`;
};

const createEmptyTrip = (): Trip => ({
  id: Date.now(),

  tripNo: getNextTripNo(),

  tripDate: new Date().toISOString().substring(0, 10),

  vehicleId: 0,
  vehicleNo: "",

  driverId: 0,
  driverName: "",

  supervisorId: 0,
  supervisorName: "",

  sourceFarmId: 0,
  sourceFarm: "",

  openingMeter: 0,
  closingMeter: 0,
  totalKm: 0,

  fuel: 0,
  expense: 0,

  remarks: "",

  totalShops: 0,
  totalBirds: 0,
  totalWeight: 0,
  totalMortality: 0,

  lastShop: "",

  status: "Pending",

  deliveries: []
});

export function useTripEntry() {

  const [trip, setTrip] = useState<Trip>(createEmptyTrip());

  const updateField = (
    field: keyof Trip,
    value: any
  ) => {

    setTrip(prev => ({
      ...prev,
      [field]: value
    }));

  };

  const updateDeliveries = (
    rows: ShopDelivery[]
  ) => {

    const updatedTrip: Trip = {

      ...trip,

      deliveries: rows,

      totalShops: rows.length,

      totalBirds: rows.reduce(
        (a, b) => a + Number(b.birds || 0),
        0
      ),

      totalWeight: rows.reduce(
        (a, b) => a + Number(b.weight || 0),
        0
      ),

      totalMortality: rows.reduce(
        (a, b) => a + Number(b.mortality || 0),
        0
      ),

      lastShop:
        rows.length > 0
          ? rows[rows.length - 1].shopName
          : ""

    };

    setTrip(updatedTrip);

    return updatedTrip;

  };

  const clearTrip = () => {

    setTrip(createEmptyTrip());

  };

  const validate = (
    rows: ShopDelivery[]
  ) => {

    if (!trip.vehicleId) {
      alert("Please select Vehicle");
      return false;
    }

    if (!trip.driverId) {
      alert("Please select Driver");
      return false;
    }

    if (!trip.supervisorId) {
      alert("Please select Supervisor");
      return false;
    }

    if (!trip.sourceFarmId) {
      alert("Please select Source Farm");
      return false;
    }

    if (rows.length === 0) {
      alert("Please add at least one Shop");
      return false;
    }

    for (const row of rows) {

      if (!row.shopId) {
        alert("Please select Shop");
        return false;
      }

      if (!row.birdTypeId) {
        alert("Please select Bird Type");
        return false;
      }

      if (row.birds <= 0) {
        alert("Enter No. of Birds");
        return false;
      }

      if (row.weight <= 0) {
        alert("Enter Weight");
        return false;
      }

    }

    return true;

  };

  const saveTrip = (
    rows: ShopDelivery[]
  ) => {

    if (!validate(rows))
      return;

    const finalTrip: Trip = {

      ...trip,

      deliveries: rows,

      totalShops: rows.length,

      totalBirds: rows.reduce(
        (a, b) => a + Number(b.birds),
        0
      ),

      totalWeight: rows.reduce(
        (a, b) => a + Number(b.weight),
        0
      ),

      totalMortality: rows.reduce(
        (a, b) => a + Number(b.mortality),
        0
      ),

      lastShop:
        rows.length > 0
          ? rows[rows.length - 1].shopName
          : "",

      totalKm:
        trip.closingMeter -
        trip.openingMeter

    };

    tripService.create(finalTrip);

    alert("Trip Saved Successfully");

    clearTrip();

  };

  const saveAndNew = (
    rows: ShopDelivery[]
  ) => {

    saveTrip(rows);

  };

  return {

    trip,

    setTrip,

    updateField,

    updateDeliveries,

    saveTrip,

    saveAndNew,

    clearTrip

  };

}