import { useMemo, useState } from "react";
import type { Trip } from "../types/trip";
import { tripService } from "../services/tripService";

export default function useTrips() {

  const [search, setSearch] = useState("");

  const [status, setStatus] = useState("All");

  const [vehicle, setVehicle] = useState("All");

  const [fromDate, setFromDate] = useState("");

  const [toDate, setToDate] = useState("");

  const [driver, setDriver] = useState("All");

  const [supervisor, setSupervisor] = useState("All");

  const [farm, setFarm] = useState("All");

  const [trips, setTrips] = useState<Trip[]>(
    tripService.getAll()
  );

  const refreshTrips = () => {

    setTrips(tripService.getAll());

  };

  const filteredTrips = useMemo(() => {

    return trips.filter(trip => {

      const text = search.toLowerCase();

      const searchMatched =
        text === "" ||

        trip.tripNo.toLowerCase().includes(text) ||

        trip.vehicleNo.toLowerCase().includes(text) ||

        trip.driverName.toLowerCase().includes(text) ||

        trip.supervisorName.toLowerCase().includes(text) ||

        trip.sourceFarm.toLowerCase().includes(text);

      const statusMatched =
        status === "All" ||
        trip.status === status;

      const vehicleMatched =
        vehicle === "All" ||
        trip.vehicleNo === vehicle;

      const driverMatched =
        driver === "All" ||
        trip.driverName === driver;

      const supervisorMatched =
        supervisor === "All" ||
        trip.supervisorName === supervisor;

      const farmMatched =
        farm === "All" ||
        trip.sourceFarm === farm;

      const fromMatched =
        !fromDate ||
        trip.tripDate >= fromDate;

      const toMatched =
        !toDate ||
        trip.tripDate <= toDate;

      return (

        searchMatched &&

        statusMatched &&

        vehicleMatched &&

        driverMatched &&

        supervisorMatched &&

        farmMatched &&

        fromMatched &&

        toMatched

      );

    });

  }, [

    trips,

    search,

    status,

    vehicle,

    driver,

    supervisor,

    farm,

    fromDate,

    toDate

  ]);

  const totalTrips = filteredTrips.length;

  const totalShops = filteredTrips.reduce(
    (sum, trip) => sum + trip.totalShops,
    0
  );

  const totalBirds = filteredTrips.reduce(
    (sum, trip) => sum + trip.totalBirds,
    0
  );

  const totalWeight = filteredTrips.reduce(
    (sum, trip) => sum + trip.totalWeight,
    0
  );

  const totalMortality = filteredTrips.reduce(
    (sum, trip) => sum + trip.totalMortality,
    0
  );

  const totalExpenses = filteredTrips.reduce(
    (sum, trip) => sum + trip.expense,
    0
  );

  return {

    trips: filteredTrips,

    refreshTrips,

    totalTrips,

    totalShops,

    totalBirds,

    totalWeight,

    totalMortality,

    totalExpenses,

    search,
    setSearch,

    status,
    setStatus,

    vehicle,
    setVehicle,

    driver,
    setDriver,

    supervisor,
    setSupervisor,

    farm,
    setFarm,

    fromDate,
    setFromDate,

    toDate,
    setToDate

  };

}