export interface ShopDelivery {
  id: number;

  boxNo: number;

  shopId: number;
  shopName: string;

  birdTypeId: number;
  birdType: string;

  birds: number;

  weight: number;

  mortality: number;

  remarks: string;
}

export interface Trip {
  id: number;

  tripNo: string;

  tripDate: string;

  vehicleId: number;
  vehicleNo: string;

  driverId: number;
  driverName: string;

  supervisorId: number;
  supervisorName: string;

  sourceFarmId: number;
  sourceFarm: string;

  openingMeter: number;
  closingMeter: number;
  totalKm: number;

  fuel: number;
  expense: number;

  remarks: string;

  totalShops: number;
  totalBirds: number;
  totalWeight: number;
  totalMortality: number;

  // Last shop delivered (for Trip List page)
  lastShop?: string;

  status: "Pending" | "In Progress" | "Completed";

  deliveries: ShopDelivery[];
}