import DashboardLayout from "../../../../layouts/DashboardLayout/DashboardLayout";

import TripFilters from "../components/TripFilters";

import TripKPICards from "../components/TripKPICards";

import TripListTable from "../components/TripListTable";

import useTrips from "../hooks/useTrips";

export default function TripListPage(){

const{

trips,

search,

setSearch,

status,

setStatus,

vehicle,

setVehicle

}=useTrips();

const totalTrips=trips.length;

const totalBirds=

trips.reduce(

(a,b)=>a+b.totalBirds,

0

);

const totalWeight=

trips.reduce(

(a,b)=>a+b.totalWeight,

0

);

const totalMortality=

trips.reduce(

(a,b)=>a+b.totalMortality,

0

);

return(

<DashboardLayout>

<div className="space-y-6">

<div>

<h1 className="text-4xl font-bold">

Vehicle Trip List

</h1>

<p className="text-slate-500">

Daily Vehicle Trips

</p>

</div>

<TripKPICards

totalTrips={totalTrips}

totalBirds={totalBirds}

totalWeight={totalWeight}

totalMortality={totalMortality}

/>

<TripFilters

search={search}

status={status}

vehicle={vehicle}

setSearch={setSearch}

setStatus={setStatus}

setVehicle={setVehicle}

/>

<TripListTable

trips={trips}

/>

</div>

</DashboardLayout>

);

}