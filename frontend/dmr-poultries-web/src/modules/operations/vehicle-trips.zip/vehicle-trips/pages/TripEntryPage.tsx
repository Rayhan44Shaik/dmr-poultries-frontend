import { useState } from "react";

import { Truck } from "lucide-react";

import DashboardLayout from "../../../../layouts/DashboardLayout/DashboardLayout";

import TripInformation from "../components/TripInformation";
import ShopDeliveryTable from "../components/ShopDeliveryTable";
import TripTotals from "../components/TripTotals";
import TripFooter from "../components/TripFooter";
import TripListTable from "../components/TripListTable";

import { useTripEntry } from "../hooks/useTripEntry";
import useTrips from "../hooks/useTrips";

import { useVehicles } from "../../../masters/vehicles/hooks/useVehicles";
import { useEmployees } from "../../../masters/employees/hooks/useEmployees";
import { useFarms } from "../../../masters/farms/hooks/useFarms";
import { useShops } from "../../../masters/shops/hooks/useShops";
import { useBirdTypes } from "../../../masters/bird-types/hooks/useBirdTypes";

import type { ShopDelivery } from "../types/trip";

export default function TripEntryPage() {

 const { vehicles } = useVehicles();

const { employees } = useEmployees();

const { farms } = useFarms();

const { shops } = useShops();

const { birdTypes } = useBirdTypes();

const {
  trips,
  refreshTrips,
} = useTrips();

const {
  trip,
  setTrip,
  updateField,
  saveTrip,
  saveAndNew,
  clearTrip,
  updateDeliveries,
} = useTripEntry();

const drivers = employees.filter(
  (x: any) => x.department === "Driver"
);

const supervisors = employees.filter(
  (x: any) => x.department === "Supervisor"
);

  const [rows,setRows]=

    useState<ShopDelivery[]>([]);

const save = () => {

  updateDeliveries(rows);

  saveTrip();

  refreshTrips();

};

const saveNew = () => {

  updateDeliveries(rows);

  saveAndNew();

  refreshTrips();

  setRows([]);

};

  return(

    <DashboardLayout>

      <div className="space-y-8">

        {/* Page Header */}

        <div className="bg-white rounded-2xl border border-slate-200 shadow-sm px-8 py-7">

          <div className="flex items-center gap-4">

            <div className="h-16 w-16 rounded-2xl bg-green-100 flex items-center justify-center">

              <Truck

                size={34}

                className="text-green-700"

              />

            </div>

            <div>

              <h1 className="text-4xl font-bold text-slate-800">

                Vehicle Trip Entry

              </h1>

              <p className="text-slate-500 mt-2">

                Enter all shop deliveries for a vehicle in a single trip

              </p>

            </div>

          </div>

        </div>

        {/* Trip Information */}

        <TripInformation

          trip={trip}

          updateField={updateField}

          vehicles={vehicles}

          drivers={drivers}

          supervisors={supervisors}

          farms={farms}

        />

        {/* Shop Delivery */}

        <ShopDeliveryTable

          rows={rows}

          setRows={setRows}

          shops={shops}

          birdTypes={birdTypes}

        />

        {/* KPI Cards */}

        <TripTotals

          rows={rows}

        />

        {/* Recent Trip List */}

        <TripListTable

          trips={trips}

        />

        {/* Footer */}

        <TripFooter

          onClear={()=>{

            clearTrip();

            setRows([]);

          }}

          onSave={save}

          onSaveNew={saveNew}

        />

      </div>

    </DashboardLayout>

  );

}