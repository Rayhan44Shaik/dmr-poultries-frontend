import {
  Store,
  Bird,
  Scale,
  HeartPulse
} from "lucide-react";

interface Props {

  totalTrips: number;

  totalBirds: number;

  totalWeight: number;

  totalMortality: number;

}

export default function TripKPICards({

  totalTrips,

  totalBirds,

  totalWeight,

  totalMortality

}: Props) {

  const cards = [

    {

      title: "Total Shops",

      value: totalTrips,

      icon: <Store size={28} />,

      bg: "bg-blue-50",

      border: "border-blue-200",

      iconBg: "bg-blue-100",

      text: "text-blue-700"

    },

    {

      title: "Total Birds",

      value: totalBirds.toLocaleString(),

      icon: <Bird size={28} />,

      bg: "bg-green-50",

      border: "border-green-200",

      iconBg: "bg-green-100",

      text: "text-green-700"

    },

    {

      title: "Total Weight (No. of Kg's)",

      value: totalWeight.toFixed(2),

      icon: <Scale size={28} />,

      bg: "bg-orange-50",

      border: "border-orange-200",

      iconBg: "bg-orange-100",

      text: "text-orange-600"

    },

    {

      title: "Mortality",

      value: totalMortality,

      icon: <HeartPulse size={28} />,

      bg: "bg-emerald-50",

      border: "border-emerald-200",

      iconBg: "bg-emerald-100",

      text: "text-emerald-700"

    }

  ];

  return (

    <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-4 gap-5">

      {

        cards.map((card) => (

          <div

            key={card.title}

            className={`${card.bg} ${card.border} border rounded-2xl shadow-sm p-5 flex items-center justify-between hover:shadow-lg transition-all`}

          >

            <div>

              <p className="text-sm font-semibold text-slate-600">

                {card.title}

              </p>

              <h2

                className={`mt-2 text-3xl font-bold ${card.text}`}

              >

                {card.value}

              </h2>

            </div>

            <div

              className={`${card.iconBg} h-16 w-16 rounded-2xl flex items-center justify-center ${card.text}`}

            >

              {card.icon}

            </div>

          </div>

        ))

      }

    </div>

  );

}