import {
  Eye,
  Pencil,
  RefreshCw,
  History,
  Heart
} from "lucide-react";

import type { Trip } from "../types/trip";

import TripStatusBadge from "./TripStatusBadge";

interface Props {
  trips: Trip[];
}

export default function TripListTable({

  trips

}: Props) {

  const recentTrips = trips.slice(-5).reverse();

  return (

    <div className="bg-white rounded-2xl border border-slate-200 shadow-sm overflow-hidden mt-8">

      {/* Header */}

      <div className="flex items-center justify-between px-6 py-5 border-b">

        <div className="flex items-center gap-3">

          <div className="h-12 w-12 rounded-xl bg-blue-100 flex items-center justify-center">

            <History
              className="w-6 h-6 text-blue-700"
            />

          </div>

          <div>

            <h2 className="text-2xl font-bold text-slate-800">

              Recent Trip List

            </h2>

            <p className="text-sm text-slate-500">

              Last 5 recently entered trips

            </p>

          </div>

        </div>

        <button

          className="h-11 w-11 rounded-xl border bg-white hover:bg-slate-100 flex items-center justify-center"

        >

          <RefreshCw
            size={20}
            className="text-slate-700"
          />

        </button>

      </div>

      <div className="overflow-x-auto">

        <table className="min-w-full text-sm">

          <thead className="bg-slate-50 border-b">

            <tr className="text-slate-700">

              <th className="px-4 py-4 text-left">

                Trip No

              </th>

              <th className="px-4 py-4 text-left">

                Date

              </th>

              <th className="px-4 py-4 text-left">

                Vehicle

              </th>

              <th className="px-4 py-4 text-left">

                Driver

              </th>

              <th className="px-4 py-4 text-left">

                Supervisor

              </th>

              <th className="px-4 py-4 text-left">

                Source Farm

              </th>

              <th className="px-4 py-4 text-center">

                Shops

              </th>

              <th className="px-4 py-4 text-center">

                Birds

              </th>

              <th className="px-4 py-4 text-center">

                Weight (KG)

              </th>

              <th className="px-4 py-4 text-center">

                <div className="flex justify-center items-center gap-2">

                  <Heart
                    size={15}
                    className="fill-red-500 text-red-500"
                  />

                  Mortality

                </div>

              </th>

              <th className="px-4 py-4 text-center">

                Status

              </th>

              <th className="px-4 py-4 text-center">

                View

              </th>

              <th className="px-4 py-4 text-center">

                Edit

              </th>

            </tr>

          </thead>

          <tbody>
                        {

              recentTrips.length === 0 ? (

                <tr>

                  <td
                    colSpan={13}
                    className="py-12 text-center text-slate-400 text-base"
                  >

                    No recent trips available.

                  </td>

                </tr>

              ) : (

                recentTrips.map((trip) => (

                  <tr
                    key={trip.id}
                    className="border-t hover:bg-slate-50 transition-colors"
                  >

                    {/* Trip No */}

                    <td className="px-4 py-4 font-semibold text-green-700">

                      {trip.tripNo}

                    </td>

                    {/* Date */}

                    <td className="px-4 py-4">

                      {trip.tripDate}

                    </td>

                    {/* Vehicle */}

                    <td className="px-4 py-4">

                      {trip.vehicleNo}

                    </td>

                    {/* Driver */}

                    <td className="px-4 py-4">

                      {trip.driverName}

                    </td>

                    {/* Supervisor */}

                    <td className="px-4 py-4">

                      {trip.supervisorName}

                    </td>

                    {/* Farm */}

                    <td className="px-4 py-4">

                      {trip.sourceFarm}

                    </td>

                    {/* Shops */}

                    <td className="px-4 py-4 text-center font-semibold">

                      {trip.totalShops}

                    </td>

                    {/* Birds */}

                    <td className="px-4 py-4 text-center font-semibold text-blue-700">

                      {trip.totalBirds.toLocaleString()}

                    </td>

                    {/* Weight */}

                    <td className="px-4 py-4 text-center font-semibold text-orange-600">

                      {trip.totalWeight.toFixed(2)}

                    </td>

                    {/* Mortality */}

                    <td className="px-4 py-4 text-center font-semibold text-red-600">

                      {trip.totalMortality}

                    </td>

                    {/* Status */}

                    <td className="px-4 py-4 text-center">

                      <TripStatusBadge

                        status={trip.status}

                      />

                    </td>

                    {/* View */}

                    <td className="text-center">

                      <button

                        className="h-9 w-9 rounded-full bg-blue-50 hover:bg-blue-100 flex items-center justify-center mx-auto transition"

                      >

                        <Eye

                          size={18}

                          className="text-blue-700"

                        />

                      </button>

                    </td>

                    {/* Edit */}

                    <td className="text-center">

                      <button

                        className="h-9 w-9 rounded-full bg-green-50 hover:bg-green-100 flex items-center justify-center mx-auto transition"

                      >

                        <Pencil

                          size={18}

                          className="text-green-700"

                        />

                      </button>

                    </td>

                  </tr>

                ))

              )

            }

          </tbody>

        </table>

      </div>

    </div>

  );

}