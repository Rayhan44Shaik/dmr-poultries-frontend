import {
  RotateCcw,
  Save,
  SaveAll
} from "lucide-react";

interface Props {

  onClear: () => void;

  onSave: () => void;

  onSaveNew: () => void;

}

export default function TripFooter({

  onClear,

  onSave,

  onSaveNew,

}: Props) {

  return (

    <div className="bg-white border border-slate-200 rounded-2xl shadow-sm mt-8 p-6">

      <div className="flex justify-center items-center gap-5 flex-wrap">

        {/* Clear */}

        <button

          type="button"

          onClick={onClear}

          className="h-12 min-w-[140px] rounded-xl border border-slate-300 bg-white hover:bg-slate-100 text-slate-700 font-semibold flex items-center justify-center gap-2 transition-all"

        >

          <RotateCcw size={18} />

          Clear

        </button>

        {/* Save */}

        <button

          type="button"

          onClick={onSave}

          className="h-12 min-w-[170px] rounded-xl bg-green-700 hover:bg-green-800 text-white font-semibold flex items-center justify-center gap-2 shadow-md transition-all"

        >

          <Save size={18} />

          Save Trip

        </button>

        {/* Save & New */}

        <button

          type="button"

          onClick={onSaveNew}

          className="h-12 min-w-[200px] rounded-xl bg-blue-700 hover:bg-blue-800 text-white font-semibold flex items-center justify-center gap-2 shadow-md transition-all"

        >

          <SaveAll size={18} />

          Save & New Trip

        </button>

      </div>

    </div>

  );

}