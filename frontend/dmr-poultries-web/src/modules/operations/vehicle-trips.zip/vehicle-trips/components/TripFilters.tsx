interface Props{

search:string;

status:string;

vehicle:string;

setSearch:(v:string)=>void;

setStatus:(v:string)=>void;

setVehicle:(v:string)=>void;

}

export default function TripFilters({

search,

status,

vehicle,

setSearch,

setStatus,

setVehicle

}:Props){

return(

<div className="bg-white border rounded-2xl shadow-sm p-6">

<div className="grid grid-cols-1 md:grid-cols-4 gap-4">

<input

value={search}

placeholder="Search Trip / Driver / Vehicle"

onChange={(e)=>setSearch(e.target.value)}

className="border rounded-xl px-4 py-3"

/>

<select

value={status}

onChange={(e)=>setStatus(e.target.value)}

className="border rounded-xl px-4 py-3"

>

<option>All</option>

<option>Pending</option>

<option>Completed</option>

</select>

<input

value={vehicle}

placeholder="Vehicle"

onChange={(e)=>setVehicle(e.target.value)}

className="border rounded-xl px-4 py-3"

/>

<button

className="bg-green-700 rounded-xl text-white"

>

Refresh

</button>

</div>

</div>

);

}