import { FileText } from "lucide-react";
import type { Trip } from "../types/trip";

interface Props {
  trip: Trip;

  setTrip: React.Dispatch<React.SetStateAction<Trip>>;

  updateField: (
    field: keyof Trip,
    value: any
  ) => void;

  vehicles: any[];
  drivers: any[];
  supervisors: any[];
  farms: any[];
}

export default function TripInformation({
  trip,
  setTrip,
  updateField,
  vehicles,
  drivers,
  supervisors,
  farms,
}: Props) {
  return (
    <div className="bg-white rounded-2xl border border-slate-200 shadow-sm overflow-hidden">

      {/* Header */}

      <div className="flex items-center gap-3 px-6 py-5 border-b bg-white">

        <div className="h-11 w-11 rounded-xl bg-slate-100 flex items-center justify-center">
          <FileText className="w-6 h-6 text-slate-700" />
        </div>

        <div>
          <h2 className="text-2xl font-bold text-slate-800">
            Trip Information
          </h2>

          <p className="text-sm text-slate-500">
            Enter common trip details
          </p>
        </div>

      </div>

      <div className="p-6">

        <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-5 gap-6">

          {/* Trip No */}

          <div>

            <label className="text-sm font-semibold">
              Trip No <span className="text-red-500">*</span>
            </label>

            <input
              value={trip.tripNo}
              readOnly
              className="mt-2 w-full rounded-xl border bg-slate-100 px-4 py-3 font-semibold cursor-not-allowed"
            />

          </div>

          {/* Trip Date */}

          <div>

            <label className="text-sm font-semibold">
              Trip Date <span className="text-red-500">*</span>
            </label>

            <input
              type="date"
              value={trip.tripDate}
              onChange={(e) =>
                updateField("tripDate", e.target.value)
              }
              className="mt-2 w-full rounded-xl border px-4 py-3"
            />

          </div>

          {/* Vehicle */}

          <div>

            <label className="text-sm font-semibold">
              Vehicle <span className="text-red-500">*</span>
            </label>

            <select
              value={trip.vehicleId || ""}
              className="mt-2 w-full rounded-xl border px-4 py-3"
              onChange={(e) => {

                const vehicle = vehicles.find(
                  (v: any) =>
                    v.id === Number(e.target.value)
                );

                if (!vehicle) return;

                setTrip(prev => ({
                  ...prev,

                  vehicleId: vehicle.id,

                  vehicleNo: vehicle.vehicleNumber
                }));

              }}
            >

              <option value="">
                Select Vehicle
              </option>

              {vehicles.map((v: any) => (

                <option
                  key={v.id}
                  value={v.id}
                >
                  {v.vehicleNumber}
                </option>

              ))}

            </select>

          </div>

          {/* Driver */}

          <div>

            <label className="text-sm font-semibold">
              Driver <span className="text-red-500">*</span>
            </label>

            <select
              value={trip.driverId || ""}
              className="mt-2 w-full rounded-xl border px-4 py-3"
              onChange={(e) => {

                const driver = drivers.find(
                  (d: any) =>
                    d.id === Number(e.target.value)
                );

                if (!driver) return;

                setTrip(prev => ({
                  ...prev,

                  driverId: driver.id,

                  driverName: driver.employeeName
                }));

              }}
            >

              <option value="">
                Select Driver
              </option>

              {drivers.map((d: any) => (

                <option
                  key={d.id}
                  value={d.id}
                >
                  {d.employeeName}
                </option>

              ))}

            </select>

          </div>

          {/* Supervisor */}

          <div>

            <label className="text-sm font-semibold">
              Supervisor <span className="text-red-500">*</span>
            </label>

            <select
              value={trip.supervisorId || ""}
              className="mt-2 w-full rounded-xl border px-4 py-3"
              onChange={(e) => {

                const supervisor = supervisors.find(
                  (s: any) =>
                    s.id === Number(e.target.value)
                );

                if (!supervisor) return;

                setTrip(prev => ({
                  ...prev,

                  supervisorId: supervisor.id,

                  supervisorName: supervisor.employeeName
                }));

              }}
            >

              <option value="">
                Select Supervisor
              </option>

              {supervisors.map((s: any) => (

                <option
                  key={s.id}
                  value={s.id}
                >
                  {s.employeeName}
                </option>

              ))}

            </select>

          </div>

          {/* Source Farm */}

          <div>

            <label className="text-sm font-semibold">
              Source Farm <span className="text-red-500">*</span>
            </label>

            <select
              value={trip.sourceFarmId || ""}
              className="mt-2 w-full rounded-xl border px-4 py-3"
              onChange={(e) => {

                const farm = farms.find(
                  (f: any) =>
                    f.id === Number(e.target.value)
                );

                if (!farm) return;

                setTrip(prev => ({
                  ...prev,

                  sourceFarmId: farm.id,

                  sourceFarm: farm.farmName
                }));

              }}
            >

              <option value="">
                Select Farm
              </option>

              {farms.map((f: any) => (

                <option
                  key={f.id}
                  value={f.id}
                >
                  {f.farmName}
                </option>

              ))}

            </select>

          </div>

          {/* Opening KM */}

          <div>

            <label className="text-sm font-semibold">
              Opening KM
            </label>

            <input
              type="number"
              value={trip.openingMeter}
              className="mt-2 w-full rounded-xl border px-4 py-3"
              onChange={(e) => {

                const opening = Number(e.target.value);

                setTrip(prev => ({
                  ...prev,
                  openingMeter: opening,
                  totalKm: prev.closingMeter - opening
                }));

              }}
            />

          </div>

          {/* Closing KM */}

          <div>

            <label className="text-sm font-semibold">
              Closing KM
            </label>

            <input
              type="number"
              value={trip.closingMeter}
              className="mt-2 w-full rounded-xl border px-4 py-3"
              onChange={(e) => {

                const closing = Number(e.target.value);

                setTrip(prev => ({
                  ...prev,
                  closingMeter: closing,
                  totalKm: closing - prev.openingMeter
                }));

              }}
            />

          </div>

          {/* Total KM */}

          <div>

            <label className="text-sm font-semibold">
              Total KM
            </label>

            <input
              value={trip.totalKm}
              readOnly
              className="mt-2 w-full rounded-xl border bg-slate-100 px-4 py-3 font-semibold"
            />

          </div>

          {/* Fuel */}

          <div>

            <label className="text-sm font-semibold">
              Fuel (Ltrs)
            </label>

            <input
              type="number"
              value={trip.fuel}
              onChange={(e) =>
                updateField("fuel", Number(e.target.value))
              }
              className="mt-2 w-full rounded-xl border px-4 py-3"
            />

          </div>

          {/* Expense */}

          <div>

            <label className="text-sm font-semibold">
              Total Expense
            </label>

            <input
              type="number"
              value={trip.expense}
              onChange={(e) =>
                updateField("expense", Number(e.target.value))
              }
              className="mt-2 w-full rounded-xl border px-4 py-3"
            />

          </div>

          {/* Remarks */}

          <div className="xl:col-span-4">

            <label className="text-sm font-semibold">
              Remarks
            </label>

            <input
              value={trip.remarks}
              placeholder="Enter remarks (optional)"
              onChange={(e) =>
                updateField("remarks", e.target.value)
              }
              className="mt-2 w-full rounded-xl border px-4 py-3"
            />

          </div>

        </div>

      </div>

    </div>
  );
}