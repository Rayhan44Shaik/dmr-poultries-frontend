import type {
  Trip,
  ShopDelivery
} from "../types/trip";

export const tripFormService = {

  calculateTotals(rows: ShopDelivery[]) {

    return {

      totalShops: rows.length,

      totalBirds: rows.reduce(
        (sum, row) => sum + Number(row.birds || 0),
        0
      ),

      totalWeight: rows.reduce(
        (sum, row) => sum + Number(row.weight || 0),
        0
      ),

      totalMortality: rows.reduce(
        (sum, row) => sum + Number(row.mortality || 0),
        0
      )

    };

  },

  calculateKM(
    openingMeter: number,
    closingMeter: number
  ) {

    if (closingMeter <= openingMeter)
      return 0;

    return closingMeter - openingMeter;

  },

  validateTrip(trip: Trip) {

    const errors: string[] = [];

    if (!trip.tripNo)
      errors.push("Trip No is required.");

    if (!trip.tripDate)
      errors.push("Trip Date is required.");

    if (!trip.vehicleId)
      errors.push("Vehicle is required.");

    if (!trip.driverId)
      errors.push("Driver is required.");

    if (!trip.supervisorId)
      errors.push("Supervisor is required.");

    if (!trip.sourceFarmId)
      errors.push("Source Farm is required.");

    if (trip.deliveries.length === 0)
      errors.push("Please add at least one shop.");

    return {

      valid: errors.length === 0,

      errors

    };

  },

  generateTripNo() {

    const date = new Date();

    const yy = date.getFullYear();

    const mm = String(
      date.getMonth() + 1
    ).padStart(2, "0");

    const dd = String(
      date.getDate()
    ).padStart(2, "0");

    const random = Math.floor(
      100 + Math.random() * 900
    );

    return `TRP-${yy}${mm}${dd}-${random}`;

  }

};