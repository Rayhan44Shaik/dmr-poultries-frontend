import type { Trip } from "../types/trip";

const STORAGE_KEY = "vehicleTrips";

const getTrips = (): Trip[] => {
  const data = localStorage.getItem(STORAGE_KEY);

  if (!data) return [];

  return JSON.parse(data);
};

const saveTrips = (trips: Trip[]) => {
  localStorage.setItem(
    STORAGE_KEY,
    JSON.stringify(trips)
  );
};

export const tripService = {

  getAll(): Trip[] {

    return getTrips()
      .sort(
        (a, b) =>
          b.id - a.id
      );

  },

  getRecent(limit = 5): Trip[] {

    return getTrips()
      .sort(
        (a, b) =>
          b.id - a.id
      )
      .slice(0, limit);

  },

  getById(id: number): Trip | undefined {

    return getTrips().find(
      x => x.id === id
    );

  },

  create(trip: Trip) {

    const trips = getTrips();

    trips.push(trip);

    saveTrips(trips);

  },

  update(updatedTrip: Trip) {

    const trips = getTrips();

    const index = trips.findIndex(
      x => x.id === updatedTrip.id
    );

    if (index >= 0) {

      trips[index] = updatedTrip;

      saveTrips(trips);

    }

  },

  remove(id: number) {

    const trips = getTrips().filter(
      x => x.id !== id
    );

    saveTrips(trips);

  },

  clear() {

    localStorage.removeItem(STORAGE_KEY);

  }

};