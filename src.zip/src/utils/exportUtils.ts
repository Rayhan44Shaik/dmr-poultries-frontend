import * as XLSX from "xlsx";
import { saveAs } from "file-saver";

import jsPDF from "jspdf";
import autoTable from "jspdf-autotable";

export function exportToExcel(

  data: any[],
  moduleName: string

) {

  if (!data.length) {

    alert("No data available.");

    return;

  }

  const worksheet =
    XLSX.utils.json_to_sheet(data);

  const workbook =
    XLSX.utils.book_new();

  XLSX.utils.book_append_sheet(

    workbook,

    worksheet,

    moduleName

  );

  const excelBuffer =
    XLSX.write(

      workbook,

      {

        bookType: "xlsx",

        type: "array",

      }

    );

  const blob = new Blob(

    [excelBuffer],

    {

      type:
        "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",

    }

  );

  saveAs(

    blob,

    `${moduleName}.xlsx`

  );

}

export function exportToPdf(

  data: any[],
  moduleName: string

) {

  if (!data.length) {

    alert("No data available.");

    return;

  }

  const doc = new jsPDF();

  doc.setFontSize(18);

  doc.text(

    `${moduleName} Report`,

    14,

    18

  );

  const headers = [

    Object.keys(data[0])

  ];

const rows = data.map(
  (item) =>
    Object.values(item) as (string | number | boolean | null)[]
);

  autoTable(

    doc,

    {

      head: headers,

      body: rows,

      startY: 28,

      styles: {

        fontSize: 8,

      },

      headStyles: {

        fillColor: [22, 101, 52],

      },

    }

  );

  doc.save(

    `${moduleName}.pdf`

  );

}