import { useLocation } from "react-router-dom";

function Header() {

  const location = useLocation();


const pageTitles: Record<string, string> = {

  "/dashboard": "Dashboard",

  "/masters": "Masters",

  "/masters/shops": "Shops",

  "/masters/farms": "Farms",

  "/masters/vehicles": "Master Vehicles",

  "/masters/employees": "Employees",

  "/masters/banks": "Banks",

  "/masters/bird-types": "Bird Types",

  "/operations": "Operations",

  "/operations/shop-sales": "Shop Sales",

  "/shop-sales/completed-trips": "Completed Trips",

  "/operations/collections/entry": "Collection Entry",

  "/accounts": "Accounts",

  "/vehicles": "Vehicle Management",

  "/staff": "Staff",

  "/reports": "Reports",

  "/settings": "Settings"

};

const pageTitle =
  pageTitles[location.pathname] ??
  "DMR Poultries";
  return (

    <header className="h-16 bg-white border-b border-slate-200 shadow-sm flex items-center justify-between px-6">

      <div>

        <h2 className="text-xl font-semibold text-slate-800">
          {pageTitle}
        </h2>

      </div>

      <div className="flex items-center gap-6">

        <button className="text-slate-600 hover:text-green-700 text-xl">
          🔔
        </button>

        <div className="flex items-center gap-3">

          <div className="w-10 h-10 rounded-full bg-green-700 text-white flex items-center justify-center font-bold">
            R
          </div>

          <div>

            <p className="font-semibold text-slate-800">
              Ruhulla
            </p>

            <p className="text-xs text-slate-500">
              Administrator
            </p>

          </div>

        </div>

      </div>

    </header>

  );
}

export default Header;