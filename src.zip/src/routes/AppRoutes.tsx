import { BrowserRouter, Routes, Route } from "react-router-dom";

import LoginPage from "../modules/auth/LoginPage";

import DashboardPage from "../modules/dashboard/DashboardPage";

import MastersPage from "../modules/masters/pages/MastersPage";

import ShopsPage from "../modules/masters/shops/pages/ShopsPage";
import FarmsPage from "../modules/masters/farms/pages/FarmsPage";

import OperationsDashboard from "../modules/operations/pages/OperationsDashboard";
import AccountsPage from "../modules/accounts/pages/AccountsPage";
import VehicleManagementPage  from "../modules/vehicles/pages/VehicleManagementPage ";
import StaffPage from "../modules/staff/pages/StaffPage";
import ReportsPage from "../modules/reports/pages/ReportsPage";
import SettingsPage from "../modules/settings/pages/SettingsPage";
import MasterVehiclesPage  from "../modules/masters/vehicles/pages/MasterVehiclesPage ";
import EmployeesPage from "../modules/masters/employees/pages/EmployeesPage";
import BanksPage from "../modules/masters/banks/pages/BanksPage";
import BirdTypesPage from "../modules/masters/bird-types/pages/BirdTypesPage";
import operationsRoutes from "../modules/operations/routes/operationsRoutes";
import ShopSalesPage from "../modules/operations/shop-sales/pages/ShopSalesPage";
import CompletedTripsPage from "../modules/operations/shop-sales/completed-trips/pages/CompletedTripsPage";
import collectionRoutes from "../modules/operations/collections/routes/collectionRoutes";
function AppRoutes() {
  return (
    <BrowserRouter>
      <Routes>

        <Route
          path="/"
          element={<LoginPage />}
        />

        <Route
          path="/dashboard"
          element={<DashboardPage />}
        />

        <Route
          path="/masters"
          element={<MastersPage />}
        />

        <Route
          path="/masters/shops"
          element={<ShopsPage />}
        />
        <Route
          path="/test123"
          element={<h1 style={{ color: "red" }}>TEST123</h1>}
        />
        <Route
          path="/masters/farms"
          element={<FarmsPage />}
        />
        <Route
          path="/masters/vehicles"
          element={<MasterVehiclesPage   />}
        />
        <Route
          path="/masters/employees"
          element={<EmployeesPage />}
        />
        <Route
          path="/masters/banks"
          element={<BanksPage />}
        />
        <Route
          path="/masters/bird-types"
          element={<BirdTypesPage />}
        />
       <Route
  path="/operations"
  element={<OperationsDashboard />}
/>

{operationsRoutes.map((route) => (
  <Route
    key={route.path}
    path={route.path}
    element={route.element}
  />
))}

{collectionRoutes.map((route) => (
  <Route
    key={route.path}
    path={route.path}
    element={route.element}
  />
))}

<Route
  path="/operations/shop-sales"
  element={<ShopSalesPage />}
 />

<Route
  path="/shop-sales/completed-trips"
  element={<CompletedTripsPage />}
 />
        <Route
          path="/accounts"
          element={<AccountsPage />}
        />

        <Route
          path="/vehicles"
          element={<VehicleManagementPage  />}
        />

        <Route
          path="/staff"
          element={<StaffPage />}
        />

        <Route
          path="/reports"
          element={<ReportsPage />}
        />

        <Route
          path="/settings"
          element={<SettingsPage />}
        />

      </Routes>
    </BrowserRouter>
  );
}

export default AppRoutes;