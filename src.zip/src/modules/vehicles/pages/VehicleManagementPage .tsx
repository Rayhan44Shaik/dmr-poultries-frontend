function VehiclesPage() {
  return (
    <div className="p-8">
      <h1 className="text-3xl font-bold">Vehicles</h1>
      <p className="text-gray-500 mt-2">
        Vehicles Module
      </p>
    </div>
  );
}

export default VehiclesPage;