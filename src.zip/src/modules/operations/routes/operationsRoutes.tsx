import type { RouteObject } from "react-router-dom";

import OperationsDashboard from "../pages/OperationsDashboard";

import TripEntryPage from "../vehicle-trips/pages/TripEntryPage";
import TripListPage from "../vehicle-trips/pages/TripListPage";
/*
import SalesEntryPage from "../sales/pages/SalesEntryPage";
import SalesListPage from "../sales/pages/SalesListPage";

import CollectionEntryPage from "../collections/pages/CollectionEntryPage";
import CollectionListPage from "../collections/pages/CollectionListPage";

import ExpenseEntryPage from "../expenses/pages/ExpenseEntryPage";
import ExpenseListPage from "../expenses/pages/ExpenseListPage";

import MortalityEntryPage from "../mortality/pages/MortalityEntryPage";
import MortalityListPage from "../mortality/pages/MortalityListPage";
*/
const operationsRoutes: RouteObject[] = [

  {
    path: "/operations",
    element: <OperationsDashboard />
  },

  // ===============================
  // Vehicle Trips
  // ===============================

  {
    path: "/operations/vehicle-trips/entry",
    element: <TripEntryPage />
  },

  {
    path: "/operations/vehicle-trips/list",
    element: <TripListPage />
  },

  // ===============================
  // Sales
  // ===============================
/*
  {
    path: "/operations/sales/entry",
    element: <SalesEntryPage />
  },

  {
    path: "/operations/sales/list",
    element: <SalesListPage />
  },

  // ===============================
  // Collections
  // ===============================

  {
    path: "/operations/collections/entry",
    element: <CollectionEntryPage />
  },

  {
    path: "/operations/collections/list",
    element: <CollectionListPage />
  },

  // ===============================
  // Expenses
  // ===============================

  {
    path: "/operations/expenses/entry",
    element: <ExpenseEntryPage />
  },

  {
    path: "/operations/expenses/list",
    element: <ExpenseListPage />
  },

  // ===============================
  // Mortality
  // ===============================

  {
    path: "/operations/mortality/entry",
    element: <MortalityEntryPage />
  },

  {
    path: "/operations/mortality/list",
    element: <MortalityListPage />
  }
*/
];

export default operationsRoutes;