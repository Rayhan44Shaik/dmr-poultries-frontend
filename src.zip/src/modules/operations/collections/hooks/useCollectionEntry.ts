import { useEffect, useMemo, useState } from "react";

import type {
  CollectionEntry,
  CollectionErrors,
  PendingCollection,
  RecentCollection,
  PaymentMode
} from "../types/collection";

import { collectionService } from "../services/collectionService";

import { shopService } from "../../../masters/shops/services/shopService";

import { getEmployees } from "../../../masters/employees/services/employeeService";

import { getBanks } from "../../../masters/banks/services/bankService";

/* ==========================================================
   COLLECTION ENTRY HOOK
========================================================== */

export default function useCollectionEntry() {

  /* ======================================================
     MASTER DATA
  ====================================================== */

  const [shops, setShops] = useState<string[]>([]);

  const [collectors, setCollectors] = useState<string[]>([]);

  const [paymentModes, setPaymentModes] = useState<PaymentMode[]>([]);

  const [pendingCollections, setPendingCollections] =
    useState<PendingCollection[]>([]);

  const [recentCollections, setRecentCollections] =
    useState<RecentCollection[]>([]);

  /* ======================================================
     SELECTED SHOP
  ====================================================== */

  const [pendingShop, setPendingShop] =
    useState<PendingCollection | null>(null);

  /* ======================================================
     FORM STATE
  ====================================================== */

  const [entry, setEntry] =
    useState<CollectionEntry>({

      collectionId: "",

      collectionNo: "",

      collectionDate:
        new Date()
          .toISOString()
          .split("T")[0],

      shopName: "",

      collectorName: "",

      paymentModeName: "Cash",

      referenceNo: "",

      amount: 0,

      remarks: ""

    });

  /* ======================================================
     VALIDATION
  ====================================================== */

  const [errors, setErrors] =
    useState<CollectionErrors>({});

  /* ======================================================
     PAGE STATE
  ====================================================== */

  const [loading, setLoading] =
    useState(false);

  const [isSaving, setIsSaving] =
    useState(false);
  
  const [isEditing, setIsEditing] = useState(false);

  const [statusFilter, setStatusFilter] =
    useState<"Pending" | "Approved" | "All">(
      "Pending"
    );
  /* ==========================================================
   PAGINATION
========================================================== */

const PAGE_SIZE = 25;

const [currentPage, setCurrentPage] =
  useState(1);

  /* ======================================================
     HEADER
  ====================================================== */

  const today = useMemo(() => {

    return new Date().toLocaleDateString(
      "en-GB"
    );

  }, []);

  const dashboard =
    useMemo(() => {

      return collectionService
        .getDashboardSummary();

    }, []);

  /* ======================================================
     LOAD MASTER DATA
  ====================================================== */

  function loadMasterData() {

    setLoading(true);

    /* Shops */

    const shopNames =
      shopService
        .getAll()
        .map(
          shop => shop.shopName
        )
        .sort();

    setShops(
      shopNames
    );

    /* Collectors */

    const collectorNames =
      getEmployees()

        .filter(emp =>

          (emp.department ?? "")
            .toLowerCase() ===
          "collection"

        )

        .map(
          emp => emp.employeeName
        )

        .sort();

    setCollectors(
      collectorNames
    );

    /* Payment Modes */

    const modes: PaymentMode[] = [

      {
        id: "cash",
        name: "Cash"
      }

    ];

    getBanks().forEach(bank => {

      modes.push({

        id: bank.bankName,

        name: bank.bankName

      });

    });

    setPaymentModes(
      modes
    );

    /* Pending Shops */

    setPendingCollections(

      collectionService
        .getPendingCollections()

    );

    /* Recent Collections */

    setRecentCollections(

      collectionService
        .getRecentCollections(
          "Pending"
        )

    );

    setLoading(false);

  }

  /* ======================================================
     INITIAL LOAD
  ====================================================== */

  useEffect(() => {

    loadMasterData();

  }, []);
  /* ==========================================================
   FIND PENDING SHOP
========================================================== */

function findPendingShop(

  shopName: string

): PendingCollection | null {

  return (

    pendingCollections.find(

      shop =>

        shop.shopName ===

        shopName

    ) ?? null

  );

}

/* ==========================================================
   SELECT SHOP
========================================================== */

function selectShop(

  shopName: string

) {

  const shop =

    findPendingShop(

      shopName

    );

  setPendingShop(

    shop

  );

  setEntry(prev => ({

    ...prev,

    shopName,

    amount:

      shop?.currentPending ?? 0,

    remarks: ""

  }));

}

/* ==========================================================
   SHOP CHANGE
========================================================== */

function changeShop(

  shopName: string

) {

  selectShop(

    shopName

  );

}

/* ==========================================================
   AUTO SELECT FIRST PENDING SHOP
========================================================== */

useEffect(() => {

  if (

    pendingCollections.length === 0

  ) {

    return;

  }

  if (

    entry.shopName

  ) {

    return;

  }

  selectShop(

    pendingCollections[0]

      .shopName

  );

}, [

  pendingCollections

]);

/* ==========================================================
   RESET ENTRY
========================================================== */

function resetEntry() {

  setPendingShop(

    null

  );

  setEntry({

    collectionId: "",

    collectionNo: "",

    collectionDate:

      new Date()

        .toISOString()

        .split("T")[0],

    shopName: "",

    collectorName: "",

    paymentModeName: "Cash",

    referenceNo: "",

    amount: 0,

    remarks: ""

  });

  setErrors({});
  setIsEditing(false);

}

/* ==========================================================
   VIEW SHOP LEDGER
========================================================== */

function viewLedger() {

  if (

    !pendingShop

  ) {

    return;

  }

  console.log(

    "Open Shop Ledger",

    pendingShop.shopName

  );

  /*
    Phase-2

    Navigate to

    Accounts

    →

    Shop Ledger

  */

}

/* ==========================================================
   OUTSTANDING SUMMARY
========================================================== */

const openingBalance =

  useMemo(() => {

    return pendingShop?.openingBalance ?? 0;

  }, [

    pendingShop

  ]);

const totalSales =

  useMemo(() => {

    return pendingShop?.totalSales ?? 0;

  }, [

    pendingShop

  ]);

const totalCollections =

  useMemo(() => {

    return pendingShop?.totalCollections ?? 0;

  }, [

    pendingShop

  ]);

const currentPending =

  useMemo(() => {

    return pendingShop?.currentPending ?? 0;

  }, [

    pendingShop

  ]);

/* ==========================================================
   LIVE COLLECTION
========================================================== */

const todayCollection =

  useMemo(() => {

    return Number(

      entry.amount || 0

    );

  }, [

    entry.amount

  ]);

const remainingBalance =

  useMemo(() => {

    const balance =

      currentPending -

      todayCollection;

    return balance < 0

      ? 0

      : balance;

  }, [

    currentPending,

    todayCollection

  ]);

/* ==========================================================
   COLLECTION PROGRESS
========================================================== */

const collectionProgress =

  useMemo(() => {

    if (

      openingBalance <= 0

    ) {

      return 0;

    }

    return Number(

      (

        (

          todayCollection /

          openingBalance

        ) *

        100

      ).toFixed(2)

    );

  }, [

    openingBalance,

    todayCollection

  ]);

/* ==========================================================
   PAGE SUMMARY
========================================================== */

const pageSummary =

  useMemo(() => {

    return {

      openingBalance,

      totalSales,

      totalCollections,

      currentPending,

      todayCollection,

      remainingBalance,

      collectionProgress,

      pendingShops:

        dashboard.totalPendingShops,

      pendingAmount:

        dashboard.totalPendingAmount,

      pendingApproval:

        dashboard.pendingApproval,

      approvedCollections:

        dashboard.approvedCollections

    };

  }, [

    openingBalance,

    totalSales,

    totalCollections,

    currentPending,

    todayCollection,

    remainingBalance,

    collectionProgress,

    dashboard

  ]);

/* ==========================================================
   FORM STATUS
========================================================== */

const disableSave =

  useMemo(() => {

    if (

      !pendingShop

    ) {

      return true;

    }

    if (

      !entry.shopName

    ) {

      return true;

    }

    if (

      !entry.collectorName

    ) {

      return true;

    }

    if (

      !entry.paymentModeName

    ) {

      return true;

    }

    if (

      Number(

        entry.amount

      ) <= 0

    ) {

      return true;

    }

    if (

      Number(

        entry.amount

      ) >

      currentPending

    ) {

      return true;

    }

    return false;

  }, [

    pendingShop,

    entry,

    currentPending

  ]);
  /* ==========================================================
   UPDATE ENTRY
========================================================== */

function updateEntry<
  K extends keyof CollectionEntry
>(
  field: K,
  value: CollectionEntry[K]
) {

  setEntry(prev => ({

    ...prev,

    [field]: value

  }));

  // Clear all validation errors whenever the user edits a field.
  setErrors({});

}


/* ==========================================================
   COLLECTOR CHANGE
========================================================== */

function changeCollector(

  collectorName: string

) {

  updateEntry(

    "collectorName",

    collectorName

  );

}

/* ==========================================================
   PAYMENT MODE CHANGE
========================================================== */

function changePaymentMode(

  paymentModeName: string

) {

  updateEntry(

    "paymentModeName",

    paymentModeName

  );

  if (

    paymentModeName === "Cash"

  ) {

    updateEntry(

      "referenceNo",

      ""

    );

  }

}

/* ==========================================================
   REFERENCE NUMBER
========================================================== */

function changeReference(

  referenceNo: string

) {

  updateEntry(

    "referenceNo",

    referenceNo

  );

}

/* ==========================================================
   COLLECTION AMOUNT
========================================================== */

function changeAmount(

  amount: number

) {

  if (

    amount < 0

  ) {

    amount = 0;

  }

  updateEntry(

    "amount",

    amount

  );

}

/* ==========================================================
   REMARKS
========================================================== */

function changeRemarks(

  remarks: string

) {

  updateEntry(

    "remarks",

    remarks

  );

}

/* ==========================================================
   DATE CHANGE
========================================================== */

function changeCollectionDate(

  collectionDate: string

) {

  updateEntry(

    "collectionDate",

    collectionDate

  );

}

/* ==========================================================
   PAYMENT MODE CHECK
========================================================== */

const isCashPayment =

  useMemo(() => {

    return (

      entry.paymentModeName ===

      "Cash"

    );

  }, [

    entry.paymentModeName

  ]);

const requiresReference =

  useMemo(() => {

    return !isCashPayment;

  }, [

    isCashPayment

  ]);

  /* ==========================================================
   VALIDATION
========================================================== */

function validateEntry(): boolean {

  const validation: CollectionErrors = {};

  /* Shop */

  if (!entry.shopName.trim()) {

    validation.shopName =

      "Please select a shop.";

  }

  /* Collector */

  if (!entry.collectorName.trim()) {

    validation.collectorName =

      "Please select a collector.";

  }

  /* Collection Date */

  if (!entry.collectionDate.trim()) {

    validation.collectionDate =

      "Collection date is required.";

  }

  /* Payment Mode */

  if (!entry.paymentModeName.trim()) {

    validation.paymentModeName =

      "Please select payment mode.";

  }

  /* Amount */

  if (Number(entry.amount) <= 0) {

    validation.amount =

      "Collection amount should be greater than zero.";

  }

  if (

    Number(entry.amount) >

    currentPending

  ) {

    validation.amount =

      "Collection amount cannot exceed pending amount.";

  }

  /* Reference Number */

  if (

    requiresReference &&

    !entry.referenceNo.trim()

  ) {

    validation.referenceNo =

      "Reference number is required.";

  }

  setErrors(validation);

  return Object.keys(validation).length === 0;

}

/* ==========================================================
   SAVE COLLECTION
========================================================== */

async function saveCollection() {

  if (!validateEntry()) {

    return;

  }

  try {

    setIsSaving(true);

    const success =

      collectionService.saveCollection(

        entry

      );

    if (!success) {

      return;

    }

    /* Reload Pending Shops */

    const pending =

      collectionService.getPendingCollections();

    setPendingCollections(

      pending

    );

    /* Reload Recent Collections */

    const recent =

      collectionService.getRecentCollections(

        statusFilter

      );

    setRecentCollections(

      recent

    );

    /* Reset Entry */

    resetEntry();

    /* Auto Select First Pending Shop */

    if (

      pending.length > 0

    ) {

      selectShop(

        pending[0].shopName

      );

    }

    else {

      setPendingShop(null);

    }

  }

  catch (error) {

    console.error(

      "Failed to save collection.",

      error

    );

  }

  finally {

    setIsSaving(false);

  }

}

/* ==========================================================
   CANCEL ENTRY
========================================================== */

function cancelCollection() {

  resetEntry();

  if (

    pendingCollections.length > 0

  ) {

    selectShop(

      pendingCollections[0].shopName

    );

  }

}

/* ==========================================================
   STATUS FILTER
========================================================== */

function changeStatusFilter(

  status: "Pending" | "Approved" | "All"

) {

  setStatusFilter(status)

    setCurrentPage(1);

  const data =

    collectionService.getRecentCollections(

      status

    );

  setRecentCollections(

    data

  );

}

/* ==========================================================
   APPROVE COLLECTION
========================================================== */

function approveCollection(

  id: string

) {

  const success =

    collectionService.approveCollection(

      id,

      "Admin"

    );

  if (!success) {

    return;

  }

  refreshPage();

}

/* ==========================================================
   DELETE COLLECTION
========================================================== */

function deleteCollection(

  id: string

) {

  const success =

    collectionService.deleteCollection(

      id

    );

  if (!success) {

    alert(

      "This collection can no longer be deleted."

    );

    return;

  }

  refreshPage();

}

/* ==========================================================
   REFRESH PAGE
========================================================== */

function refreshPage() {

  const pending =

    collectionService.getPendingCollections();

  setPendingCollections(

    pending

  );

  const recent =

    collectionService.getRecentCollections(

      statusFilter

    );

  setRecentCollections(

    recent

  );

  if (

    pending.length > 0

  ) {

    const selected =

      pending.find(

        shop =>

          shop.shopName ===

          entry.shopName

      );

    if (selected) {

      setPendingShop(

        selected

      );

    }

  }

}

/* ==========================================================
   RELOAD MODULE
========================================================== */

function reloadCollections() {

  loadMasterData();

}

/* ==========================================================
   HAS DATA
========================================================== */

const hasPendingCollections =

  pendingCollections.length > 0;

const hasRecentCollections =

  recentCollections.length > 0;

/* ==========================================================
   PENDING COUNTS
========================================================== */

const pendingApprovalCount =

  useMemo(() => {

    return collectionService.getPendingApprovalCount();

  }, [

    recentCollections

  ]);

const approvedCount =

  useMemo(() => {

    return collectionService.getApprovedCount();

  }, [

    recentCollections

  ]);
  /* ==========================================================
   LOAD COLLECTION FOR EDIT
========================================================== */

function editCollection(

  collection: RecentCollection

) {

  const shop =

    findPendingShop(

      collection.shopName

    );

  setPendingShop(

    shop

  );

  setEntry({

    collectionId:

      collection.id,

    collectionNo:

      collection.collectionNo,

    collectionDate:

      collection.collectionDate,

    shopName:

      collection.shopName,

    collectorName:

      collection.collectorName,

    paymentModeName:

      collection.paymentModeName,

    referenceNo:

      collection.referenceNo,

    amount:

      Number(

        collection.amount

      ),

    remarks:

      collection.remarks

  });

  setErrors({});
  setIsEditing(true);
}

/* ==========================================================
   UPDATE COLLECTION
========================================================== */

async function updateExistingCollection() {

  if (

    !validateEntry()

  ) {

    return;

  }

  const collections =

    collectionService.getCollections();

  const existing =

    collections.find(

      row =>

        row.id ===

        entry.collectionId

    );

  if (

    !existing

  ) {

    return;

  }

  const success =

    collectionService.updateCollection({

      ...existing,

      collectionDate:

        entry.collectionDate,

      shopName:

        entry.shopName,

      collectorName:

        entry.collectorName,

      paymentModeName:

        entry.paymentModeName,

      referenceNo:

        entry.referenceNo,

      amount:

        Number(

          entry.amount

        ),

      remarks:

        entry.remarks

    });

  if (

    !success

  ) {

    alert(

      "Edit is allowed only within 10 days."

    );

    return;

  }

  refreshPage();

  resetEntry();
  setIsEditing(false);

}

/* ==========================================================
   SAVE OR UPDATE
========================================================== */

async function saveOrUpdateCollection() {

  if (

    entry.collectionId

  ) {

    await updateExistingCollection();

    return;

  }

  await saveCollection();

}
/* ==========================================================
   RECENT COLLECTIONS OF SELECTED SHOP
========================================================== */

const selectedShopCollections =

  useMemo(() => {

    if (!pendingShop) {

      return [];

    }

    return recentCollections.filter(

      row =>

        row.shopName ===

        pendingShop.shopName

    );

  }, [

    pendingShop,

    recentCollections

  ]);

/* ==========================================================
   PAYMENT MODE
========================================================== */

const selectedPaymentMode =

  useMemo(() => {

    return paymentModes.find(

      mode =>

        mode.name ===

        entry.paymentModeName

    ) ?? null;

  }, [

    paymentModes,

    entry.paymentModeName

  ]);

/* ==========================================================
   PAGE SUMMARY
========================================================== */

const totalPendingShops =

  pendingCollections.length;

const totalPendingAmount =

  useMemo(() => {

    return pendingCollections.reduce(

      (total, shop) =>

        total +

        shop.currentPending,

      0

    );

  }, [

    pendingCollections

  ]);

/* ==========================================================
   FORM STATUS
========================================================== */

const formStatus =

  useMemo(() => {

    if (!pendingShop) {

      return {

        title: "No Shop Selected",

        message:

          "Select a pending shop.",

        status: "empty"

      };

    }

    if (

      remainingBalance === 0

    ) {

      return {

        title: "Collection Complete",

        message:

          "Outstanding amount fully collected.",

        status: "completed"

      };

    }

    return {

      title: "Pending Collection",

      message:

        "Outstanding balance available.",

      status: "pending"

    };

  }, [

    pendingShop,

    remainingBalance

  ]);

/* ==========================================================
   FOOTER STATE
========================================================== */

const footerState =

  useMemo(() => {

    return {

      loading,

      isSaving,

      disableSave,

      pendingApprovalCount,

      approvedCount

    };

  }, [

    loading,

    isSaving,

    disableSave,

    pendingApprovalCount,

    approvedCount

  ]);

/* ==========================================================
   PAGE ACTIONS
========================================================== */

const actions = {

  saveCollection:

    saveOrUpdateCollection,

  cancelCollection,

  approveCollection,

  deleteCollection,

  editCollection,

  refreshPage,

  reloadCollections,

  viewLedger,

  resetEntry

};
/* ==========================================================
   TODAY'S COLLECTION TOTAL
========================================================== */

const totalCollectionToday =

  useMemo(() => {

    return recentCollections

      .filter(

        row =>

          row.collectionDate ===

          entry.collectionDate

      )

      .reduce(

        (total, row) =>

          total +

          Number(row.amount),

        0

      );

  }, [

    recentCollections,

    entry.collectionDate

  ]);

/* ==========================================================
   RECENT COLLECTION COUNT
========================================================== */

const recentCollectionCount =

  useMemo(() => {

    return recentCollections.length;

  }, [

    recentCollections

  ]);

/* ==========================================================
   EMPTY STATES
========================================================== */

const noPendingShops =

  pendingCollections.length === 0;

const noRecentCollections =

  recentCollections.length === 0;

/* ==========================================================
   PAGE READY
========================================================== */

const pageReady =

  useMemo(() => {

    return !loading;

  }, [

    loading

  ]);

/* ==========================================================
   AUTO REFRESH FILTER
========================================================== */

useEffect(() => {

  setRecentCollections(

    collectionService.getRecentCollections(

      statusFilter

    )

  );

}, [

  statusFilter

]);

/* ==========================================================
   AUTO CLEAR ERRORS
========================================================== */

useEffect(() => {

  if (

    Object.keys(

      errors

    ).length === 0

  ) {

    return;

  }

  setErrors({});

}, [

  entry.shopName,

  entry.collectorName,

  entry.paymentModeName,

  entry.referenceNo,

  entry.amount

]);

/* ==========================================================
   COLLECTION STATISTICS
========================================================== */

const statistics =

  useMemo(() => {

    return {

      totalPendingShops,

      totalPendingAmount,

      pendingApprovalCount,

      approvedCount,

      totalCollectionToday,

      recentCollectionCount

    };

  }, [

    totalPendingShops,

    totalPendingAmount,

    pendingApprovalCount,

    approvedCount,

    totalCollectionToday,

    recentCollectionCount

  ]);

/* ==========================================================
   TOTAL PAGES
========================================================== */

const totalPages = useMemo(() => {

  if (recentCollections.length === 0) {

    return 1;

  }

  return Math.ceil(

    recentCollections.length /

    PAGE_SIZE

  );

}, [

  recentCollections

]);

/* ==========================================================
   PAGINATED COLLECTIONS
========================================================== */

const paginatedCollections =

  useMemo(() => {

    const start =

      (currentPage - 1) *

      PAGE_SIZE;

    return recentCollections.slice(

      start,

      start + PAGE_SIZE

    );

  }, [

    recentCollections,

    currentPage

  ]);

  /* ==========================================================
   CHANGE PAGE
========================================================== */

function changePage(
  page: number
) {

  if (page < 1) {

    return;

  }

  if (page > totalPages) {

    return;

  }

  setCurrentPage(page);

}

  /* ==========================================================
   RETURN
========================================================== */

return {

  /* ======================================================
     Header
  ====================================================== */

  today,

  dashboard,

  statistics,

  pageReady,

  /* ======================================================
     Masters
  ====================================================== */

  shops,

  collectors,

  paymentModes,

  /* ======================================================
     Pending Shops
  ====================================================== */

  pendingCollections,

  pendingShop,

  totalPendingShops,

  totalPendingAmount,

  /* ======================================================
     Collection Entry
  ====================================================== */

  entry,

  errors,

  isEditing,

  updateEntry,

  changeShop,

  changeCollector,

  changePaymentMode,

  changeReference,

  changeAmount,

  changeRemarks,

  changeCollectionDate,

  resetEntry,

  /* ======================================================
     Outstanding Summary
  ====================================================== */

  openingBalance,

  totalSales,

  totalCollections,

  currentPending,

  todayCollection,

  remainingBalance,

  collectionProgress,

  pageSummary,

  /* ======================================================
     Recent Collections
  ====================================================== */

recentCollections: paginatedCollections,

  selectedShopCollections,

  statusFilter,

  changeStatusFilter,

  pendingApprovalCount,

  approvedCount,

  recentCollectionCount,

  currentPage,

  totalPages,

changePage,

  /* ======================================================
     Form
  ====================================================== */

  formStatus,

  disableSave,

  loading,

  isSaving,

  footerState,

  /* ======================================================
     Actions
  ====================================================== */

  saveCollection: saveOrUpdateCollection,

  cancelCollection,

  approveCollection,

  deleteCollection,

  editCollection,

  viewLedger,

  refreshPage,

  reloadCollections,

  /* ======================================================
     Helpers
  ====================================================== */

  selectedPaymentMode,

  isCashPayment,

  requiresReference,

  hasPendingCollections,

  hasRecentCollections,

  noPendingShops,

  noRecentCollections,

  actions

};

}