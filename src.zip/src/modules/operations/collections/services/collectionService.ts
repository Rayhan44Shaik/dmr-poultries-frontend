import type {

  Collection,

  CollectionEntry,

  PendingCollection,

  RecentCollection,

  CollectorSummary,

  PaymentModeSummary,

  CollectionDashboardSummary

} from "../types/collection";

import type {

  ShopSale

} from "../../shop-sales/types/shopSale";

import {

  calculateCollectedAmount,

  calculatePendingAmount,

  calculateCollectorSummary,

  calculatePaymentModeSummary,

  canEditCollection,

  canDeleteCollection

} from "../utils/collectionCalculation";

/* ==========================================================
   STORAGE KEYS
========================================================== */

const COLLECTION_STORAGE =

  "dmr-collections";

const SHOPSALE_STORAGE =

  "dmr-shop-sales";

/* ==========================================================
   READ SHOP SALES
========================================================== */

function getShopSales(): ShopSale[] {

  const json =

    localStorage.getItem(

      SHOPSALE_STORAGE

    );

  if (!json) {

    return [];

  }

  try {

    return JSON.parse(

      json

    );

  }

  catch {

    return [];

  }

}

/* ==========================================================
   READ COLLECTIONS
========================================================== */

function getCollections(): Collection[] {

  const json =

    localStorage.getItem(

      COLLECTION_STORAGE

    );

  if (!json) {

    return [];

  }

  try {

    return JSON.parse(

      json

    );

  }

  catch {

    return [];

  }

}

/* ==========================================================
   SAVE COLLECTIONS
========================================================== */

function saveCollections(

  collections: Collection[]

): void {

  localStorage.setItem(

    COLLECTION_STORAGE,

    JSON.stringify(

      collections

    )

  );

}

/* ==========================================================
   NEXT COLLECTION NUMBER
========================================================== */

function getNextCollectionNumber(): string {

  const next =

    getCollections().length + 1;

  return `COL-${String(next).padStart(6, "0")}`;

}
/* ==========================================================
   GET PENDING COLLECTIONS
========================================================== */

function getPendingCollections()

: PendingCollection[] {

  const shopSales =

    getShopSales();

  const collections =

    getCollections();

  const shopMap =

    new Map<

      string,

      PendingCollection

    >();

  /* ======================================================
     BUILD SALES SUMMARY
  ====================================================== */

  shopSales.forEach(sale => {

    if (

      !shopMap.has(

        sale.shopName

      )

    ) {

      shopMap.set(

        sale.shopName,

        {

          shopName:

            sale.shopName,

          openingBalance: 0,

          totalSales: 0,

          totalCollections: 0,

          currentPending: 0,

          overdueDays: 0,

          lastCollectionDate: "-"

        }

      );

    }

    const shop =

      shopMap.get(

        sale.shopName

      )!;

    shop.totalSales +=

      Number(

        sale.amount

      );

  });

  /* ======================================================
     CALCULATE COLLECTIONS
  ====================================================== */

  shopMap.forEach(shop => {

    const approvedCollections =

      collections.filter(

        collection =>

          collection.shopName ===

            shop.shopName &&

          collection.status ===

            "Approved"

      );

    shop.totalCollections =

      calculateCollectedAmount(

        approvedCollections

      );

    shop.currentPending =

      calculatePendingAmount(

        shop.totalSales,

        shop.totalCollections

      );

    shop.openingBalance =

      shop.currentPending;

    /* ==================================================
       LAST COLLECTION
    ================================================== */

    if (

      approvedCollections.length > 0

    ) {

      const latest =

        approvedCollections

          .sort(

            (a, b) =>

              b.collectionDate.localeCompare(

                a.collectionDate

              )

          )[0];

      shop.lastCollectionDate =

        latest.collectionDate;

      const days =

        Math.floor(

          (

            new Date().getTime()

            -

            new Date(

              latest.collectionDate

            ).getTime()

          )

          /

          (1000 * 60 * 60 * 24)

        );

      shop.overdueDays =

        days < 0

          ? 0

          : days;

    }

  });

  /* ======================================================
     RETURN ONLY PENDING SHOPS
  ====================================================== */

  return Array

    .from(

      shopMap.values()

    )

    .filter(

      shop =>

        shop.currentPending > 0

    )

    .sort(

      (a, b) =>

        b.currentPending -

        a.currentPending

    );

}
/* ==========================================================
   SAVE COLLECTION
========================================================== */

function saveCollection(

  entry: CollectionEntry

): boolean {

  const collections =

    getCollections();

const collection: Collection = {

  id: crypto.randomUUID(),

  collectionNo: getNextCollectionNumber(),

  collectionDate: entry.collectionDate,

  shopName: entry.shopName,

  collectorName: entry.collectorName,

  paymentModeName: entry.paymentModeName,

  referenceNo: entry.referenceNo,

  amount: Number(entry.amount),

  remarks: entry.remarks,

  status: "Pending",

  createdDate: new Date().toISOString(),

  createdBy: "Admin"

};
  collections.unshift(

    collection

  );

  saveCollections(

    collections

  );

  return true;

}

/* ==========================================================
   UPDATE COLLECTION
========================================================== */

function updateCollection(

  collection: Collection

): boolean {

  if (

    !canEditCollection(

      collection.createdDate

    )

  ) {

    return false;

  }

  const collections =

    getCollections();

  const index =

    collections.findIndex(

      row =>

        row.id ===

        collection.id

    );

  if (

    index === -1

  ) {

    return false;

  }

  collections[index] = {

    ...collection,

    modifiedDate:

      new Date()

        .toISOString(),

    modifiedBy:

      "Admin"

  };

  saveCollections(

    collections

  );

  return true;

}

/* ==========================================================
   DELETE COLLECTION
========================================================== */

function deleteCollection(

  id: string

): boolean {

  const collections =

    getCollections();

  const row =

    collections.find(

      item =>

        item.id === id

    );

  if (

    !row

  ) {

    return false;

  }

  if (

    !canDeleteCollection(

      row.createdDate

    )

  ) {

    return false;

  }

  const updated =

    collections.filter(

      item =>

        item.id !== id

    );

  saveCollections(

    updated

  );

  return true;

}
/* ==========================================================
   APPROVE COLLECTION
========================================================== */

function approveCollection(

  id: string,

  approvedBy: string = "Admin"

): boolean {

  const collections =

    getCollections();

  const index =

    collections.findIndex(

      row =>

        row.id === id

    );

  if (

    index === -1

  ) {

    return false;

  }

  collections[index].status =

    "Approved";

  collections[index].approvedBy =

    approvedBy;

  collections[index].approvedDate =

    new Date()

      .toISOString();

  saveCollections(

    collections

  );

  return true;

}

/* ==========================================================
   RECENT COLLECTIONS
========================================================== */

function getRecentCollections(

  status:

    "Pending"

    | "Approved"

    | "All" = "Pending"

): RecentCollection[] {

  const collections =

    getCollections();

  let filtered =

    collections;

  if (

    status !== "All"

  ) {

    filtered =

      collections.filter(

        row =>

          row.status === status

      );

  }

  return filtered

    .sort((a, b) => {

  /* Pending Always First */

  if (a.status !== b.status) {

    return a.status === "Pending" ? -1 : 1;

  }

  /* Latest First */

  return b.collectionDate.localeCompare(
    a.collectionDate
  );

})

    .map(

      row => ({

        id:

          row.id,

        collectionNo:

          row.collectionNo,

        collectionDate:

          row.collectionDate,

        shopName:

          row.shopName,

        collectorName:

          row.collectorName,

        paymentModeName:

          row.paymentModeName,

        referenceNo:

          row.referenceNo,

        amount:

          row.amount,

        remarks:

          row.remarks,

        status:

          row.status,

        approvedBy:

          row.approvedBy,

        approvedDate:

          row.approvedDate

      })

    );

}

/* ==========================================================
   PENDING APPROVAL COUNT
========================================================== */

function getPendingApprovalCount(): number {

  return getCollections()

    .filter(

      row =>

        row.status ===

        "Pending"

    )

    .length;

}

/* ==========================================================
   APPROVED COUNT
========================================================== */

function getApprovedCount(): number {

  return getCollections()

    .filter(

      row =>

        row.status ===

        "Approved"

    )

    .length;

}
/* ==========================================================
   COLLECTOR SUMMARY
========================================================== */

function getCollectorSummary()

: CollectorSummary[] {

  const approvedCollections =

    getCollections()

      .filter(

        row =>

          row.status ===

          "Approved"

      );

  return calculateCollectorSummary(

    approvedCollections

  );

}

/* ==========================================================
   PAYMENT MODE SUMMARY
========================================================== */

function getPaymentModeSummary()

: PaymentModeSummary[] {

  const approvedCollections =

    getCollections()

      .filter(

        row =>

          row.status ===

          "Approved"

      );

  return calculatePaymentModeSummary(

    approvedCollections

  );

}

/* ==========================================================
   DASHBOARD SUMMARY
========================================================== */

function getDashboardSummary()

: CollectionDashboardSummary {

  const pendingCollections =

    getPendingCollections();

  const approvedCollections =

    getCollections()

      .filter(

        row =>

          row.status ===

          "Approved"

      );

  const totalPendingAmount =

    pendingCollections.reduce(

      (total, row) =>

        total +

        row.currentPending,

      0

    );

  return {

    totalPendingShops:

      pendingCollections.length,

    totalPendingAmount,

    pendingApproval:

      getPendingApprovalCount(),

    approvedCollections:

      approvedCollections.length

  };

}

/* ==========================================================
   REFRESH COLLECTION MODULE
========================================================== */

function refreshCollections() {

  return {

    pendingCollections:

      getPendingCollections(),

    recentCollections:

      getRecentCollections(),

    collectorSummary:

      getCollectorSummary(),

    paymentModeSummary:

      getPaymentModeSummary(),

    dashboardSummary:

      getDashboardSummary()

  };

}
/* ==========================================================
   EXPORT SERVICE
========================================================== */

export const collectionService = {

  /* ======================================================
     Storage
  ====================================================== */

  getShopSales,

  getCollections,

  saveCollections,

  /* ======================================================
     Collection Number
  ====================================================== */

  getNextCollectionNumber,

  /* ======================================================
     Pending Collections
  ====================================================== */

  getPendingCollections,

  /* ======================================================
     Collection Entry
  ====================================================== */

  saveCollection,

  updateCollection,

  deleteCollection,

  approveCollection,

  /* ======================================================
     Recent Collections
  ====================================================== */

  getRecentCollections,

  getPendingApprovalCount,

  getApprovedCount,

  /* ======================================================
     Reports
  ====================================================== */

  getCollectorSummary,

  getPaymentModeSummary,

  getDashboardSummary,

  /* ======================================================
     Refresh
  ====================================================== */

  refreshCollections

};