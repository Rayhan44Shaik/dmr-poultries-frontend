import useCollectionEntry from "../hooks/useCollectionEntry";

import CollectionInformation from "../components/entry/CollectionInformation";
import OutstandingSummary from "../components/entry/OutstandingSummary";
import CollectionAmount from "../components/entry/CollectionAmount";
import RecentCollectionsTable from "../components/entry/RecentCollectionsTable";
export default function CollectionEntryPage() {

  const vm = useCollectionEntry();

  return (

    <div className="w-full p-6">

      {/* ===========================================
          PAGE HEADER
      =========================================== */}

      <div className="mb-1">

    
      </div>

      {/* ===========================================
          MAIN CONTAINER
      =========================================== */}

      <div className="rounded-lg border border-slate-200 bg-white shadow-sm">

        {/* Collection Information */}

        <div className="border-b border-slate-200 p-3">

          <CollectionInformation

            entry={vm.entry}

            errors={vm.errors}

            shops={vm.shops}

            collectors={vm.collectors}

            paymentModes={vm.paymentModes}

            onDateChange={vm.changeCollectionDate}

            onShopChange={vm.changeShop}

            onCollectorChange={vm.changeCollector}

            onPaymentModeChange={vm.changePaymentMode}

            onReferenceChange={vm.changeReference}

            onViewLedger={vm.viewLedger}

            onReset={vm.resetEntry}

          />

        </div>

        {/* Outstanding Summary */}

<div className="mt-5 grid grid-cols-10 gap-5 items-start">
  <div className="col-span-4 min-w-0">

          <OutstandingSummary

            openingBalance={vm.openingBalance}

            totalSales={vm.totalSales}

            totalCollections={vm.totalCollections}

            currentPending={vm.currentPending}

          />

        </div>

        {/* Collection Amount */}

  <div className="col-span-6 min-w-0">

          <CollectionAmount
  amount={vm.entry.amount}
  remarks={vm.entry.remarks}
  previousBalance={vm.currentPending}
  receivedToday={vm.todayCollection}
  remainingBalance={vm.remainingBalance}
  onAmountChange={vm.changeAmount}
  onRemarksChange={vm.changeRemarks}

  onSave={vm.saveCollection}
  onCancel={vm.cancelCollection}
  isSaving={vm.isSaving}
  disableSave={vm.disableSave}
/>

  </div>

</div>                {/* ===========================================
            RECENT COLLECTIONS
        =========================================== */}

        <div className="border-b border-slate-200 p-3">

          <RecentCollectionsTable

            collections={vm.recentCollections}

            statusFilter={vm.statusFilter}

            pendingApprovalCount={vm.pendingApprovalCount}

            currentPage={vm.currentPage}

            totalPages={vm.totalPages}

            pageSize={25}

            onStatusChange={vm.changeStatusFilter}

            onPageChange={vm.changePage}

            onApprove={vm.approveCollection}

            onEdit={vm.editCollection}

            onDelete={vm.deleteCollection}

          />

        </div>


        </div>

      </div>

  );

}