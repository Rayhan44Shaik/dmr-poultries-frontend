import type { RouteObject } from "react-router-dom";

import DashboardLayout from "../../../../layouts/DashboardLayout/DashboardLayout";

import CollectionEntryPage from "../pages/CollectionEntryPage";

const collectionRoutes: RouteObject[] = [
  {
    path: "/operations/collections/entry",
    element: (
      <DashboardLayout>
        <CollectionEntryPage />
      </DashboardLayout>
    )
  }
];

export default collectionRoutes;