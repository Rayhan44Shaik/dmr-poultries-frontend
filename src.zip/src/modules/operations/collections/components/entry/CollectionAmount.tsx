import {
  Save,
  X,
  Wallet,
  BadgeIndianRupee,
  MessageSquareText,
  FileText,
  Wallet2,
  Landmark,
} from "lucide-react";

interface Props {
  amount: number;
  remarks: string;
  previousBalance: number;
  receivedToday: number;
  remainingBalance: number;
  onAmountChange: (value: number) => void;
  onRemarksChange: (value: string) => void;
  onSave: () => void;
  onCancel: () => void;
  isSaving: boolean;
  disableSave: boolean;
}

const inr = (n: number) =>
  "₹ " + Number(n || 0).toLocaleString("en-IN", {
    minimumFractionDigits: 2,
    maximumFractionDigits: 2,
  });

export default function CollectionAmount({
  amount,
  remarks,
  previousBalance,
  receivedToday,
  remainingBalance,
  onAmountChange,
  onRemarksChange,
  onSave,
  onCancel,
  isSaving,
  disableSave,
}: Props) {
  const completed = remainingBalance === 0 && amount > 0;

  return (
<div className="h-full w-full rounded-2xl border border-slate-200 bg-white-40 p-5 shadow-sm">      <div className="mb-4 flex items-center gap-2">
        <div className="flex h-8 w-8 items-center justify-center rounded-lg bg-green-100 text-green-700">
          <Wallet size={16} /> 
        </div>
        <h2 className="text-lg font-semibold text-green-800">
          Collection Details
        </h2>
      </div>

      {/* Amount + Remarks side by side */}
      <div className="grid grid-cols-1 gap-5 md:grid-cols-2">
        {/* Amount Received */}
        <div>
          <label className="mb-2 flex items-center gap-2 text-sm font-medium text-slate-700">
            <BadgeIndianRupee size={16} className="text-green-700" />
            Amount Received
          </label>
          <div className="relative">
            <span className="pointer-events-none absolute left-3 top-1/2 -translate-y-1/2 text-slate-500">
              ₹
            </span>
            <input
              type="number"
              min={0}
              value={amount}
              onChange={(e) => onAmountChange(Number(e.target.value))}
              placeholder="0.00"
              className="h-12 w-full rounded-lg border border-slate-300 bg-white pl-8 pr-3 text-lg font-bold text-slate-800 outline-none transition-all duration-200 focus:border-green-600 focus:ring-2 focus:ring-green-100"
            />
          </div>
          <p className="mt-2 text-xs text-slate-500">
            Enter the amount received from the selected shop.
          </p>
        </div>

        {/* Remarks */}
        <div>
          <label className="mb-2 flex items-center gap-2 text-sm font-medium text-slate-700">
            <MessageSquareText size={16} className="text-green-700" />
            Remarks <span className="font-normal text-slate-400">(Optional)</span>
          </label>
          <textarea
            rows={2}
            maxLength={250}
            value={remarks}
            onChange={(e) => onRemarksChange(e.target.value)}
            placeholder="Enter remarks..."
            className="w-full resize-none rounded-lg border border-slate-300 bg-white p-3 text-sm text-slate-700 outline-none transition-all duration-200 focus:border-green-600 focus:ring-2 focus:ring-green-100"
          />
          <div className="mt-1 flex justify-end">
            <span className={`text-xs font-medium ${remarks.length > 220 ? "text-red-600" : "text-slate-400"}`}>
              {remarks.length} / 250
            </span>
          </div>
        </div>
      </div>

      {/* After Collection */}
      <div className="mt-6">
        <div className="mb-4 flex items-center gap-3">
          <h3 className="text-base font-semibold text-green-800">After Collection</h3>
          <div className="h-px flex-1 bg-green-200" />
        </div>
<div className="grid grid-cols-1 gap-4 rounded-xl border border-green-200 bg-green-50 p-4 sm:grid-cols-3">

          <div className="flex items-center gap-3">
            <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-red-100 text-red-600">
              <FileText size={18} />
            </div>
            <div>
              <p className="text-xs font-medium text-slate-500">Previous Balance</p>
              <p className="text-lg font-bold tabular-nums text-red-600">{inr(previousBalance)}</p>
            </div>
          </div>

          {/* Received Today */}
          <div className="flex items-center gap-3">
            <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-blue-100 text-blue-600">
              <Wallet2 size={18} />
            </div>
            <div>
              <p className="text-xs font-medium text-slate-500">Received Today</p>
              <p className="text-lg font-bold tabular-nums text-blue-600">{inr(receivedToday)}</p>
            </div>
          </div>

          {/* Remaining Balance */}
          <div className="flex items-center gap-3">
            <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-green-100 text-green-700">
              <Landmark size={18} />
            </div>
            <div>
              <p className="text-xs font-medium text-slate-500">Remaining Balance</p>
              <p className={`text-lg font-bold tabular-nums ${completed ? "text-green-700" : "text-slate-800"}`}>
                {inr(remainingBalance)}
              </p>
              <span className={`mt-0.5 inline-block rounded px-2 py-0.5 text-[11px] font-semibold ${completed ? "bg-green-100 text-green-700" : "bg-orange-100 text-orange-700"}`}>
                {completed ? "Completed" : "Pending"}
              </span>
            </div>
          </div>
        </div>
      </div>

      {/* Actions */}
      <div className="mt-5 flex items-center justify-end gap-3">
        <button
          type="button"
          onClick={onCancel}
          className="inline-flex items-center gap-2 rounded-lg border border-slate-300 bg-white px-5 py-2.5 text-sm font-medium text-slate-700 transition-all duration-200 hover:border-red-300 hover:bg-red-50 hover:text-red-600"
        >
          <X size={16} />
          Cancel
        </button>
        <button
          type="button"
          onClick={onSave}
          disabled={disableSave || isSaving}
          className="inline-flex items-center gap-2 rounded-lg bg-green-700 px-6 py-2.5 text-sm font-semibold text-white shadow-sm transition-all duration-200 hover:bg-green-800 disabled:cursor-not-allowed disabled:opacity-50"
        >
          <Save size={17} />
          {isSaving ? "Saving..." : "Save Collection"}
        </button>
      </div>
    </div>
  );
}