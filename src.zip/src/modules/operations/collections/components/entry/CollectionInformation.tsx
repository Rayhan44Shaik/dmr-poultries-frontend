import {

  RotateCcw,

  BookOpen

} from "lucide-react";

import type {

  CollectionEntry,

  CollectionErrors,

  PaymentMode

} from "../../types/collection";

interface Props {

  entry: CollectionEntry;

  errors: CollectionErrors;

  shops: string[];

  collectors: string[];

  paymentModes: PaymentMode[];

  onDateChange: (
    value: string
  ) => void;

  onShopChange: (
    value: string
  ) => void;

  onCollectorChange: (
    value: string
  ) => void;

  onPaymentModeChange: (
    value: string
  ) => void;

  onReferenceChange: (
    value: string
  ) => void;

  onViewLedger: () => void;

  onReset: () => void;

}

export default function CollectionInformation({

  entry,

  errors,

  shops,

  collectors,

  paymentModes,

  onDateChange,

  onShopChange,

  onCollectorChange,

  onPaymentModeChange,

  onReferenceChange,

  onViewLedger,

  onReset

}: Props) {

  return (

    <div>

      {/* ===========================================
          TITLE
      =========================================== */}

      <h2 className="mb-5 text-lg font-semibold text-slate-800">

        Collection Information

      </h2>

      {/* ===========================================
          FIRST ROW
      =========================================== */}

      <div className="grid grid-cols-12 gap-4">

        {/* Collection Date */}

        <div className="col-span-3">

          <label className="mb-1 block text-sm font-medium text-slate-700">

            Collection Date

          </label>

          <input

            type="date"

            value={entry.collectionDate}

            onChange={(e) =>
              onDateChange(
                e.target.value
              )
            }

            className="
              h-10
              w-full
              rounded-md
              border
              border-slate-300
              px-3
              text-sm
              outline-none
              focus:border-blue-500
            "

          />

          {errors.collectionDate && (

            <p className="mt-1 text-xs text-red-600">

              {errors.collectionDate}

            </p>

          )}

        </div>

        {/* Collector */}

        <div className="col-span-3">

          <label className="mb-1 block text-sm font-medium text-slate-700">

            Collector

          </label>

          <select

            value={entry.collectorName}

            onChange={(e)=>

              onCollectorChange(

                e.target.value

              )

            }

            className="
              h-10
              w-full
              rounded-md
              border
              border-slate-300
              px-3
              text-sm
              outline-none
              focus:border-blue-500
            "

          >

            <option value="">

              Select Collector

            </option>

            {collectors.map(name=>(

              <option

                key={name}

                value={name}

              >

                {name}

              </option>

            ))}

          </select>

          {errors.collectorName && (

            <p className="mt-1 text-xs text-red-600">

              {errors.collectorName}

            </p>

          )}

        </div>

        {/* Payment Mode */}

        <div className="col-span-3">

          <label className="mb-1 block text-sm font-medium text-slate-700">

            Payment Mode

          </label>

          <select

            value={entry.paymentModeName}

            onChange={(e)=>

              onPaymentModeChange(

                e.target.value

              )

            }

            className="
              h-10
              w-full
              rounded-md
              border
              border-slate-300
              px-3
              text-sm
              outline-none
              focus:border-blue-500
            "

          >

            {paymentModes.map(mode=>(

              <option

                key={mode.name}

                value={mode.name}

              >

                {mode.name}

              </option>

            ))}

          </select>

          {errors.paymentModeName && (

            <p className="mt-1 text-xs text-red-600">

              {errors.paymentModeName}

            </p>

          )}

        </div>
                {/* Reference Number */}

        <div className="col-span-3">

          <label className="mb-1 block text-sm font-medium text-slate-700">

            Reference No.

          </label>

          <input

            type="text"

            value={entry.referenceNo}

            onChange={(e) =>
              onReferenceChange(
                e.target.value
              )
            }

            placeholder="Reference Number"

            disabled={
              entry.paymentModeName === "Cash"
            }

            className="
              h-10
              w-full
              rounded-md
              border
              border-slate-300
              px-3
              text-sm
              outline-none
              focus:border-blue-500
              disabled:bg-slate-100
              disabled:text-slate-400
            "

          />

          {errors.referenceNo && (

            <p className="mt-1 text-xs text-red-600">

              {errors.referenceNo}

            </p>

          )}

        </div>

      </div>

      {/* ===========================================
          SECOND ROW
      =========================================== */}

      <div className="mt-5 grid grid-cols-12 gap-4">

        {/* Shop */}

        <div className="col-span-8">

          <label className="mb-1 block text-sm font-medium text-slate-700">

            Shop Name

          </label>

          <select

            value={entry.shopName}

            onChange={(e) =>
              onShopChange(
                e.target.value
              )
            }

            className="
              h-10
              w-full
              rounded-md
              border
              border-slate-300
              px-3
              text-sm
              outline-none
              focus:border-blue-500
            "

          >

            <option value="">

              Select Shop

            </option>

            {shops.map(shop => (

              <option
                key={shop}
                value={shop}
              >

                {shop}

              </option>

            ))}

          </select>

          {errors.shopName && (

            <p className="mt-1 text-xs text-red-600">

              {errors.shopName}

            </p>

          )}

        </div>

        {/* Buttons */}

        <div className="col-span-4 flex items-end justify-end gap-3">

                   <button
            type="button"
            onClick={onViewLedger}
            className="
              inline-flex
              h-10
              items-center
              gap-2
              rounded-md
              bg-green-700
              px-4
              text-sm
              font-semibold
              text-white
              shadow-sm
              transition
              hover:bg-green-800
            "
          >
            <BookOpen size={16} />
            View Shop Ledger
          </button>

          <button
            type="button"
            onClick={onReset}
            className="
              inline-flex
              h-10
              items-center
              gap-2
              rounded-md
              border
              border-red-300
              bg-white
              px-4
              text-sm
              font-medium
              text-red-600
              transition
              hover:bg-red-50
            "
          >
            <RotateCcw size={16} />
            Reset
          </button>

        </div>

      </div>

    </div>

  );

}