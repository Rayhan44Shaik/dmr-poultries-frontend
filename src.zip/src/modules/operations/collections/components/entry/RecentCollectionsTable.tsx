import {

  CheckCircle2,

  Pencil,

  Trash2,

  Eye

} from "lucide-react";

import type {

  RecentCollection

} from "../../types/collection";

interface Props {

  collections: RecentCollection[];

  statusFilter: "Pending" | "Approved" | "All";

  pendingApprovalCount: number;

  currentPage: number;

  totalPages: number;

  pageSize: number;

  onStatusChange: (
    value: "Pending" | "Approved" | "All"
  ) => void;

  onPageChange: (
    page: number
  ) => void;

  onApprove: (
    id: string
  ) => void;

  onEdit: (
    row: RecentCollection
  ) => void;

  onDelete: (
    id: string
  ) => void;

}

export default function RecentCollectionsTable({

  collections,

  statusFilter,

  pendingApprovalCount,

  currentPage,

  totalPages,

  pageSize,

  onStatusChange,

  onPageChange,

  onApprove,

  onEdit,

  onDelete

}: Props) { 

  return (

    <div>

      {/* =======================================
          HEADER
      ======================================= */}

      <div className="mb-4 flex items-center justify-between">

        <div>

          <h2 className="text-lg font-semibold text-slate-800">

            Recent Collections

          </h2>

          <p className="mt-1 text-sm text-orange-600 font-medium">

            Pending Approval : {pendingApprovalCount}

          </p>

        </div>

        <select

          value={statusFilter}

          onChange={(e)=>

            onStatusChange(

              e.target.value as

              "Pending" |

              "Approved" |

              "All"

            )

          }

          className="
            h-10
            rounded-md
            border
            border-slate-300
            px-3
            text-sm
          "

        >

          <option>

            Pending

          </option>

          <option>

            Approved

          </option>

          <option>

            All

          </option>

        </select>

      </div>

      {/* =======================================
          TABLE
      ======================================= */}

      <div className="overflow-x-auto rounded-md border border-slate-200">

        <table className="min-w-full">

          <thead className="bg-slate-100">

            <tr>

              <th className="px-4 py-3 text-left text-sm font-semibold">

                Date

              </th>

              <th className="px-4 py-3 text-left text-sm font-semibold">

                Collector

              </th>

              <th className="px-4 py-3 text-left text-sm font-semibold">

                Amount

              </th>

              <th className="px-4 py-3 text-left text-sm font-semibold">

                Payment

              </th>

              <th className="px-4 py-3 text-left text-sm font-semibold">

                Reference

              </th>

              <th className="px-4 py-3 text-left text-sm font-semibold">

                Status

              </th>

              <th className="px-4 py-3 text-center text-sm font-semibold">

                Action

              </th>

            </tr>

          </thead>

          <tbody>
                      {collections.length === 0 ? (

            <tr>

              <td
                colSpan={7}
                className="py-12 text-center text-sm text-slate-500"
              >

                No collection records found.

              </td>

            </tr>

          ) : (

            collections.map((row) => {

              const createdDate = row.approvedDate
                ? new Date(row.approvedDate)
                : new Date(row.collectionDate);

              const today = new Date();

              const diffDays = Math.floor(
                (today.getTime() - createdDate.getTime()) /
                (1000 * 60 * 60 * 24)
              );

              const allowEditDelete =
                diffDays <= 10;

              return (

                <tr
                  key={row.id}
                  className="border-t border-slate-200 hover:bg-slate-50"
                >

                  <td className="px-4 py-3 text-sm">

                    {row.collectionDate}

                  </td>

                  <td className="px-4 py-3 text-sm">

                    {row.collectorName}

                  </td>

                  <td className="px-4 py-3 text-sm font-semibold text-blue-700">

                    ₹ {row.amount.toLocaleString("en-IN")}

                  </td>

                  <td className="px-4 py-3 text-sm">

                    {row.paymentModeName}

                  </td>

                  <td className="px-4 py-3 text-sm">

                    {row.referenceNo || "-"}

                  </td>

                  <td className="px-4 py-3">

                    {row.status === "Pending" ? (

                      <span className="rounded-full bg-orange-100 px-3 py-1 text-xs font-semibold text-orange-700">

                        Pending

                      </span>

                    ) : (

                      <span className="rounded-full bg-green-100 px-3 py-1 text-xs font-semibold text-green-700">

                        Approved

                      </span>

                    )}

                  </td>

                  <td className="px-4 py-3">

                    <div className="flex items-center justify-center gap-2">

                      {row.status === "Pending" && (

                        <button

                          title="Approve"

                          onClick={() =>
                            onApprove(row.id)
                          }

                          className="rounded-md p-2 text-green-600 hover:bg-green-50"

                        >

                          <CheckCircle2 size={18} />

                        </button>

                      )}

                      <button

                        title={
                          allowEditDelete
                            ? "Edit"
                            : "Edit expired"
                        }

                        disabled={!allowEditDelete}

                        onClick={() =>
                          onEdit(row)
                        }

                        className="rounded-md p-2 text-blue-600 hover:bg-blue-50 disabled:cursor-not-allowed disabled:opacity-40"

                      >

                        <Pencil size={18} />

                      </button>

                      <button

                        title={
                          allowEditDelete
                            ? "Delete"
                            : "Delete expired"
                        }

                        disabled={!allowEditDelete}

                        onClick={() =>
                          onDelete(row.id)
                        }

                        className="rounded-md p-2 text-red-600 hover:bg-red-50 disabled:cursor-not-allowed disabled:opacity-40"

                      >

                        <Trash2 size={18} />

                      </button>

                      <button

                        title="View"

                        className="rounded-md p-2 text-slate-600 hover:bg-slate-100"

                      >

                        <Eye size={18} />

                      </button>

                    </div>

                  </td>

                </tr>

              );

            })

          )}
                  </tbody>

      </table>

    </div>

    {/* =======================================
        PAGINATION
    ======================================= */}

    <div className="mt-4 flex items-center justify-between">

      <p className="text-sm text-slate-500">

        Showing

        {" "}

        {collections.length === 0
          ? 0
          : ((currentPage - 1) * pageSize) + 1}

        {" "}

        -

        {" "}

        {Math.min(
          currentPage * pageSize,
          totalPages * pageSize
        )}

      </p>

      <div className="flex items-center gap-2">

        <button

          type="button"

          disabled={currentPage === 1}

          onClick={() =>

            onPageChange(

              currentPage - 1

            )

          }

          className="
            h-9
            rounded-md
            border
            border-slate-300
            px-4
            text-sm
            disabled:cursor-not-allowed
            disabled:opacity-50
            hover:bg-slate-100
          "

        >

          Previous

        </button>

        {Array.from(

          {

            length: totalPages

          },

          (_, index) => (

            <button

              key={index}

              type="button"

              onClick={() =>

                onPageChange(

                  index + 1

                )

              }

              className={

                currentPage === index + 1

                  ? "flex h-9 w-9 items-center justify-center rounded-md bg-blue-600 text-sm font-semibold text-white"

                  : "flex h-9 w-9 items-center justify-center rounded-md border border-slate-300 text-sm hover:bg-slate-100"

              }

            >

              {index + 1}

            </button>

          )

        )}

        <button

          type="button"

          disabled={

            currentPage === totalPages ||

            totalPages === 0

          }

          onClick={() =>

            onPageChange(

              currentPage + 1

            )

          }

          className="
            h-9
            rounded-md
            border
            border-slate-300
            px-4
            text-sm
            disabled:cursor-not-allowed
            disabled:opacity-50
            hover:bg-slate-100
          "

        >

          Next

        </button>

      </div>

    </div>

  </div>

);

}