

import type { ShopSaleSummary } from "../types/shopSale";

interface Props {

  summary: ShopSaleSummary;

  fromDate: string;

  toDate: string;

  shopName: string;

}

export default function ShopSalesSummary({

  summary,

  fromDate,

  toDate,

  shopName

}: Props) {

  const hasFilter =

    fromDate !== "" ||

    toDate !== "" ||

    shopName.trim() !== "";

  let viewing = "-";

  if (hasFilter) {

    if (fromDate || toDate) {

      viewing =

        `${fromDate || "-"} to ${toDate || "-"}`;

    }

    if (shopName.trim()) {

      viewing +=

        ` | ${shopName}`;

    }

  }

  return (

    <div className="bg-white rounded-2xl border border-slate-200 shadow-sm p-8">

    <h2 className="text-2xl font-bold text-slate-800">

        Summary

    </h2>

    <div className="mt-6">

        <h3 className="text-lg font-bold text-slate-700">

            Applied Filter

        </h3>

        <p className="mt-2 text-slate-600">

            {

                hasFilter

                ? viewing

                : "-"

            }

        </p>

    </div>

    <div className="mt-8 border-t pt-6 space-y-5">

        <div className="flex justify-between">

            <span className="font-semibold">

                Total Shops

            </span>

            <span className="font-bold text-green-700">

                {

                    hasFilter

                    ? summary.totalShops

                    : "-"

                }

            </span>

        </div>

        <div className="flex justify-between">

            <span className="font-semibold">

                Total Birds

            </span>

            <span className="font-bold text-violet-700">

                {

                    hasFilter

                    ? summary.totalBirds.toLocaleString()

                    : "-"

                }

            </span>

        </div>

        <div className="flex justify-between">

            <span className="font-semibold">

                Total Weight

            </span>

            <span className="font-bold text-blue-700">

                {

                    hasFilter

                    ? `${summary.totalWeight.toFixed(2)} KG`

                    : "-"

                }

            </span>

        </div>

        <div className="flex justify-between">

            <span className="font-semibold">

                Total Amount

            </span>

            <span className="font-bold text-orange-600">

                {

                    hasFilter

                    ? `₹ ${summary.totalAmount.toLocaleString("en-IN",{

                        minimumFractionDigits:2

                    })}`

                    : "-"

                }

            </span>

        </div>

        <div className="flex justify-between">

            <span className="font-semibold">

                Average Rate

            </span>

            <span className="font-bold text-red-500">

                {

                    hasFilter

                    ? `₹ ${summary.averageRate.toFixed(2)}`

                    : "-"

                }

            </span>

        </div>

        <div className="flex justify-between">

            <span className="font-semibold">

                Average Weight / Bird

            </span>

            <span className="font-bold text-cyan-600">

                {

                    hasFilter

                    ? `${summary.averageWeightPerBird.toFixed(2)} KG`

                    : "-"

                }

            </span>

        </div>

    </div>

</div>

  );

}