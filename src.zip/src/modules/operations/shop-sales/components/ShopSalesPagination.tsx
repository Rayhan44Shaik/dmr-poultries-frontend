interface Props {

  currentPage: number;

  totalPages: number;

  onPageChange: (page: number) => void;

}

export default function ShopSalesPagination({

  currentPage,

  totalPages,

  onPageChange

}: Props) {

  if (totalPages <= 1)
    return null;

  return (

    <div className="bg-white rounded-2xl border border-slate-200 shadow-sm px-6 py-4">

      <div className="flex items-center justify-between">

        <div className="text-sm text-slate-500">

          Page

          <span className="font-bold text-slate-700 mx-1">

            {currentPage}

          </span>

          of

          <span className="font-bold text-slate-700 mx-1">

            {totalPages}

          </span>

        </div>

        <div className="flex gap-2">

          <button

            disabled={currentPage === 1}

            onClick={() =>

              onPageChange(currentPage - 1)

            }

            className="px-4 py-2 rounded-xl border disabled:opacity-40 hover:bg-slate-100"

          >

            Previous

          </button>

          {

            Array.from(

              { length: totalPages },

              (_, i) => i + 1

            ).map(page => (

              <button

                key={page}

                onClick={() =>

                  onPageChange(page)

                }

                className={`h-10 w-10 rounded-xl border transition

                ${

                  page === currentPage

                  ? "bg-green-700 text-white border-green-700"

                  : "hover:bg-slate-100"

                }`}

              >

                {page}

              </button>

            ))

          }

          <button

            disabled={currentPage === totalPages}

            onClick={() =>

              onPageChange(currentPage + 1)

            }

            className="px-4 py-2 rounded-xl border disabled:opacity-40 hover:bg-slate-100"

          >

            Next

          </button>

        </div>

      </div>

    </div>

  );

}