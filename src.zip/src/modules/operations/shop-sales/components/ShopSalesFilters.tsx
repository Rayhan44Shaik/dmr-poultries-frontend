import Select from "react-select";
import ExportDropdown from "./ExportDropdown";

interface Props {

  fromDate: string;

  toDate: string;

  shopName: string;

  sortBy: string;

  shopNames: string[];

  setFromDate: (value: string) => void;

  setToDate: (value: string) => void;

  setShopName: (value: string) => void;

  setSortBy: (value: string) => void;

  onSearch: () => void;

  onReset: () => void;

  totalEntries: number;
}

export default function ShopSalesFilters({

  fromDate,

  toDate,

  shopName,

  sortBy,

  shopNames,

  setFromDate,

  setToDate,

  setShopName,

  setSortBy,

  onSearch,

  onReset,
  totalEntries
  

}: Props) {

  const shopOptions = [

    {

      value: "",

      label: "All Shops"

    },

    ...shopNames.map(shop => ({

      value: shop,

      label: shop

    }))

  ];

  const sortOptions = [

    {

      value: "Latest",

      label: "Latest Date"

    },

    {

      value: "Shop",

      label: "Shop Name"

    },

    {

      value: "Birds",

      label: "Highest Birds"

    },

    {

      value: "Weight",

      label: "Highest Weight"

    },

    {

      value: "Amount",

      label: "Highest Amount"

    },

    {

      value: "Rate",

      label: "Highest Rate"

    }

  ];

  return (

    <div className="bg-white rounded-2xl border border-slate-200 shadow-sm p-6">

      {/* First Row */}

      <div className="grid grid-cols-12 gap-4">

        {/* From Date */}

        <div className="col-span-2">

          <label className="text-sm font-semibold mb-2 block">

            From Date

          </label>

          <input

            type="date"

            value={fromDate}

            onChange={(e) =>

              setFromDate(e.target.value)

            }

            className="w-full border rounded-xl px-3 py-2"

          />

        </div>

        {/* To Date */}

        <div className="col-span-2">

          <label className="text-sm font-semibold mb-2 block">

            To Date

          </label>

          <input

            type="date"

            value={toDate}

            onChange={(e) =>

              setToDate(e.target.value)

            }

            className="w-full border rounded-xl px-3 py-2"

          />

        </div>

        {/* Shop */}

        <div className="col-span-4">

          <label className="text-sm font-semibold mb-2 block">

            Shop Name

          </label>

          <Select

            options={shopOptions}

            isSearchable

            placeholder="Search Shop..."

            value={

              shopOptions.find(

                x =>

                  x.value === shopName

              )

            }

            onChange={(value) =>

              setShopName(

                value?.value || ""

              )

            }

          />

        </div>

        {/* Sort */}

        <div className="col-span-4">

          <label className="text-sm font-semibold mb-2 block">

            Sort By

          </label>

          <Select

            options={sortOptions}

            value={

              sortOptions.find(

                x =>

                  x.value === sortBy

              )

            }

            onChange={(value) =>

              setSortBy(

                value?.value || "Latest"

              )

            }

          />

        </div>

      </div>
   {/* Second Row */}

<div className="flex items-center justify-between mt-6">

    <div className="text-base font-semibold text-slate-700">

        Total Entries :

        <span className="ml-2 text-green-600">

            {totalEntries}

        </span>

    </div>

    <div className="flex items-center gap-3">

        <ExportDropdown
            onPdf={() => {}}
            onExcel={() => {}}
        />

        <button
            onClick={onSearch}
            className="h-11 px-8 rounded-xl bg-green-600 hover:bg-green-700 text-white font-semibold"
        >
            Search
        </button>

        <button
            onClick={onReset}
            className="h-11 px-8 rounded-xl border border-slate-300 bg-white hover:bg-slate-50 font-medium"
        >
            Reset
        </button>

    </div>

</div>

    </div>

  );

}