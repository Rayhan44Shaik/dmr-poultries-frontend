import type { ShopSale } from "../types/shopSale";

interface Props {

  sales: ShopSale[];

}

export default function ShopSalesTable({

  sales

}: Props) {

  return (

    <div className="bg-white rounded-2xl border border-slate-200 shadow-sm overflow-hidden">

      {/* Header */}

      <div className="px-6 py-5 border-b flex items-center justify-between">

        <div>

          <h2 className="text-2xl font-bold text-slate-800">

            Shop Sales Register

          </h2>

          <p className="text-sm text-slate-500 mt-1">

            Read-only register generated from locked completed trips.

          </p>

        </div>

      </div>

      <div className="overflow-x-auto">

        <table className="min-w-full text-sm">

          <thead className="sticky top-0 bg-slate-100 border-b z-10">

            <tr className="text-slate-700 whitespace-nowrap">

              <th className="px-4 py-4 text-center">

                S.No

              </th>

              <th className="px-4 py-4">

                Trip No

              </th>

              <th className="px-4 py-4">

                Date

              </th>

              <th className="px-4 py-4">

                Shop Name

              </th>

              <th className="px-4 py-4 text-center">

                Birds

              </th>

              <th className="px-4 py-4 text-center">

                Weight (KG)

              </th>

              <th className="px-4 py-4 text-center">

                Rate (₹)

              </th>

              <th className="px-4 py-4 text-center">

                Amount

              </th>

              <th className="px-4 py-4">

                Remark

              </th>

            </tr>

          </thead>

          <tbody>

            {

              sales.length === 0 ? (

                <tr>

                  <td
                    colSpan={9}
                    className="py-16 text-center text-slate-400"
                  >

                    No Shop Sales Found.

                  </td>

                </tr>

              ) : (

                sales.map((sale, index) => (

                  <tr
                    key={sale.id}
                    className="border-t hover:bg-slate-50 transition-colors"
                  >

                    {/* S.No */}

                    <td className="px-4 py-3 text-center">

                      {index + 1}

                    </td>

                    {/* Trip */}

                    <td className="px-4 py-3 font-semibold text-green-700">

                      {sale.tripNo}

                    </td>

                    {/* Date */}

                    <td className="px-4 py-3">

                      {sale.tripDate}

                    </td>

                    {/* Shop */}

                    <td className="px-4 py-3 font-medium">

                      {sale.shopName}

                    </td>

                    {/* Birds */}

                    <td className="px-4 py-3 text-center">

                      <span className="inline-flex px-3 py-1 rounded-full bg-blue-50 text-blue-700 font-semibold">

                        {sale.totalBirds.toLocaleString()}

                      </span>

                    </td>

                    {/* Weight */}

                    <td className="px-4 py-3 text-center">

                      <span className="inline-flex px-3 py-1 rounded-full bg-orange-50 text-orange-700 font-semibold">

                        {sale.totalWeight.toFixed(2)}

                      </span>

                    </td>

                    {/* Rate */}

                    <td className="px-4 py-3 text-center">

                      <span className="inline-flex px-3 py-1 rounded-full bg-violet-50 text-violet-700 font-semibold">

                        ₹ {(sale.rate ?? 0).toFixed(2)}

                      </span>

                    </td>

                    {/* Amount */}

                    <td className="px-4 py-3 text-center">

                      <span className="inline-flex px-3 py-1 rounded-full bg-green-50 text-green-700 font-bold">

                        ₹ {sale.amount.toLocaleString("en-IN", {

                          maximumFractionDigits: 2

                        })}

                      </span>

                    </td>

                    {/* Remark */}

                    <td className="px-4 py-3">

                      {sale.remark?.trim() || "-"}

                    </td>

                  </tr>

                ))

              )

            }

          </tbody>

        </table>

      </div>

    </div>

  );

}