import DashboardLayout from "../../../../../layouts/DashboardLayout/DashboardLayout";

import useCompletedTrips from "../hooks/useCompletedTrips";

import CompletedTripsHeader from "../components/CompletedTripsHeader";
import CompletedTripsFilters from "../components/CompletedTripsFilters";
import CompletedTripsTable from "../components/CompletedTripsTable";
import EnterRateModal from "../components/EnterRateModal";
import TripPagination from "../../../vehicle-trips/components/TripPagination";

export default function CompletedTripsPage() {

  const {

    filteredTrips,

    paginatedTrips,

    currentPage,

    totalPages,

    setCurrentPage,

    filter,

    setFilter,

    resetFilters,

    vehicleList,

    supervisorList,

    modalOpen,

    selectedTrip,

    openRateEntry,

    closeRateEntry,

    saveTrip

  } = useCompletedTrips();

  return (

    <DashboardLayout>

      <div className="space-y-6">

        {/* Header */}

        <CompletedTripsHeader

          trips={filteredTrips}

        />

        {/* Filters */}

        <CompletedTripsFilters

          fromDate={filter.fromDate}

          toDate={filter.toDate}

          tripNo={filter.tripNo}

          vehicle={filter.vehicle}

          supervisor={filter.supervisor}

          vehicleList={vehicleList}

          supervisorList={supervisorList}

          setFromDate={(value)=>

            setFilter({

              ...filter,

              fromDate:value

            })

          }

          setToDate={(value)=>

            setFilter({

              ...filter,

              toDate:value

            })

          }

          setTripNo={(value)=>

            setFilter({

              ...filter,

              tripNo:value

            })

          }

          setVehicle={(value)=>

            setFilter({

              ...filter,

              vehicle:value

            })

          }

          setSupervisor={(value)=>

            setFilter({

              ...filter,

              supervisor:value

            })

          }

          onSearch={()=>{

            setCurrentPage(1);

          }}

          onReset={resetFilters}

        />

        {/* Table */}

        <CompletedTripsTable

          trips={paginatedTrips}

          onEnterRate={openRateEntry}

        />

        {/* Pagination */}

        <TripPagination

          currentPage={currentPage}

          totalPages={totalPages}

          onPageChange={setCurrentPage}

        />

        {/* Modal */}

        <EnterRateModal

          open={modalOpen}

          trip={selectedTrip}

          onClose={closeRateEntry}

          onSave={saveTrip}

        />

      </div>

    </DashboardLayout>

  );

}