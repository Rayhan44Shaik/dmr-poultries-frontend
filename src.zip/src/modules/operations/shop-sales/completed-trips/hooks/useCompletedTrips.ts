import { useEffect, useMemo, useState } from "react";

import type { Trip } from "../../../vehicle-trips/types/trip";

import { completedTripService } from "../services/completedTripService";

export default function useCompletedTrips() {

  /* =========================================
     State
  ========================================= */

  const [trips, setTrips] = useState<Trip[]>([]);

  const [selectedTrip, setSelectedTrip] =
    useState<Trip | null>(null);

  const [modalOpen, setModalOpen] =
    useState(false);

  const [currentPage, setCurrentPage] =
    useState(1);

  const pageSize = 10;

  const [filter, setFilter] = useState({

    fromDate: "",

    toDate: "",

    tripNo: "",

    vehicle: ""

  });

  /* =========================================
     Load Trips
  ========================================= */

  function loadTrips() {

    setTrips(

      completedTripService.getCompletedTrips()

    );

  }

  useEffect(() => {

    loadTrips();

  }, []);

  /* =========================================
     Filter Trips
  ========================================= */

  const filteredTrips = useMemo(() => {

    return trips.filter((trip) => {

      const fromOk =

        !filter.fromDate ||

        trip.tripDate >= filter.fromDate;

      const toOk =

        !filter.toDate ||

        trip.tripDate <= filter.toDate;

      const tripOk =

        !filter.tripNo ||

        trip.tripNo
          .toLowerCase()
          .includes(filter.tripNo.toLowerCase());

      const vehicleOk =

        !filter.vehicle ||

        trip.vehicleNo === filter.vehicle;

      return (

        fromOk &&

        toOk &&

        tripOk &&

        vehicleOk

      );

    });

  }, [

    trips,

    filter

  ]);

  /* =========================================
     Pagination
  ========================================= */

  const totalPages = Math.ceil(

    filteredTrips.length / pageSize

  );

  const paginatedTrips = useMemo(() => {

    const start =

      (currentPage - 1) * pageSize;

    return filteredTrips.slice(

      start,

      start + pageSize

    );

  }, [

    filteredTrips,

    currentPage

  ]);

  /* =========================================
     Vehicle Dropdown
  ========================================= */

  const vehicleList = [

    ...new Set(

      trips.map(

        x => x.vehicleNo

      )

    )

  ];

  /* =========================================
     Open Modal
  ========================================= */

  function openRateEntry(

    trip: Trip

  ) {

    setSelectedTrip(trip);

    setModalOpen(true);

  }

  /* =========================================
     Close Modal
  ========================================= */

  function closeRateEntry() {

    setSelectedTrip(null);

    setModalOpen(false);

  }

  /* =========================================
     Save & Lock
  ========================================= */

  function saveTrip(

    deliveries: Trip["deliveries"]

  ) {

    if (!selectedTrip)
      return;

    const saved =

      completedTripService.saveRates(

        selectedTrip.id,

        deliveries

      );

    if (saved) {

      closeRateEntry();

      loadTrips();

    }

  }

  /* =========================================
     Reset Filters
  ========================================= */

  function resetFilters() {

    setFilter({

      fromDate: "",

      toDate: "",

      tripNo: "",

      vehicle: ""

    });

    setCurrentPage(1);

  }

  /* =========================================
     Return
  ========================================= */

  return {

    trips,

    filteredTrips,

    paginatedTrips,

    currentPage,

    totalPages,

    setCurrentPage,

    filter,

    setFilter,

    resetFilters,

    vehicleList,

    modalOpen,

    selectedTrip,

    openRateEntry,

    closeRateEntry,

    saveTrip

  };

}