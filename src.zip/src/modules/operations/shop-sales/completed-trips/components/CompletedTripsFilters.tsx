import {
  Search,
  RotateCcw
} from "lucide-react";

import Select from "react-select";

interface Props {

  fromDate: string;

  toDate: string;

  tripNo: string;

  vehicle: string;

  vehicleList: string[];

  setFromDate: (value: string) => void;

  setToDate: (value: string) => void;

  setTripNo: (value: string) => void;

  setVehicle: (value: string) => void;

  onSearch: () => void;

  onReset: () => void;

}

export default function CompletedTripsFilters({

  fromDate,

  toDate,

  tripNo,

  vehicle,

  vehicleList,

  setFromDate,

  setToDate,

  setTripNo,

  setVehicle,

  onSearch,

  onReset

}: Props) {

  return (

    <div className="bg-white rounded-2xl border border-slate-200 shadow-sm p-6">

      <div className="grid grid-cols-4 gap-5">

        {/* From Date */}

        <div>

          <label className="text-sm font-semibold text-slate-700 mb-2 block">

            From Date

          </label>

          <input

            type="date"

            value={fromDate}

            onChange={(e) =>

              setFromDate(e.target.value)

            }

            className="w-full h-11 rounded-xl border border-slate-300 px-3 focus:border-green-600 focus:ring-2 focus:ring-green-100 outline-none"

          />

        </div>

        {/* To Date */}

        <div>

          <label className="text-sm font-semibold text-slate-700 mb-2 block">

            To Date

          </label>

          <input

            type="date"

            value={toDate}

            onChange={(e) =>

              setToDate(e.target.value)

            }

            className="w-full h-11 rounded-xl border border-slate-300 px-3 focus:border-green-600 focus:ring-2 focus:ring-green-100 outline-none"

          />

        </div>

        {/* Vehicle */}

        <div>

          <label className="text-sm font-semibold text-slate-700 mb-2 block">

            Vehicle

          </label>

          <Select

    menuPortalTarget={document.body}

    menuPosition="fixed"

    placeholder="All Vehicles"

    isSearchable

    value={

        vehicle

            ? {

                value: vehicle,

                label: vehicle

            }

            : null

    }

    options={

        vehicleList.map((item)=>({

            value:item,

            label:item

        }))

    }

    onChange={(selected)=>{

        setVehicle(

            selected

                ? selected.value

                : ""

        );

    }}

    styles={{

        control:(base)=>({

            ...base,

            minHeight:44,

            borderRadius:12

        })

    }}

/>

        </div>

        {/* Trip Search */}

        <div>

          <label className="text-sm font-semibold text-slate-700 mb-2 block">

            Trip No

          </label>

          <input

            value={tripNo}

            onChange={(e) =>

              setTripNo(e.target.value)

            }

            placeholder="Enter Trip Number..."

            className="w-full h-11 rounded-xl border border-slate-300 px-3 focus:border-green-600 focus:ring-2 focus:ring-green-100 outline-none"

          />

        </div>

      </div>

      {/* Buttons */}

      <div className="flex justify-end gap-3 mt-6">

        <button

          onClick={onReset}

          className="h-11 px-6 rounded-xl border border-slate-300 bg-white hover:bg-slate-50 flex items-center gap-2 font-medium"

        >

          <RotateCcw size={18} />

          Reset

        </button>

        <button

          onClick={onSearch}

          className="h-11 px-8 rounded-xl bg-green-600 hover:bg-green-700 text-white flex items-center gap-2 font-semibold shadow-sm"

        >

          <Search size={18} />

          Search

        </button>

      </div>

    </div>

  );

}