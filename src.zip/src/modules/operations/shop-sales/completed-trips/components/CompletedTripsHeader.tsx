import {
  ClipboardCheck,
  Truck,
  Store,
  Weight,
  Package
} from "lucide-react";

import type { Trip } from "../../../vehicle-trips/types/trip";

interface Props {

  trips: Trip[];

}

export default function CompletedTripsHeader({

  trips

}: Props) {

  const totalTrips = trips.length;

  const totalShops = trips.reduce(

    (sum, trip) =>

      sum + trip.totalShops,

    0

  );

  const totalBirds = trips.reduce(

    (sum, trip) =>

      sum + trip.totalBirds,

    0

  );

  const totalWeight = trips.reduce(

    (sum, trip) =>

      sum + trip.totalWeight,

    0

  );

  return (

    <div className="space-y-6">

      {/* =======================================
          Header
      ======================================== */}

      <div className="bg-white rounded-3xl border border-slate-200 shadow-sm">

        <div className="flex items-center justify-between px-8 py-7">

          <div className="flex items-center gap-5">

            <div className="w-16 h-16 rounded-2xl bg-orange-100 flex items-center justify-center">

              <ClipboardCheck

                className="text-orange-600"

                size={34}

              />

            </div>

            <div>

              <h1 className="text-3xl font-bold text-slate-800">

                Completed Trips Waiting for Rate Entry

              </h1>

              <p className="text-slate-500 mt-1">

                Completed operational trips awaiting Accounts rate approval.

              </p>

            </div>

          </div>

          <div className="text-right">

            <p className="text-sm text-slate-500">

              Pending Trips

            </p>

            <h2 className="text-5xl font-bold text-orange-600">

              {totalTrips}

            </h2>

          </div>

        </div>

      </div>

      {/* =======================================
          Summary Cards
      ======================================== */}

      <div className="grid grid-cols-4 gap-5">

        {/* Trips */}

        <SummaryCard

          icon={

            <Truck

              size={26}

              className="text-orange-600"

            />

          }

          title="Pending Trips"

          value={totalTrips.toLocaleString()}

          color="bg-orange-100"

        />

        {/* Shops */}

        <SummaryCard

          icon={

            <Store

              size={26}

              className="text-violet-600"

            />

          }

          title="Waiting Shops"

          value={totalShops.toLocaleString()}

          color="bg-violet-100"

        />

        {/* Birds */}

        <SummaryCard

          icon={

            <Package

              size={26}

              className="text-green-600"

            />

          }

          title="Total Birds"

          value={totalBirds.toLocaleString()}

          color="bg-green-100"

        />

        {/* Weight */}

        <SummaryCard

          icon={

            <Weight

              size={26}

              className="text-blue-600"

            />

          }

          title="Total Weight"

          value={`${totalWeight.toFixed(2)} KG`}

          color="bg-blue-100"

        />

      </div>

    </div>

  );

}

/* ==========================================
   Summary Card
========================================== */

interface CardProps {

  icon: React.ReactNode;

  title: string;

  value: string;

  color: string;

}

function SummaryCard({

  icon,

  title,

  value,

  color

}: CardProps) {

  return (

    <div className="bg-white rounded-2xl border border-slate-200 shadow-sm p-5">

      <div className="flex items-center gap-4">

        <div className={`w-14 h-14 rounded-xl flex items-center justify-center ${color}`}>

          {icon}

        </div>

        <div>

          <p className="text-sm text-slate-500">

            {title}

          </p>

          <h2 className="text-3xl font-bold text-slate-800">

            {value}

          </h2>

        </div>

      </div>

    </div>

  );

}