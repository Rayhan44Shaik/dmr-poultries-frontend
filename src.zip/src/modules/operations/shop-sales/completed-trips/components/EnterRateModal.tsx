import { useEffect, useMemo, useState } from "react";
import {
  X,
  Truck,
  CalendarDays
} from "lucide-react";

import type { Trip } from "../../../vehicle-trips/types/trip";

interface Props {

  open: boolean;

  trip: Trip | null;

  onClose: () => void;

  onSave: (

    deliveries: Trip["deliveries"]

  ) => void;

}

export default function EnterRateModal({

  open,

  trip,

  onClose,

  onSave

}: Props) {

  /* =====================================================
     Local Delivery State
  ===================================================== */

  const [

    deliveries,

    setDeliveries

  ] = useState<Trip["deliveries"]>([]);

  /* =====================================================
     Load Trip
  ===================================================== */

  useEffect(() => {

    if (!trip)
      return;

    setDeliveries(

      trip.deliveries.map(

        d => ({

          ...d,

          rate:

            (d as any).rate ?? null,

          amount:

            (d as any).amount ?? 0

        })

      )

    );

  }, [

    trip

  ]);

  /* =====================================================
     Totals
  ===================================================== */

  const totalBirds = useMemo(() => {

    return deliveries.reduce(

      (sum, row) =>

        sum + row.birds,

      0

    );

  }, [

    deliveries

  ]);

  const totalWeight = useMemo(() => {

    return deliveries.reduce(

      (sum, row) =>

        sum + row.weight,

      0

    );

  }, [

    deliveries

  ]);

  const grandAmount = useMemo(() => {

    return deliveries.reduce(

      (

        sum,

        row

      ) =>

        sum +

        ((row as any).amount || 0),

      0

    );

  }, [

    deliveries

  ]);
  /* =====================================================
   Save & Lock
===================================================== */

const canSave = useMemo(() => {

  return deliveries.every((row) => {

    const rate = (row as any).rate;

    return (

      rate !== null &&

      rate !== undefined &&

      rate >= 50 &&

      rate <= 300

    );

  });

}, [

  deliveries

]);

const handleSave = () => {

  if (!canSave) {

    alert(

      "Please enter a valid rate (₹50 - ₹300) for every shop."

    );

    return;

  }

  if (

    !window.confirm(

      "Save rates and lock this trip?\n\nAfter locking, this trip will move to Shop Sales Register."

    )

  )

    return;

  onSave(deliveries);

};
  /* =====================================================
     Hide
  ===================================================== */

  if (

    !open ||

    !trip

  )

    return null;

  return (

    <div className="fixed inset-0 z-50 bg-black/40 backdrop-blur-sm flex items-center justify-center p-6">

      {/* Modal */}

      <div className="bg-white rounded-3xl shadow-2xl w-full max-w-7xl overflow-hidden">

        {/* =================================================
            Header
        ================================================= */}

        <div className="flex items-center justify-between border-b px-8 py-6">

          <div>

            <h2 className="text-3xl font-bold text-slate-800">

              💰 Enter Selling Rates

            </h2>

            <p className="text-slate-500 mt-1">

              Enter shop-wise selling rates and lock this trip.

            </p>

          </div>

          <div className="flex items-center gap-6">

            <div className="text-right">

              <p className="text-xs uppercase tracking-wide text-slate-500">

                Trip Number

              </p>

              <p className="text-2xl font-bold text-green-700">

                {trip.tripNo}

              </p>

            </div>

            <button

              onClick={onClose}

              className="h-11 w-11 rounded-full bg-slate-100 hover:bg-red-100 transition flex items-center justify-center"

            >

              <X

                size={22}

                className="text-slate-700"

              />

            </button>

          </div>

        </div>

        {/* =================================================
            Trip Information
        ================================================= */}

        <div className="grid grid-cols-2 gap-6 px-8 py-5 border-b bg-slate-50">

          <div className="flex items-center gap-3">

            <div className="h-11 w-11 rounded-xl bg-blue-100 flex items-center justify-center">

              <Truck

                size={20}

                className="text-blue-700"

              />

            </div>

            <div>

              <p className="text-xs uppercase text-slate-500">

                Vehicle

              </p>

              <p className="font-semibold text-slate-800">

                {trip.vehicleNo}

              </p>

            </div>

          </div>

          <div className="flex items-center gap-3">

            <div className="h-11 w-11 rounded-xl bg-green-100 flex items-center justify-center">

              <CalendarDays

                size={20}

                className="text-green-700"

              />

            </div>

            <div>

              <p className="text-xs uppercase text-slate-500">

                Trip Date

              </p>

              <p className="font-semibold text-slate-800">

                {trip.tripDate}

              </p>

            </div>

          </div>

        </div>

        {/* =================================================
            Table
        ================================================= */}

        <div className="overflow-x-auto">

          <table className="min-w-full">

            <thead className="bg-slate-100 border-b">

              <tr className="text-slate-700">

                <th className="px-4 py-4 text-center">

                  S.No

                </th>

                <th className="px-4 py-4 text-left">

                  Shop Name

                </th>

                <th className="px-4 py-4 text-center">

                  Birds

                </th>

                <th className="px-4 py-4 text-center">

                  Weight (KG)

                </th>

                <th className="px-4 py-4 text-center bg-amber-50">

                  Rate (₹/KG)

                </th>

                <th className="px-4 py-4 text-center">

                  Amount

                </th>

              </tr>

            </thead>

<tbody>

{

deliveries.map((delivery, index) => {

const rate = (delivery as any).rate;

const amount = (delivery as any).amount ?? 0;

return (

<tr

key={delivery.id}

className="border-b hover:bg-amber-50 transition"

>

{/* S.No */}

<td className="text-center py-4">

{index + 1}

</td>

{/* Shop */}

<td className="px-4 py-4 font-semibold text-slate-700">

{delivery.shopName}

</td>

{/* Birds */}

<td className="text-center font-semibold text-blue-700">

{delivery.birds.toLocaleString()}

</td>

{/* Weight */}

<td className="text-center font-semibold text-orange-700">

{delivery.weight.toFixed(2)}

</td>

{/* =========================
Rate
========================= */}

<td className="bg-amber-50 px-4 py-3">

<div className="flex justify-center">

<div className="relative">

<span className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-500">

₹

</span>

<input

type="number"

min={50}

max={300}

step="0.01"

value={

rate ?? ""

}

placeholder="0.00"

onFocus={(e)=>{

e.target.select();

}}

onKeyDown={(e)=>{

if(e.key==="Enter"){

const next=document.getElementById(

`rate-${index+1}`

) as HTMLInputElement;

next?.focus();

}

}}

onChange={(e)=>{

const value=e.target.value;

const updated=[...deliveries];

(updated[index] as any).rate=

value===""?

null:

Number(value);

(updated[index] as any).amount=

value===""

?

0

:

Number(value)*delivery.weight;

setDeliveries(updated);

}}

id={`rate-${index}`}

className="

w-32

pl-8

pr-3

py-2

rounded-xl

border-2

border-amber-300

bg-white

text-right

font-semibold

outline-none

focus:border-green-600

focus:ring-4

focus:ring-green-100

transition

"

/>

</div>

</div>

{

rate==null &&(

<p className="text-center text-xs text-red-500 mt-1">

Required

</p>

)

}

</td>

{/* =========================
Amount
========================= */}

<td className="text-center">

<span

className="

inline-flex

items-center

justify-center

rounded-full

bg-green-100

text-green-700

font-bold

px-5

py-2

min-w-[140px]

"

>

₹

{

amount.toLocaleString(

undefined,

{

minimumFractionDigits:2,

maximumFractionDigits:2

}

)

}

</span>

</td>

</tr>

);

})

}

</tbody>

          </table>

        </div>

        {/* =================================================
            Footer Placeholder
        ================================================= */}

        <div className="border-t bg-slate-50 px-8 py-6">

          <div className="grid grid-cols-4 gap-5">

            <div className="rounded-2xl bg-white border p-5">

              <p className="text-sm text-slate-500">

                Total Shops

              </p>

              <h3 className="text-3xl font-bold mt-2">

                {deliveries.length}

              </h3>

            </div>

            <div className="rounded-2xl bg-white border p-5">

              <p className="text-sm text-slate-500">

                Total Birds

              </p>

              <h3 className="text-3xl font-bold mt-2">

                {totalBirds.toLocaleString()}

              </h3>

            </div>

            <div className="rounded-2xl bg-white border p-5">

              <p className="text-sm text-slate-500">

                Total Weight

              </p>

              <h3 className="text-3xl font-bold mt-2">

                {totalWeight.toFixed(2)} KG

              </h3>

            </div>

            <div className="rounded-2xl bg-green-50 border border-green-200 p-5">

              <p className="text-sm text-green-700">

                Grand Amount

              </p>

              <h3 className="text-3xl font-bold text-green-700 mt-2">

                ₹ {

grandAmount.toLocaleString(

undefined,

{

minimumFractionDigits:2,

maximumFractionDigits:2

}

)

}

              </h3>

            </div>

          </div>

          <div className="flex justify-end gap-4 mt-8">

            <button

              onClick={onClose}

              className="px-8 py-3 rounded-xl border font-semibold hover:bg-slate-100"

            >

              Cancel

            </button>

            <button

onClick={handleSave}

disabled={!canSave}

className={`

px-10

py-3

rounded-xl

font-semibold

transition

shadow

${

canSave

?

"bg-green-700 hover:bg-green-800 text-white"

:

"bg-slate-300 text-white cursor-not-allowed"

}

`}

>

🔒 Save & Lock Trip

</button>   

          </div>

        </div>

      </div>

    </div>

  );

}