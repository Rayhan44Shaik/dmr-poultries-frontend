import {
  DollarSign,
  Truck,
  Package,
  Weight,
  CalendarDays,
  User,
  Building2
} from "lucide-react";

import type { Trip } from "../../../vehicle-trips/types/trip";

interface Props {

  trips: Trip[];

  onEnterRate: (trip: Trip) => void;

}

export default function CompletedTripsTable({

  trips,

  onEnterRate

}: Props) {

  return (

    <div className="bg-white rounded-2xl border border-slate-200 shadow-sm overflow-hidden">

      {/* Header */}

      <div className="flex items-center justify-between px-6 py-5 border-b">

        <div>

          <h2 className="text-2xl font-bold text-slate-800">

            Trips Waiting for Rate Entry

          </h2>

          <p className="text-slate-500 text-sm mt-1">

            Completed trips awaiting Accounts approval.

          </p>

        </div>

        <div className="text-sm text-slate-500">

          Total Trips

          <span className="ml-2 font-bold text-orange-600">

            {trips.length}

          </span>

        </div>

      </div>

      <div className="overflow-x-auto">

        <table className="min-w-full">

          <thead className="sticky top-0 bg-slate-100 border-b">

            <tr className="text-slate-700 whitespace-nowrap">

              <th className="px-4 py-4 text-center">

                S.No

              </th>

              <th className="px-4 py-4 text-left">

                Trip No

              </th>

              <th className="px-4 py-4 text-left">

                Date

              </th>

              <th className="px-4 py-4 text-left">

                Vehicle

              </th>

              <th className="px-4 py-4 text-left">

                Supervisor

              </th>

              <th className="px-4 py-4 text-left">

                Farm

              </th>

              <th className="px-4 py-4 text-center">

                Shops

              </th>

              <th className="px-4 py-4 text-center">

                Birds

              </th>

              <th className="px-4 py-4 text-center">

                Weight

              </th>

              <th className="px-4 py-4 text-center">

                Action

              </th>

            </tr>

          </thead>

          <tbody>

            {

              trips.length === 0 ?

              (

                <tr>

                  <td

                    colSpan={10}

                    className="py-20 text-center"

                  >

                    <div className="flex flex-col items-center">

                      <DollarSign

                        size={48}

                        className="text-slate-300"

                      />

                      <h3 className="mt-4 text-xl font-semibold text-slate-500">

                        No Trips Waiting

                      </h3>

                      <p className="text-slate-400 mt-2">

                        All completed trips have already been processed.

                      </p>

                    </div>

                  </td>

                </tr>

              )

              :

              trips.map((trip, index) => (

                <tr

                  key={trip.id}

                  className="border-b hover:bg-orange-50 transition"

                >

                  {/* S.No */}

                  <td className="text-center px-4 py-4">

                    {index + 1}

                  </td>

                  {/* Trip */}

                  <td className="px-4 py-4">

                    <span className="font-bold text-green-700">

                      {trip.tripNo}

                    </span>

                  </td>

                  {/* Date */}

                  <td className="px-4 py-4">

                    <div className="flex items-center gap-2">

                      <CalendarDays

                        size={16}

                        className="text-slate-400"

                      />

                      {trip.tripDate}

                    </div>

                  </td>

                  {/* Vehicle */}

                  <td className="px-4 py-4">

                    <div className="flex items-center gap-2">

                      <Truck

                        size={16}

                        className="text-blue-600"

                      />

                      {trip.vehicleNo}

                    </div>

                  </td>

                  {/* Supervisor */}

                  <td className="px-4 py-4">

                    <div className="flex items-center gap-2">

                      <User

                        size={16}

                        className="text-violet-600"

                      />

                      {trip.supervisorName}

                    </div>

                  </td>

                  {/* Farm */}

                  <td className="px-4 py-4">

                    <div className="flex items-center gap-2">

                      <Building2

                        size={16}

                        className="text-green-600"

                      />

                      {trip.sourceFarm}

                    </div>

                  </td>

                  {/* Shops */}

                  <td className="text-center px-4 py-4">

                    <span className="inline-flex items-center justify-center rounded-full bg-violet-100 text-violet-700 px-4 py-1 font-semibold">

                      {trip.totalShops}

                    </span>

                  </td>

                  {/* Birds */}

                  <td className="text-center px-4 py-4">

                    <span className="inline-flex items-center justify-center rounded-full bg-blue-100 text-blue-700 px-4 py-1 font-semibold">

                      <Package

                        size={15}

                        className="mr-2"

                      />

                      {trip.totalBirds.toLocaleString()}

                    </span>

                  </td>

                  {/* Weight */}

                  <td className="text-center px-4 py-4">

                    <span className="inline-flex items-center justify-center rounded-full bg-orange-100 text-orange-700 px-4 py-1 font-semibold">

                      <Weight

                        size={15}

                        className="mr-2"

                      />

                      {trip.totalWeight.toFixed(2)}

                    </span>

                  </td>

                  {/* Action */}

                  <td className="text-center px-4 py-4">

                    <button

                      onClick={() =>

                        onEnterRate(trip)

                      }

                      className="inline-flex items-center gap-2 rounded-xl bg-green-600 hover:bg-green-700 text-white px-5 py-2 font-semibold shadow"

                    >

                      <DollarSign size={18} />

                      Enter Rates

                    </button>

                  </td>

                </tr>

              ))

            }

          </tbody>

        </table>

      </div>

    </div>

  );

}