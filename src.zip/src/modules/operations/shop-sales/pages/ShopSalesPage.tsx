import DashboardLayout from "../../../../layouts/DashboardLayout/DashboardLayout";

import useShopSales from "../hooks/useShopSales";

import ShopSalesHeader from "../components/ShopSalesHeader";
import ShopSalesFilters from "../components/ShopSalesFilters";
import ShopSalesSummary from "../components/ShopSalesSummary";
import ShopSalesTable from "../components/ShopSalesTable";
import ShopSalesPagination from "../components/ShopSalesPagination";
export default function ShopSalesPage() {

  const {

    paginatedSales,

    filteredSales,

    summary,

    shopNames,

    filter,

    setFilter,

    resetFilters,

    currentPage,

    totalPages,

    setCurrentPage

  } = useShopSales();

  /* ===========================
     Search
  =========================== */

  const handleSearch = () => {

    setCurrentPage(1);

  };

  /* ===========================
     Export
  =========================== */



  return (

    <DashboardLayout>

      <div className="space-y-6">

        {/* Header */}

        <ShopSalesHeader

          totalRecords={filteredSales.length}

        />

        {/* Filters */}

        <div className="flex justify-between gap-4">

          <div className="flex-1">

            <ShopSalesFilters

              totalEntries={filteredSales.length}
              fromDate={filter.fromDate}

              toDate={filter.toDate}

              shopName={filter.shopName}

              sortBy={filter.sortBy}

              shopNames={shopNames}

              setFromDate={(v) =>

                setFilter({

                  ...filter,

                  fromDate: v

                })

              }

              setToDate={(v) =>

                setFilter({

                  ...filter,

                  toDate: v

                })

              }

              setShopName={(v) =>

                setFilter({

                  ...filter,

                  shopName: v

                })

              }

              setSortBy={(v) =>

                setFilter({

                  ...filter,

                  sortBy: v

                })

              }

              onSearch={handleSearch}

              onReset={resetFilters}

            />

          </div>


        </div>

        

        {/* Table */}

        <ShopSalesTable

          sales={paginatedSales}


        />

        {/* Pagination */}

        <ShopSalesPagination

          currentPage={currentPage}

          totalPages={totalPages}

          onPageChange={setCurrentPage}

        />

        {/* Summary */}

        <ShopSalesSummary

          summary={summary}

          fromDate={filter.fromDate}

          toDate={filter.toDate}

          shopName={filter.shopName}

        />
      </div>

    </DashboardLayout>

  );

}