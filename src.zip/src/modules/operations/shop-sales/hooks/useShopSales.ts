import { useMemo, useState } from "react";

import type {
  ShopSale,
  ShopSaleFilter
} from "../types/shopSale";

import { shopSalesService } from "../services/shopSalesService";

import {
  calculateSummary
} from "../utils/shopSaleCalculation";

export default function useShopSales() {

  /* ===========================
     Load Shop Sales
  =========================== */

  const [sales] = useState<ShopSale[]>(

    shopSalesService.getAll()


  );

  /* ===========================
     Filters
  =========================== */

  const [filter, setFilter] = useState<ShopSaleFilter>({

    fromDate: "",

    toDate: "",

    shopName: "",

    sortBy: "Newest"

  });

  /* ===========================
     Pagination
  =========================== */

  const [currentPage, setCurrentPage] = useState(1);

  const pageSize = 25;

  /* ===========================
     Shop Names
  =========================== */

  const shopNames = useMemo(() => {

    return [

      ...new Set(

        sales.map(x => x.shopName)

      )

    ].sort();

  }, [sales]);

  /* ===========================
     Filtering
  =========================== */

  const filteredSales = useMemo(() => {

    let data = [...sales];

    if (filter.fromDate) {

      data = data.filter(

        x => x.tripDate >= filter.fromDate

      );

    }

    if (filter.toDate) {

      data = data.filter(

        x => x.tripDate <= filter.toDate

      );

    }

    if (filter.shopName.trim() !== "") {

      data = data.filter(

        x =>

          x.shopName

            .toLowerCase()

            .includes(

              filter.shopName.toLowerCase()

            )

      );

    }

    switch (filter.sortBy) {

      case "Amount":

        data.sort(

          (a, b) =>

            (b.amount ?? 0) -

            (a.amount ?? 0)

        );

        break;

      case "Weight":

        data.sort(

          (a, b) =>

            b.totalWeight -

            a.totalWeight

        );

        break;

      case "Birds":

        data.sort(

          (a, b) =>

            b.totalBirds -

            a.totalBirds

        );

        break;

      default:

        data.sort(

          (a, b) =>

            new Date(b.tripDate).getTime()

            -

            new Date(a.tripDate).getTime()

        );

    }

    return data;

  }, [sales, filter]);

  /* ===========================
     Pagination
  =========================== */

  const totalPages = Math.max(

    1,

    Math.ceil(

      filteredSales.length /

      pageSize

    )

  );

  const paginatedSales = useMemo(() => {

    const start =

      (currentPage - 1) *

      pageSize;

    return filteredSales.slice(

      start,

      start + pageSize

    );

  }, [

    filteredSales,

    currentPage

  ]);

  /* ===========================
     Summary
  =========================== */

  const summary = useMemo(

    () =>

      calculateSummary(

        filteredSales

      ),

    [filteredSales]

  );


  /* ===========================
     Reset Filters
  =========================== */

  function resetFilters() {

    setFilter({

      fromDate: "",

      toDate: "",

      shopName: "",

      sortBy: "Newest"

    });

    setCurrentPage(1);

  }

  /* ===========================
     Return
  =========================== */

  return {

    sales,

    filteredSales,

    paginatedSales,

    summary,

    filter,

    setFilter,

    shopNames,

    currentPage,

    setCurrentPage,

    totalPages,

    resetFilters

  };

}