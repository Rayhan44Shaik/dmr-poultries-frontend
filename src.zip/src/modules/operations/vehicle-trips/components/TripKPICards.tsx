import {
  Truck,
  Bird,
  Scale,
  HeartPulse,
  Store
} from "lucide-react";

interface Props {

  totalTrips: number;

  totalBirds: number;

  totalWeight: number;

  totalMortality: number;

  totalShops: number;

}

export default function TripKPICards({

  totalTrips,

  totalBirds,

  totalWeight,

  totalMortality,

  totalShops

}: Props) {

  const cards = [

    {
      title: "Total Trips",
      value: totalTrips.toLocaleString(),
      icon: <Truck size={28} />,
      bg: "bg-blue-50",
      iconBg: "bg-blue-100",
      text: "text-blue-700"
    },

    {
      title: "Total Birds",
      value: totalBirds.toLocaleString(),
      icon: <Bird size={28} />,
      bg: "bg-green-50",
      iconBg: "bg-green-100",
      text: "text-green-700"
    },

    {
      title: "Total Weight (KG)",
      value: totalWeight.toFixed(2),
      icon: <Scale size={28} />,
      bg: "bg-purple-50",
      iconBg: "bg-purple-100",
      text: "text-purple-700"
    },

    {
      title: "Total Mortality",
      value: totalMortality.toLocaleString(),
      icon: <HeartPulse size={28} />,
      bg: "bg-red-50",
      iconBg: "bg-red-100",
      text: "text-red-600"
    },

    {
      title: "Total Shops",
      value: totalShops.toLocaleString(),
      icon: <Store size={28} />,
      bg: "bg-orange-50",
      iconBg: "bg-orange-100",
      text: "text-orange-600"
    }

  ];

  return (

    <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-5 gap-5">

      {cards.map(card => (

        <div

          key={card.title}

          className={`${card.bg} rounded-2xl border border-slate-200 shadow-sm px-6 py-5 flex items-center justify-between hover:shadow-md transition-all`}

        >

          <div>

            <div className="text-sm text-slate-500 font-medium">

              {card.title}

            </div>

            <div className={`text-3xl font-bold mt-2 ${card.text}`}>

              {card.value}

            </div>

          </div>

          <div

            className={`h-14 w-14 rounded-xl flex items-center justify-center ${card.iconBg} ${card.text}`}

          >

            {card.icon}

          </div>

        </div>

      ))}

    </div>

  );

}