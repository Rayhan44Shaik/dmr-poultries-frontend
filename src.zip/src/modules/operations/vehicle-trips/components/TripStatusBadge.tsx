interface Props {
  status: "Pending" | "Completed" | "In Progress";
}

export default function TripStatusBadge({
  status,
}: Props) {

  if (status === "Completed") {
    return (
      <span className="px-3 py-1 rounded-full bg-green-100 text-green-700 text-xs font-semibold">
        Completed
      </span>
    );
  }

  if (status === "In Progress") {
    return (
      <span className="px-3 py-1 rounded-full bg-blue-100 text-blue-700 text-xs font-semibold">
        In Progress
      </span>
    );
  }

  return (
    <span className="px-3 py-1 rounded-full bg-yellow-100 text-yellow-700 text-xs font-semibold">
      Pending
    </span>
  );
}