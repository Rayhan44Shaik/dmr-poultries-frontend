import Select from "react-select";

interface Props {

  fromDate: string;
  toDate: string;

  vehicle: string;
  supervisor: string;
  farm: string;

  search: string;

  setFromDate: (v: string) => void;
  setToDate: (v: string) => void;

  setVehicle: (v: string) => void;
  setSupervisor: (v: string) => void;
  setFarm: (v: string) => void;

  setSearch: (v: string) => void;

  onSearch: () => void;
  onReset: () => void;

  vehicles: string[];
  supervisors: string[];
  farms: string[];

}

export default function TripFilters({

  fromDate,
  toDate,

  vehicle,
  supervisor,
  farm,

  search,

  setFromDate,
  setToDate,

  setVehicle,
  setSupervisor,
  setFarm,

  setSearch,

  onSearch,
  onReset,

  vehicles,
  supervisors,
  farms

}: Props) {

  const vehicleOptions = [

    {
      value: "All",
      label: "All Vehicles"
    },

    ...vehicles.map(v => ({

      value: v,
      label: v

    }))

  ];

  const supervisorOptions = [

    {
      value: "All",
      label: "All Supervisors"
    },

    ...supervisors.map(v => ({

      value: v,
      label: v

    }))

  ];

  const farmOptions = [

    {
      value: "All",
      label: "All Sources"
    },

    ...farms.map(v => ({

      value: v,
      label: v

    }))

  ];

  return (

    <div className="bg-white rounded-2xl border border-slate-200 shadow-sm p-6">

      <div className="grid grid-cols-1 md:grid-cols-12 gap-5">

        {/* From Date */}

        <div className="md:col-span-2">

          <label className="text-sm font-semibold text-slate-700 mb-2 block">

            From Date

          </label>

          <input

            type="date"

            value={fromDate}

            onChange={(e) => setFromDate(e.target.value)}

            className="w-full rounded-xl border border-slate-300 px-3 py-2"

          />

        </div>

        {/* To Date */}

        <div className="md:col-span-2">

          <label className="text-sm font-semibold text-slate-700 mb-2 block">

            To Date

          </label>

          <input

            type="date"

            value={toDate}

            onChange={(e) => setToDate(e.target.value)}

            className="w-full rounded-xl border border-slate-300 px-3 py-2"

          />

        </div>

        {/* Vehicle */}

        <div className="md:col-span-3">

          <label className="text-sm font-semibold text-slate-700 mb-2 block">

            Vehicle

          </label>

          <Select

            options={vehicleOptions}

            value={vehicleOptions.find(x => x.value === vehicle)}

            onChange={(e) =>

              setVehicle(e?.value || "All")

            }

            isSearchable

            placeholder="Search Vehicle..."

          />

        </div>

        {/* Supervisor */}

        <div className="md:col-span-3">

          <label className="text-sm font-semibold text-slate-700 mb-2 block">

            Supervisor

          </label>

          <Select

            options={supervisorOptions}

            value={supervisorOptions.find(x => x.value === supervisor)}

            onChange={(e) =>

              setSupervisor(e?.value || "All")

            }

            isSearchable

            placeholder="Search Supervisor..."

          />

        </div>

        {/* Farm */}

        <div className="md:col-span-2">

          <label className="text-sm font-semibold text-slate-700 mb-2 block">

            From (Source)

          </label>

          <Select

            options={farmOptions}

            value={farmOptions.find(x => x.value === farm)}

            onChange={(e) =>

              setFarm(e?.value || "All")

            }

            isSearchable

            placeholder="Search Farm..."

          />

        </div>

        {/* Search */}

        <div className="md:col-span-8">

          <label className="text-sm font-semibold text-slate-700 mb-2 block">

            Search

          </label>

          <input

            value={search}

            placeholder="Trip No / Vehicle / Supervisor / Farm"

            onChange={(e) => setSearch(e.target.value)}

            className="w-full rounded-xl border border-slate-300 px-4 py-2"

          />

        </div>

        {/* Buttons */}

        <div className="md:col-span-4 flex items-end gap-3">

          <button

            onClick={onSearch}

            className="flex-1 rounded-xl bg-green-700 py-2.5 font-semibold text-white hover:bg-green-800 transition"

          >

            Search

          </button>

          <button

            onClick={onReset}

            className="flex-1 rounded-xl border border-slate-300 py-2.5 font-semibold hover:bg-slate-100 transition"

          >

            Reset

          </button>

        </div>

      </div>

    </div>

  );

}