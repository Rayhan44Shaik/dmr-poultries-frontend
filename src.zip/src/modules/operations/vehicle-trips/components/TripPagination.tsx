interface Props {

  currentPage: number;

  totalPages: number;

  onPageChange: (page: number) => void;

}

export default function TripPagination({

  currentPage,

  totalPages,

  onPageChange

}: Props) {

  if (totalPages <= 1)
    return null;

  return (

    <div className="bg-white border border-slate-200 rounded-2xl shadow-sm p-5">

      <div className="flex justify-between items-center">

        <button

          onClick={() => onPageChange(currentPage - 1)}

          disabled={currentPage === 1}

          className="px-5 py-2 rounded-xl border disabled:opacity-40 hover:bg-slate-100"

        >

          Previous

        </button>

        <div className="flex items-center gap-2">

          {

            Array.from(

              { length: totalPages },

              (_, index) => (

                <button

                  key={index}

                  onClick={() =>

                    onPageChange(index + 1)

                  }

                  className={`

                    h-10

                    w-10

                    rounded-xl

                    font-semibold

                    transition

                    ${

                      currentPage === index + 1

                        ? "bg-green-700 text-white"

                        : "border hover:bg-slate-100"

                    }

                  `}

                >

                  {index + 1}

                </button>

              )

            )

          }

        </div>

        <button

          onClick={() => onPageChange(currentPage + 1)}

          disabled={currentPage === totalPages}

          className="px-5 py-2 rounded-xl border disabled:opacity-40 hover:bg-slate-100"

        >

          Next

        </button>

      </div>

    </div>

  );

}