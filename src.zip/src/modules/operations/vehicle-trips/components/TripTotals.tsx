import {
  Store,
  Bird,
  Scale,
  Heart
} from "lucide-react";

import type { ShopDelivery } from "../types/trip";

interface Props {
  rows: ShopDelivery[];
}

export default function TripTotals({ rows }: Props) {

  const totalShops = rows.length;

  const totalBirds = rows.reduce(
    (sum, row) => sum + Number(row.birds || 0),
    0
  );

  const totalWeight = rows.reduce(
    (sum, row) => sum + Number(row.weight || 0),
    0
  );

  const totalMortality = rows.reduce(
    (sum, row) => sum + Number(row.mortality || 0),
    0
  );

  const cards = [
    {
      title: "Total Shops",
      value: totalShops,
      icon: <Store size={28} />,
      bg: "bg-blue-50",
      border: "border-blue-200",
      iconBg: "bg-blue-100",
      text: "text-blue-700"
    },
    {
      title: "Total Birds",
      value: totalBirds,
      icon: <Bird size={28} />,
      bg: "bg-green-50",
      border: "border-green-200",
      iconBg: "bg-green-100",
      text: "text-green-700"
    },
    {
      title: "Total Weight (Kg)",
      value: totalWeight.toFixed(2),
      icon: <Scale size={28} />,
      bg: "bg-orange-50",
      border: "border-orange-200",
      iconBg: "bg-orange-100",
      text: "text-orange-700"
    },
    {
      title: "Mortality",
      value: totalMortality,
      icon: <Heart size={28} fill="currentColor" />,
      bg: "bg-emerald-50",
      border: "border-emerald-200",
      iconBg: "bg-emerald-100",
      text: "text-emerald-700"
    }
  ];

  return (
    <div className="grid grid-cols-1 sm:grid-cols-2 xl:grid-cols-4 gap-5 mt-6">

      {cards.map(card => (

        <div
          key={card.title}
          className={`${card.bg} ${card.border} border rounded-2xl shadow-sm p-5 flex items-center justify-between hover:shadow-md transition-all`}
        >

          <div>

            <p className="text-sm font-medium text-slate-500">
              {card.title}
            </p>

            <h2 className={`text-3xl font-bold mt-2 ${card.text}`}>
              {card.value}
            </h2>

          </div>

          <div
            className={`${card.iconBg} h-16 w-16 rounded-2xl flex items-center justify-center ${card.text}`}
          >
            {card.icon}
          </div>

        </div>

      ))}

    </div>
  );

}