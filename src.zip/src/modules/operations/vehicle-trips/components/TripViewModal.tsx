import type { Trip } from "../types/trip";

interface Props {

  open: boolean;

  trip: Trip | null;

  onClose: () => void;

}

export default function TripViewModal({

  open,

  trip,

  onClose,

}: Props) {

  if (!open || !trip)
  return null;

  return (

    <div className="p-6">

      {/* Trip Summary */}

      <div className="grid grid-cols-2 gap-6 mb-8">

        <div className="space-y-3">

          <div className="flex justify-between border-b pb-2">
            <span className="font-medium text-slate-500">Trip No</span>
            <span className="font-semibold">{trip.tripNo}</span>
          </div>

          <div className="flex justify-between border-b pb-2">
            <span className="font-medium text-slate-500">Trip Date</span>
            <span>{trip.tripDate}</span>
          </div>

          <div className="flex justify-between border-b pb-2">
            <span className="font-medium text-slate-500">Supervisor</span>
            <span>{trip.supervisorName}</span>
          </div>

          <div className="flex justify-between border-b pb-2">
            <span className="font-medium text-slate-500">Opening KM</span>
            <span>{trip.openingMeter}</span>
          </div>

          <div className="flex justify-between border-b pb-2">
            <span className="font-medium text-slate-500">Total KM</span>
            <span>{trip.totalKm}</span>
          </div>

          <div className="flex justify-between border-b pb-2">
            <span className="font-medium text-slate-500">Expense</span>
            <span>₹ {trip.expense}</span>
          </div>

        </div>

        <div className="space-y-3">

          <div className="flex justify-between border-b pb-2">
            <span className="font-medium text-slate-500">Vehicle</span>
            <span>{trip.vehicleNo}</span>
          </div>

          <div className="flex justify-between border-b pb-2">
            <span className="font-medium text-slate-500">Driver</span>
            <span>{trip.driverName}</span>
          </div>

          <div className="flex justify-between border-b pb-2">
            <span className="font-medium text-slate-500">Source Farm</span>
            <span>{trip.sourceFarm}</span>
          </div>

          <div className="flex justify-between border-b pb-2">
            <span className="font-medium text-slate-500">Closing KM</span>
            <span>{trip.closingMeter}</span>
          </div>

          <div className="flex justify-between border-b pb-2">
            <span className="font-medium text-slate-500">Fuel</span>
            <span>{trip.fuel} Ltrs</span>
          </div>

          <div className="flex justify-between border-b pb-2">
            <span className="font-medium text-slate-500">Status</span>
            <span>{trip.status}</span>
          </div>

        </div>

      </div>

      {/* Remarks */}

      <div className="border rounded-xl p-4 bg-slate-50 mb-8">

        <div className="font-semibold mb-2">
          Remarks
        </div>

        <div className="text-slate-700">
          {trip.remarks || "--"}
        </div>

      </div>

      {/* Shop Table */}

      <div className="overflow-x-auto">

        <table className="min-w-full border">

          <thead className="bg-slate-100">

            <tr>

              <th className="px-3 py-3">Box</th>

              <th className="px-3 py-3 text-left min-w-[280px]">
                Shop Name
              </th>

              <th className="px-3 py-3 text-right">
                Birds
              </th>

              <th className="px-3 py-3 text-right">
                Weight (KG)
              </th>

              <th className="px-3 py-3 text-right">
                Mortality
              </th>

              <th className="px-3 py-3 text-left">
                Remarks
              </th>

            </tr>

          </thead>

          <tbody>

            {trip.deliveries.map((row, index) => (

              <tr
                key={index}
                className="border-t"
              >

                <td className="px-3 py-3 text-center">
                  {row.boxNo}
                </td>

                <td className="px-3 py-3">
                  {row.shopName}
                </td>

                <td className="px-3 py-3 text-right">
                  {row.birds}
                </td>

                <td className="px-3 py-3 text-right">
                  {row.weight.toFixed(2)}
                </td>

                <td className="px-3 py-3 text-right">
                  {row.mortality}
                </td>

                <td className="px-3 py-3">
                  {row.remarks || "--"}
                </td>

              </tr>

            ))}

          </tbody>

          <tfoot className="bg-slate-50 font-semibold">

            <tr>

              <td
                colSpan={6}
                className="px-5 py-4"
              >

                <div className="flex justify-around">

                  <span>
                    Total Shops :
                    <b> {trip.totalShops}</b>
                  </span>

                  <span>
                    Birds :
                    <b> {trip.totalBirds}</b>
                  </span>

                  <span>
                    Weight :
                    <b> {trip.totalWeight.toFixed(2)} KG</b>
                  </span>

                  <span>
                    Mortality :
                    <b> {trip.totalMortality}</b>
                  </span>
                <div className="mt-8 flex justify-end">

  <button

    onClick={onClose}

    className="px-6 py-2 rounded-xl bg-green-700 hover:bg-green-800 text-white"

  >

    Close

  </button>

</div>
                </div>

              </td>

            </tr>

          </tfoot>

        </table>

      </div>

    </div>

  );

}