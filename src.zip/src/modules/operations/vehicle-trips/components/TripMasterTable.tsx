import {
  Eye,
  Pencil,
  Trash2,
  Heart
} from "lucide-react";

import type { Trip } from "../types/trip";
interface Props{

trips: Trip[];

onView:(trip:Trip)=>void;

onEdit:(trip:Trip)=>void;

onDelete:(trip:Trip)=>void;

onStatusChange:(

trip:Trip,

status:"Pending"|"Completed"

)=>void;

}

export default function TripMasterTable({

  trips,

  onView,

  onEdit,

  onDelete,

  onStatusChange

}: Props) {

  return (

    <div className="bg-white rounded-2xl border border-slate-200 shadow-sm overflow-hidden">

      <div className="overflow-x-auto">

        <table className="min-w-full text-sm">

          <thead className="sticky top-0 bg-slate-100 border-b z-20">

            <tr className="text-slate-700 whitespace-nowrap">

              <th className="px-4 py-4 text-center">

                S.No

              </th>

              <th className="px-4 py-4 text-left">

                Trip No

              </th>

              <th className="px-4 py-4 text-left">

                Date

              </th>

              <th className="px-4 py-4 text-left">

                Vehicle

              </th>

              <th className="px-4 py-4 text-left">

                Driver

              </th>

              <th className="px-4 py-4 text-left">

                Supervisor

              </th>

              <th className="px-4 py-4 text-left">

                Source Farm

              </th>

              <th className="px-4 py-4 text-left">

                Last Shop

              </th>

              <th className="px-4 py-4 text-center">

                Shops

              </th>

              <th className="px-4 py-4 text-center">

                Birds

              </th>

              <th className="px-4 py-4 text-center">

                Weight (KG)

              </th>

              <th className="px-4 py-4 text-center">

                <div className="flex justify-center items-center gap-2">

                  <Heart

                    size={15}

                    className="fill-red-500 text-red-500"

                  />

                  Mortality

                </div>

              </th>

              <th className="px-4 py-4 text-center">

                Status

              </th>

              <th className="px-4 py-4 text-center">

                View

              </th>

              <th className="px-4 py-4 text-center">

                Edit

              </th>

              <th className="px-4 py-4 text-center">

                Delete

              </th>

            </tr>

          </thead>

          <tbody>

            {

              trips.length === 0 ? (

                <tr>

                  <td

                    colSpan={16}

                    className="py-14 text-center text-slate-400"

                  >

                  <div className="py-10">

  <div className="text-5xl mb-4">

    🚚

  </div>

  <div className="text-lg font-semibold">

    No Vehicle Trips Found

  </div>

  <div className="text-slate-400 mt-2">

    Create a new trip from Vehicle Trip Entry.

  </div>

</div>

                  </td>

                </tr>

              ) : (

                trips.map((trip, index) => (

                  <tr

  key={trip.id}

  className={`

    border-t

    transition-all

    ${index % 2 === 0

      ? "bg-white"

      : "bg-slate-50/40"}

    hover:bg-green-50

  `}

>

                    {/* S.No */}

                    <td className="px-4 py-4 text-center">

                      {index + 1}

                    </td>

                    {/* Trip No */}

                    <td className="px-4 py-4">

  <span className="font-bold tracking-wide text-green-700">

    {trip.tripNo}

  </span>

</td>

                    {/* Date */}

                    <td className="px-4 py-4">

                      {trip.tripDate}

                    </td>

                    {/* Vehicle */}

                    <td className="px-4 py-4 font-medium text-slate-700">

  🚚 {trip.vehicleNo}

</td>

                    {/* Driver */}

                    <td className="px-4 py-4">

                      {trip.driverName}

                    </td>

                    {/* Supervisor */}

                    <td className="px-4 py-4">

                      {trip.supervisorName}

                    </td>

                    {/* Source Farm */}

                    <td className="px-4 py-4">

                      {trip.sourceFarm}

                    </td>

                    {/* Last Shop */}

                    <td className="px-4 py-4">

                      {

                        trip.deliveries.length > 0

                          ? trip.deliveries[trip.deliveries.length - 1].shopName

                          : "--"

                      }

                    </td>

                    {/* Shops */}

                    <td className="px-4 py-4 text-center font-semibold">

                      {trip.totalShops}

                    </td>

                    {/* Birds */}

                    <td className="px-4 py-4 text-center">

  <span className="rounded-full bg-blue-100 px-3 py-1 font-semibold text-blue-700">

    {trip.totalBirds.toLocaleString()}

  </span>

</td>

                    {/* Weight */}

                    <td className="px-4 py-4 text-center font-semibold text-orange-600">

                      {trip.totalWeight.toFixed(2)} KG's

                    </td>

                    {/* Mortality */}

                    <td className="px-4 py-4 text-center">

  <span className="rounded-full bg-red-100 px-3 py-1 font-semibold text-red-600">

    {trip.totalMortality}

  </span>

</td>

                    {/* Status */}

<td className="px-4 py-4">

  <div className="flex justify-center">

    <select
    
      value={trip.status}
      onChange={(e) =>
        onStatusChange(
          trip,
          e.target.value as "Pending" | "Completed"
        )
      }
      className={`

        appearance-none

        cursor-pointer

        rounded-full

        px-10

        py-2

        pr-8

        text-sm

        font-semibold

        border

        shadow-sm

        transition-all

        duration-200

        focus:outline-none

        focus:ring-2

        ${
          trip.status === "Completed"

            ? "bg-green-50 text-green-700 border-green-300 focus:ring-green-200"

            : "bg-yellow-50 text-yellow-700 border-yellow-300 focus:ring-yellow-200"

        }

      `}
    >

      <option value="Pending">

        🟡 Pending

      </option>

      <option value="Completed">

        🟢 Completed

      </option>

    </select>

  </div>

</td>


                                        {/* View */}

                    <td className="text-center">

                      <button

                        onClick={() => onView(trip)}

                        className="h-9 w-9 rounded-lg bg-blue-50 hover:bg-blue-100 flex items-center justify-center mx-auto transition"

                      >

                        <Eye

                          size={18}

                          className="text-blue-700"

                        />

                      </button>

                    </td>

                    {/* Edit */}

                    <td className="text-center">

                      <button

                        onClick={() => onEdit(trip)}

                        className="h-9 w-9 rounded-full bg-green-50 hover:bg-green-100 flex items-center justify-center mx-auto transition"

                      >

                        <Pencil

                          size={18}

                          className="text-green-700"

                        />

                      </button>

                    </td>

                    {/* Delete */}

                    <td className="text-center">

                      <button

                        onClick={() => {

                          if (

                            window.confirm(

                              `Delete Trip ${trip.tripNo}?`

                            )

                          ) {

                            onDelete(trip);

                          }

                        }}

                        className="h-9 w-9 rounded-full bg-red-50 hover:bg-red-100 flex items-center justify-center mx-auto transition"

                      >

                        <Trash2

                          size={18}

                          className="text-red-600"

                        />

                      </button>

                    </td>

                  </tr>

                ))

              )

            }

          </tbody>

        </table>

      </div>

    </div>

  );

}  