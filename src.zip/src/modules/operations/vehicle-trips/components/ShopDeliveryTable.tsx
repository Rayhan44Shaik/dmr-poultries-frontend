import {
  Store,
  Plus,
  Trash2
} from "lucide-react";

import Select from "react-select";

import type { ShopDelivery } from "../types/trip";

interface Props {

  rows: ShopDelivery[];

  setRows: React.Dispatch<
    React.SetStateAction<ShopDelivery[]>
  >;

  shops: any[];

  birdTypes: any[];

}

export default function ShopDeliveryTable({

  rows,

  setRows,

  shops,

  birdTypes

}: Props) {

  const addRow = () => {

    setRows([

      ...rows,

      {

  id: Date.now(),

  shopId: 0,

  boxNo: 0,

  shopName: "",

  birdTypeId: 0,

  birdType: "",

  birds: 0,

  weight: 0,

  mortality: 0,

  rate: null,

  amount: 0,

  remarks: ""

}

    ]);

  };

  const updateRow = (

    id: number,

    field: keyof ShopDelivery,

    value: any

  ) => {

    setRows(

      rows.map((r) =>

        r.id === id

          ? {

              ...r,

              [field]: value

            }

          : r

      )

    );

  };

  const deleteRow = (id: number) => {

  setRows(
    rows.filter(x => x.id !== id)
  );

};

  return (

    <div className="bg-white rounded-2xl border border-slate-200 shadow-sm overflow-hidden mt-8">

      {/* Header */}

<div className="flex items-center justify-between px-6 py-5 border-b">

  <div className="flex items-center gap-3">

    <div className="h-12 w-12 rounded-xl bg-green-100 flex items-center justify-center">

      <Store className="w-6 h-6 text-green-700" />

    </div>

    <div>

      <h2 className="text-2xl font-semibold text-slate-800">
        Shops Delivered in this Trip
      </h2>

      <p className="text-slate-500 text-sm">
        Add all delivery shops for this trip
      </p>

    </div>

  </div>

  <button
    onClick={addRow}
    className="bg-green-700 hover:bg-green-800 text-white px-5 py-3 rounded-xl flex items-center gap-2 font-medium"
  >

    <Plus size={18} />

    Add Shop

  </button>

</div>

      <div className="overflow-x-auto">

        <table className="w-full text-sm">

          <thead className="bg-slate-50">

            <tr className="text-slate-700">

              <th className="px-4 py-4 text-center">

                S.No <span className="text-red-500">*</span>

              </th>

              <th className="px-4 py-4 text-center">

                Box No <span className="text-red-500">*</span>

              </th>

              <th className="px-4 py-4">

                Shop Name <span className="text-red-500">*</span>

              </th>

              <th className="px-4 py-4">

                Bird Type <span className="text-red-500">*</span>

              </th>

              <th className="px-4 py-4 text-center">

                No. of Birds <span className="text-red-500">*</span>

              </th>

              <th className="px-4 py-4 text-center">

                No. of Kg's <span className="text-red-500">*</span>

              </th>

            <th className="px-4 py-3 text-center">
  Mortality <span className="text-red-500">*</span>
</th>

              <th className="px-4 py-4">

                Remarks

              </th>

              <th className="px-4 py-4 text-center">
  Action
</th>

            </tr>

          </thead>

          <tbody>

            {
              rows.length === 0 && (

                <tr>

                  <td

                    colSpan={9}

                    className="text-center py-10 text-slate-400"

                  >

                    No shops added yet.

                    Click

                    <b> Add Shop </b>

                    to begin.

                  </td>

                </tr>

              )
            }

            {rows.map((row,index)=>(
                            <tr
                key={row.id}
                className="border-t hover:bg-slate-50 transition-colors"
              >

                {/* S.No */}

                <td className="px-4 py-3 text-center font-medium">
                  {index + 1}
                </td>

                {/* Box No */}

                <td className="px-4 py-3 text-center">

                  <input
                    type="number"
                    value={row.boxNo}
                    onChange={(e)=>
                      updateRow(
                        row.id,
                        "boxNo",
                        Number(e.target.value)
                      )
                    }
                    className="w-20 border rounded-lg px-2 py-2 text-center"
                  />

                </td>

                {/* Shop */}

<td className="px-4 py-3 min-w-[320px]">

  <Select
    menuPortalTarget={document.body}
    menuPosition="fixed"
    menuPlacement="auto"
    maxMenuHeight={250}
    
    value={
      row.shopId
        ? {
            value: row.shopId,
            label: row.shopName
          }
        : null
    }

    options={shops.map((shop: any) => ({
      value: shop.id,
      label: shop.shopName
    }))}

    placeholder="Search Shop..."

    isSearchable

    className="min-w-[300px]"

    onChange={(selected: any) => {

      if (!selected) return;

      setRows(prev =>
        prev.map(r =>
          r.id === row.id
            ? {
                ...r,
                shopId: selected.value,
                shopName: selected.label
              }
            : r
        )
      );

    }}

    styles={{
      control: (base) => ({
        ...base,
        minHeight: 42,
        borderRadius: 12
      })
    }}

  />

</td>

                {/* Bird */}

                <td className="px-4 py-3 min-w-[220px]">

                  <select
                    value={row.birdTypeId}
                    className="w-full border rounded-xl px-3 py-2"
                    onChange={(e)=>{

                      const bird=birdTypes.find(
                        (x:any)=>
                          x.id===Number(e.target.value)
                      );

                      if(!bird) return;

                      setRows(
  rows.map(r =>
    r.id === row.id
      ? {
          ...r,
          birdTypeId: bird.id,
          birdType: bird.birdType
        }
      : r
  )
);

                    }}
                  >

                    <option value={0}>
                      Select Bird Type
                    </option>

                    {birdTypes.map((bird:any)=>(

                      <option
                        key={bird.id}
                        value={bird.id}
                      >
                        {bird.birdType}
                      </option>

                    ))}

                  </select>

                </td>

                {/* Birds */}

                <td className="w-32 border rounded-xl px-3 py-2">

                  <input
                    type="number"
                    value={row.birds}
                    className="w-full border rounded-xl px-3 py-2"
                    onChange={(e)=>

                      updateRow(
                        row.id,
                        "birds",
                        Number(e.target.value)
                      )

                    }
                  />

                </td>

                {/* Weight */}

                <td className="w-32 border rounded-xl px-3 py-2">

                  <input
                    type="number"
                    value={row.weight}
                    className="w-full border rounded-xl px-3 py-2"
                    onChange={(e)=>

                      updateRow(
                        row.id,
                        "weight",
                        Number(e.target.value)
                      )

                    }
                  />

                </td>

                {/* Mortality */}

                <td className="w-28 border rounded-xl px-3 py-2">

                  <input
                    type="number"
                    value={row.mortality}
                    className="w-full border rounded-xl px-3 py-2"
                    onChange={(e)=>

                      updateRow(
                        row.id,
                        "mortality",
                        Number(e.target.value)
                      )

                    }
                  />

                </td>

                {/* Remarks */}

                <td className="px-1 py-3">

                  <input
                    value={row.remarks}
                    placeholder="Optional"
                    className="w-full border rounded-xl px-3 py-2"
                    onChange={(e)=>

                      updateRow(
                        row.id,
                        "remarks",
                        e.target.value
                      )

                    }
                  />

                </td>

               <td className="text-center">

  <button
    onClick={() => deleteRow(row.id)}
    className="h-9 w-9 rounded-full bg-red-50 hover:bg-red-100 flex items-center justify-center mx-auto"
  >

    <Trash2
      size={18}
      className="text-red-600"
    />

  </button>

</td>

              </tr>

            ))}

          </tbody>

        </table>

      </div>

    </div>

  );

}