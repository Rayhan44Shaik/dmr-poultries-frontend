import type {
  Trip,
  ShopDelivery
} from "../types/trip";

export const tripFormService = {

  // ==========================
  // Calculate Trip Totals
  // ==========================
  calculateTotals(rows: ShopDelivery[]) {

    return {

      totalShops: rows.length,

      totalBirds: rows.reduce(
        (sum, row) => sum + Number(row.birds || 0),
        0
      ),

      totalWeight: rows.reduce(
        (sum, row) => sum + Number(row.weight || 0),
        0
      ),

      totalMortality: rows.reduce(
        (sum, row) => sum + Number(row.mortality || 0),
        0
      ),

      lastShop:
        rows.length > 0
          ? rows[rows.length - 1].shopName
          : ""

    };

  },

  // ==========================
  // KM Calculation
  // ==========================
  calculateKM(
    openingMeter: number,
    closingMeter: number
  ) {

    if (
      !openingMeter ||
      !closingMeter ||
      closingMeter <= openingMeter
    ) {

      return 0;

    }

    return closingMeter - openingMeter;

  },

  // ==========================
  // Trip Validation
  // ==========================
  validateTrip(trip: Trip) {

    const errors: string[] = [];

    // Header Validation

    if (!trip.tripDate)
      errors.push("Trip Date is required.");

    if (!trip.vehicleId)
      errors.push("Please select Vehicle.");

    if (!trip.driverId)
      errors.push("Please select Driver.");

    if (!trip.supervisorId)
      errors.push("Please select Supervisor.");

    if (!trip.sourceFarmId)
      errors.push("Please select Source Farm.");

    // Delivery Validation

    if (trip.deliveries.length === 0) {

      errors.push("Please add at least one Shop.");

    }

    trip.deliveries.forEach((row, index) => {

      if (!row.shopId) {

        errors.push(
          `Row ${index + 1} : Select Shop.`
        );

      }

      if (!row.birdTypeId) {

        errors.push(
          `Row ${index + 1} : Select Bird Type.`
        );

      }

      if (row.birds <= 0) {

        errors.push(
          `Row ${index + 1} : Enter No. of Birds.`
        );

      }

      if (row.weight <= 0) {

        errors.push(
          `Row ${index + 1} : Enter Weight.`
        );

      }

      if (row.mortality < 0) {

        errors.push(
          `Row ${index + 1} : Invalid Mortality.`
        );

      }

    });

    return {

      valid: errors.length === 0,

      errors

    };

  },

  // ==========================
  // Generate Trip Number
  // ==========================
  generateTripNo() {

    const date = new Date();

    const yy = date.getFullYear();

    const mm = String(
      date.getMonth() + 1
    ).padStart(2, "0");

    const dd = String(
      date.getDate()
    ).padStart(2, "0");

    const random = Math.floor(
      100 + Math.random() * 900
    );

    return `TRP-${yy}${mm}${dd}-${random}`;

  }

};