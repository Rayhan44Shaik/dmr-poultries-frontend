import { useMemo, useState } from "react";

import type { Trip } from "../types/trip";

import { tripService } from "../services/tripService";

export default function useTrips() {

  /* ============================
      Filters
  ============================ */

  const [search, setSearch] = useState("");

  const [status, setStatus] = useState("All");

  const [vehicle, setVehicle] = useState("All");

  const [driver, setDriver] = useState("All");

  const [supervisor, setSupervisor] = useState("All");

  const [farm, setFarm] = useState("All");

  const [fromDate, setFromDate] = useState("");

  const [toDate, setToDate] = useState("");

  /* ============================
      Trips
  ============================ */

  const [trips, setTrips] = useState<Trip[]>(
    tripService.getAll()
  );

  /* ============================
      View / Edit
  ============================ */

  const [selectedTrip, setSelectedTrip] =
    useState<Trip | null>(null);

  /* ============================
      Pagination
  ============================ */

  const [currentPage, setCurrentPage] =
    useState(1);

  const pageSize = 10;

  /* ============================
      Refresh
  ============================ */

  const refreshTrips = () => {

    setTrips(
      tripService.getAll()
    );

  };

  /* ============================
      Reset Filters
  ============================ */

  const resetFilters = () => {

    setSearch("");

    setStatus("All");

    setVehicle("All");

    setDriver("All");

    setSupervisor("All");

    setFarm("All");

    setFromDate("");

    setToDate("");

    setCurrentPage(1);

  };

  /* ============================
      Delete Trip
  ============================ */

  const deleteTrip = (id: number) => {

    tripService.remove(id);

    refreshTrips();

  };
const updateTrip = (trip: Trip) => {

  tripService.update(trip);

  refreshTrips();

};

const changeStatus = (

  trip: Trip,

  status: "Pending" | "Completed"

) => {

  updateTrip({

    ...trip,

    status

  });

};
  /* ============================
      Recent Trips
  ============================ */

  const recentTrips = useMemo(() => {

    return tripService.getRecent(5);

  }, [trips]);

  /* ============================
      Filtered Trips
  ============================ */

  const filteredTrips = useMemo(() => {

    return trips.filter(trip => {

      const text = search.toLowerCase();

      const searchMatched =

        text === "" ||

        trip.tripNo.toLowerCase().includes(text) ||

        trip.vehicleNo.toLowerCase().includes(text) ||

        trip.driverName.toLowerCase().includes(text) ||

        trip.supervisorName.toLowerCase().includes(text) ||

        trip.sourceFarm.toLowerCase().includes(text);

      const statusMatched =

        status === "All" ||

        trip.status === status;

      const vehicleMatched =

        vehicle === "All" ||

        trip.vehicleNo === vehicle;

      const driverMatched =

        driver === "All" ||

        trip.driverName === driver;

      const supervisorMatched =

        supervisor === "All" ||

        trip.supervisorName === supervisor;

      const farmMatched =

        farm === "All" ||

        trip.sourceFarm === farm;

      const fromMatched =

        !fromDate ||

        trip.tripDate >= fromDate;

      const toMatched =

        !toDate ||

        trip.tripDate <= toDate;

      return (

        searchMatched &&

        statusMatched &&

        vehicleMatched &&

        driverMatched &&

        supervisorMatched &&

        farmMatched &&

        fromMatched &&

        toMatched

      );

    });

  }, [

    trips,

    search,

    status,

    vehicle,

    driver,

    supervisor,

    farm,

    fromDate,

    toDate

  ]);

  /* ============================
      Pagination
  ============================ */

  const totalPages = Math.ceil(
    filteredTrips.length / pageSize
  );

  const paginatedTrips = filteredTrips.slice(

    (currentPage - 1) * pageSize,

    currentPage * pageSize

  );

  

  /* ============================
      KPI Cards
  ============================ */

  const totalTrips = filteredTrips.length;

  const totalShops = filteredTrips.reduce(

    (sum, trip) => sum + trip.totalShops,

    0

  );

  const totalBirds = filteredTrips.reduce(

    (sum, trip) => sum + trip.totalBirds,

    0

  );

  const totalWeight = filteredTrips.reduce(

    (sum, trip) => sum + trip.totalWeight,

    0

  );

  const totalMortality = filteredTrips.reduce(

    (sum, trip) => sum + trip.totalMortality,

    0

  );

  const totalExpenses = filteredTrips.reduce(

    (sum, trip) => sum + trip.expense,

    0

  );

  return {

    trips: paginatedTrips,

    filteredTrips,

    recentTrips,

    refreshTrips,

    deleteTrip,

    selectedTrip,

    setSelectedTrip,

    currentPage,

    setCurrentPage,

    totalPages,

    pageSize,

    totalTrips,

    totalShops,

    totalBirds,

    totalWeight,

    totalMortality,

    totalExpenses,

    updateTrip,
    search,
    setSearch,

    status,
    setStatus,

    vehicle,
    setVehicle,

    driver,
    setDriver,

    supervisor,
    setSupervisor,

    farm,
    setFarm,

    fromDate,
    setFromDate,

    toDate,
    setToDate,

    resetFilters,

changeStatus,
    

  };

}