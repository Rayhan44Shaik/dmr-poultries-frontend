import { useState } from "react";

import type {
  Trip,
  ShopDelivery
} from "../types/trip";

import { tripService } from "../services/tripService";

import { tripFormService } from "../services/tripFormService";

const createEmptyTrip = (): Trip => ({

  id: Date.now(),

  tripNo: tripFormService.generateTripNo(),

  tripDate: new Date().toISOString().substring(0, 10),

  vehicleId: 0,
  vehicleNo: "",

  driverId: 0,
  driverName: "",

  supervisorId: 0,
  supervisorName: "",

  sourceFarmId: 0,
  sourceFarm: "",

  openingMeter: 0,
  closingMeter: 0,
  totalKm: 0,

  fuel: 0,
  expense: 0,

  remarks: "",

  totalShops: 0,
  totalBirds: 0,
  totalWeight: 0,
  totalMortality: 0,

  lastShop: "",

  status: "Pending",

  deliveries: [],

  createdAt: new Date().toISOString(),

  updatedAt: new Date().toISOString()

});

export function useTripEntry() {

  const [trip, setTrip] = useState<Trip>(
    createEmptyTrip()
  );

  const updateField = (
    field: keyof Trip,
    value: any
  ) => {

    setTrip(prev => ({

      ...prev,

      [field]: value

    }));

  };

  const updateDeliveries = (
    rows: ShopDelivery[]
  ) => {

    const totals =
      tripFormService.calculateTotals(rows);

    const updatedTrip: Trip = {

      ...trip,

      deliveries: rows,

      totalShops: totals.totalShops,

      totalBirds: totals.totalBirds,

      totalWeight: totals.totalWeight,

      totalMortality: totals.totalMortality,

      lastShop: totals.lastShop

    };

    setTrip(updatedTrip);

    return updatedTrip;

  };

  const clearTrip = () => {

    setTrip(
      createEmptyTrip()
    );

  };

  const saveTrip = (
    rows: ShopDelivery[]
  ) => {

    const totals =
      tripFormService.calculateTotals(rows);

    const finalTrip: Trip = {

      ...trip,

      deliveries: rows,

      totalShops: totals.totalShops,

      totalBirds: totals.totalBirds,

      totalWeight: totals.totalWeight,

      totalMortality: totals.totalMortality,

      lastShop: totals.lastShop,

      totalKm:
        tripFormService.calculateKM(
          trip.openingMeter,
          trip.closingMeter
        ),

      updatedAt:
        new Date().toISOString()

    };

    const validation =
      tripFormService.validateTrip(
        finalTrip
      );

    if (!validation.valid) {

      alert(
        validation.errors.join("\n")
      );

      return false;

    }

    tripService.create(
      finalTrip
    );

    alert(
      "Trip Saved Successfully."
    );

    clearTrip();

    return true;

  };

  const saveAndNew = (
    rows: ShopDelivery[]
  ) => {

    return saveTrip(rows);

  };

  const loadTrip = (
    tripData: Trip
  ) => {

    setTrip({

      ...tripData,

      updatedAt:
        new Date().toISOString()

    });

  };

  const updateTrip = (
    rows: ShopDelivery[]
  ) => {

    const totals =
      tripFormService.calculateTotals(rows);

    const finalTrip: Trip = {

      ...trip,

      deliveries: rows,

      totalShops: totals.totalShops,

      totalBirds: totals.totalBirds,

      totalWeight: totals.totalWeight,

      totalMortality: totals.totalMortality,

      lastShop: totals.lastShop,

      totalKm:
        tripFormService.calculateKM(
          trip.openingMeter,
          trip.closingMeter
        ),

      updatedAt:
        new Date().toISOString()

    };

    const validation =
      tripFormService.validateTrip(
        finalTrip
      );

    if (!validation.valid) {

      alert(
        validation.errors.join("\n")
      );

      return false;

    }

    tripService.update(
      finalTrip
    );

    alert(
      "Trip Updated Successfully."
    );

    clearTrip();

    return true;

  };

  return {

    trip,

    setTrip,

    updateField,

    updateDeliveries,

    saveTrip,

    saveAndNew,

    updateTrip,

    loadTrip,

    clearTrip

  };

}