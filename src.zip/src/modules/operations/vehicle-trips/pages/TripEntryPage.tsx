import { useEffect, useState } from "react";

import { Truck } from "lucide-react";

import DashboardLayout from "../../../../layouts/DashboardLayout/DashboardLayout";

import TripInformation from "../components/TripInformation";
import ShopDeliveryTable from "../components/ShopDeliveryTable";
import TripTotals from "../components/TripTotals";
import TripFooter from "../components/TripFooter";
import TripRecentTable from "../components/TripRecentTable";
import TripViewModal from "../components/TripViewModal";
import TripEditModal from "../components/TripEditModal";

import { useTripEntry } from "../hooks/useTripEntry";
import useTrips from "../hooks/useTrips";

import { useVehicles } from "../../../masters/vehicles/hooks/useVehicles";
import { useEmployees } from "../../../masters/employees/hooks/useEmployees";
import { useFarms } from "../../../masters/farms/hooks/useFarms";
import { useShops } from "../../../masters/shops/hooks/useShops";
import { useBirdTypes } from "../../../masters/bird-types/hooks/useBirdTypes";

import type {
  Trip,
  ShopDelivery,
} from "../types/trip";

export default function TripEntryPage() {

  /* ---------------- Masters ---------------- */

  const { vehicles } = useVehicles();

  const { employees } = useEmployees();

  const { farms } = useFarms();

  const { shops } = useShops();

  const { birdTypes } = useBirdTypes();

  /* ---------------- Trips ---------------- */

  const {

    trips,

    refreshTrips,

  } = useTrips();

  /* ---------------- Entry Hook ---------------- */

  const {

    trip,

    setTrip,

    updateField,

    updateDeliveries,

    saveTrip,

    saveAndNew,

    clearTrip,

  } = useTripEntry();

  /* ---------------- Employees ---------------- */

  const drivers = employees.filter(
    (x: any) => x.department === "Driver"
  );

  const supervisors = employees.filter(
    (x: any) => x.department === "Supervisor"
  );

  /* ---------------- Delivery Rows ---------------- */

  const [rows, setRows] =
    useState<ShopDelivery[]>([]);

  /* ---------------- View Modal ---------------- */

  const [viewTrip, setViewTrip] =
    useState<Trip | null>(null);

  const [viewOpen, setViewOpen] =
    useState(false);

  /* ---------------- Edit Modal ---------------- */

  const [editTrip, setEditTrip] =
    useState<Trip | null>(null);

  const [editOpen, setEditOpen] =
    useState(false);

  /* ---------------- Edit Mode ---------------- */

  const [isEditing, setIsEditing] =
    useState(false);

  /* ---------------- View ---------------- */

  const handleView = (
    selectedTrip: Trip
  ) => {

    setViewTrip(selectedTrip);

    setViewOpen(true);

  };

  /* ---------------- Edit ---------------- */

  const handleEdit = (
    selectedTrip: Trip
  ) => {

    setEditTrip(selectedTrip);

    setEditOpen(true);

  };

  const loadTripForEditing = () => {

    if (!editTrip)
      return;

    setTrip(editTrip);

    setRows(editTrip.deliveries);

    setIsEditing(true);

    setEditOpen(false);

  };

  /* ---------------- Save ---------------- */

  const handleSave = () => {

    updateDeliveries(rows);

    saveTrip(rows);

    refreshTrips();

  };

  /* ---------------- Save & New ---------------- */

  const handleSaveNew = () => {

    updateDeliveries(rows);

    saveAndNew(rows);

    refreshTrips();

    setRows([]);

  };

  /* ---------------- Clear ---------------- */

  const handleClear = () => {

    clearTrip();

    setRows([]);

    setIsEditing(false);

  };

  /* ---------------- Refresh ---------------- */

  const handleRefresh = () => {

    refreshTrips();

  };

  useEffect(() => {

    if (!isEditing)
      return;

    setRows(trip.deliveries);

  }, [trip, isEditing]);
  return (

    <DashboardLayout>

      <div className="space-y-8">

        {/* Header */}

        <div className="bg-white rounded-2xl border border-slate-200 shadow-sm px-8 py-7">

          <div className="flex items-center gap-4">

            <div className="h-16 w-16 rounded-2xl bg-green-100 flex items-center justify-center">

              <Truck
                size={34}
                className="text-green-700"
              />

            </div>

            <div>

              <h1 className="text-4xl font-bold text-slate-800">

                Vehicle Trip Entry

              </h1>

              <p className="text-slate-500 mt-2">

                Enter all shop deliveries for a vehicle in a single trip

              </p>

            </div>

          </div>

        </div>

        {/* Trip Information */}

        <TripInformation

          trip={trip}

          setTrip={setTrip}

          updateField={updateField}

          vehicles={vehicles}

          drivers={drivers}

          supervisors={supervisors}

          farms={farms}

        />

        {/* Shop Delivery */}

        <ShopDeliveryTable

          rows={rows}

          setRows={setRows}

          shops={shops}

          birdTypes={birdTypes}

        />

        {/* Totals */}

        <TripTotals

          rows={rows}

        />

        {/* Recent Trips */}

        <TripRecentTable

          trips={trips}

          onRefresh={handleRefresh}

          onView={handleView}

          onEdit={handleEdit}

        />

        {/* Footer */}

        <TripFooter

          onClear={handleClear}

          onSave={handleSave}

          onSaveNew={handleSaveNew}

        />

        {/* View Trip */}

        <TripViewModal

          trip={viewTrip}

          open={viewOpen}

          onClose={() => {

            setViewOpen(false);

            setViewTrip(null);

          }}

        />

        {/* Edit Trip */}

        <TripEditModal

          trip={editTrip}

          open={editOpen}

          onClose={() => {

            setEditOpen(false);

            setEditTrip(null);

          }}

          onEdit={loadTripForEditing}

        />

      </div>

    </DashboardLayout>

  );

}