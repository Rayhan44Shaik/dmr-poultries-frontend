import { useState } from "react";
import { Truck } from "lucide-react";

import DashboardLayout from "../../../../layouts/DashboardLayout/DashboardLayout";

import useTrips from "../hooks/useTrips";

import TripFilters from "../components/TripFilters";
import TripKPICards from "../components/TripKPICards";
import TripMasterTable from "../components/TripMasterTable";
import TripPagination from "../components/TripPagination";
import TripViewModal from "../components/TripViewModal";
import TripEditModal from "../components/TripEditModal";

import type { Trip } from "../types/trip";

export default function TripListPage() {

  const {

  trips,

  deleteTrip,

  currentPage,

  setCurrentPage,

  totalPages,

  totalTrips,

  totalShops,

  totalBirds,

  totalWeight,

  totalMortality,

  search,
  setSearch,

  vehicle,
  setVehicle,

  supervisor,
  setSupervisor,

  farm,
  setFarm,

  fromDate,
  setFromDate,

  toDate,
  setToDate,

  resetFilters,

  selectedTrip,
  setSelectedTrip,

  changeStatus,

} = useTrips();

/* ----------------------------------
   Filter Lists
----------------------------------- */

const vehicles = [
  "All Vehicles",
  ...Array.from(
    new Set(
      trips
        .map((t) => t.vehicleNo)
        .filter(Boolean)
    )
  )
];

const supervisors = [
  "All Supervisors",
  ...Array.from(
    new Set(
      trips
        .map((t) => t.supervisorName)
        .filter(Boolean)
    )
  )
];

const farms = [
  "All Sources",
  ...Array.from(
    new Set(
      trips
        .map((t) => t.sourceFarm)
        .filter(Boolean)
    )
  )
];

  const [

    viewOpen,

    setViewOpen

  ] = useState(false);

  const [

    editOpen,

    setEditOpen

  ] = useState(false);

  const openView = (

    trip: Trip

  ) => {

    setSelectedTrip(trip);

    setViewOpen(true);

  };

  const openEdit = (

    trip: Trip

  ) => {

    setSelectedTrip(trip);

    setEditOpen(true);

  };

  const handleDelete = (

    trip: Trip

  ) => {

    deleteTrip(trip.id);

  };

const editTrip = (trip: Trip) => {

  console.log("Edit Trip", trip);

  // Next:
  // Navigate to Trip Entry
  // Load trip into form
};

  return (

    <DashboardLayout>

      <div className="space-y-8">

        {/* Header */}

        <div className="bg-white rounded-2xl border border-slate-200 shadow-sm px-8 py-7">

          <div className="flex items-center gap-4">

            <div className="h-16 w-16 rounded-2xl bg-blue-100 flex items-center justify-center">

              <Truck

                size={34}

                className="text-blue-700"

              />

            </div>

            <div>

              <h1 className="text-4xl font-bold text-slate-800">

                Vehicle Trip List

              </h1>

              <p className="text-slate-500 mt-2">

                Search, View, Edit and Manage Trips

              </p>

            </div>

          </div>

        </div>

        {/* Filters */}

<TripFilters

  fromDate={fromDate}
  toDate={toDate}

  vehicle={vehicle}
  supervisor={supervisor}
  farm={farm}

  search={search}

  setFromDate={setFromDate}
  setToDate={setToDate}

  setVehicle={setVehicle}
  setSupervisor={setSupervisor}
  setFarm={setFarm}

  setSearch={setSearch}

  onSearch={() => {}}

  onReset={resetFilters}

  vehicles={vehicles}
  supervisors={supervisors}
  farms={farms}

/>

        {/* KPI */}

<TripKPICards
  totalTrips={totalTrips}
  totalBirds={totalBirds}
  totalWeight={totalWeight}
  totalMortality={totalMortality}
  totalShops={totalShops}
/>

        {/* Master Table */}

<TripMasterTable

  trips={trips}

  onView={openView}

  onEdit={openEdit}

  onDelete={handleDelete}

  onStatusChange={changeStatus}

/>


        {/* Pagination */}

        <TripPagination

          currentPage={currentPage}

          totalPages={totalPages}

          onPageChange={setCurrentPage}

        />
                {/* View Trip */}

        <TripViewModal

          open={viewOpen}

          trip={selectedTrip}

          onClose={() => {

            setViewOpen(false);

            setSelectedTrip(null);

          }}

        />

        {/* Edit Trip */}

        <TripEditModal

          open={editOpen}

          trip={selectedTrip}

          onClose={() => {

            setEditOpen(false);

            setSelectedTrip(null);

          }}

onEdit={editTrip}

        />

      </div>

    </DashboardLayout>

  );

}