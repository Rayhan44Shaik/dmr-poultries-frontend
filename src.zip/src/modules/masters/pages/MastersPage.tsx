import { useMemo, useState } from "react";

import {
  Store,
  Warehouse,
  Truck,
  Users,
  Building2,
  Bird,
  MapPinned,
  Search,
} from "lucide-react";

import DashboardLayout from "../../../layouts/DashboardLayout/DashboardLayout";


import MasterCard from "../components/MasterCard";
import MasterToolbar from "../components/MasterToolbar";
import MasterDataTable from "../components/MasterDataTable";

import { useShops } from "../shops/hooks/useShops";
import { useFarms } from "../farms/hooks/useFarms";
import { useVehicles } from "../vehicles/hooks/useVehicles";
import { useEmployees } from "../employees/hooks/useEmployees";
import { useBanks } from "../banks/hooks/useBanks";
import { useBirdTypes } from "../bird-types/hooks/useBirdTypes";
import {

  exportToExcel,

  exportToPdf,

} from "../../../utils/exportUtils";

function MastersPage() {

  const { shops } = useShops();
  const { farms } = useFarms();
  const { vehicles } = useVehicles();
  const { employees } = useEmployees();
  const { banks } = useBanks();
  const { birdTypes } = useBirdTypes();

  const [search, setSearch] = useState("");

  const [moduleName, setModuleName] =
    useState("Shops");

  const [status, setStatus] =
    useState("All");

  const totalMasters =
    shops.length +
    farms.length +
    vehicles.length +
    employees.length +
    banks.length +
    birdTypes.length;

  const moduleData = useMemo(() => {

    switch (moduleName) {

      case "Shops":
        return shops;

      case "Farms":
        return farms;

      case "Vehicles":
        return vehicles;

      case "Employees":
        return employees;

      case "Banks":
        return banks;

      case "Bird Types":
        return birdTypes;

      default:
        return [];

    }

  }, [

    moduleName,
    shops,
    farms,
    vehicles,
    employees,
    banks,
    birdTypes,

  ]);

  const filteredData = useMemo(() => {

    return moduleData.filter((item: any) => {

      const searchMatched =
        JSON.stringify(item)
          .toLowerCase()
          .includes(search.toLowerCase());

      const statusMatched =
        status === "All"
          ? true
          : item.status === status;

      return searchMatched && statusMatched;

    });

  }, [

    moduleData,
    search,
    status,

  ]);
const exportExcel = () => {

  exportToExcel(

    filteredData,

    moduleName

  );

};

const exportPdf = () => {

  exportToPdf(

    filteredData,

    moduleName

  );

};    
return (

    <DashboardLayout>

      <div className="space-y-8">

        <div className="mb-2">

          <p className="text-slate-1000 text-sm">

              Manage all master records from one place • {totalMasters} Total Records

          </p>

        </div>  

        {/* Global Search */}

        <div className="bg-white rounded-2xl shadow-sm border p-6">

          <h2 className="text-2xl font-bold text-slate-800">

            Search

          </h2>

          <div className="relative">

            <Search
              size={22}
              className="absolute left-5 top-4 text-slate-400"
            />

            <input

              value={search}

              onChange={(e)=>

                setSearch(

                  e.target.value

                )

              }

              placeholder="Search Shops, Vehicles, Employees, Banks,Farms, Bird Types..."

              className="w-full border rounded-xl pl-14 pr-5 py-4 text-lg focus:ring-2 focus:ring-green-600 outline-none"

            />

          </div>

        </div>

        {/* Summary Cards */}

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">

          <MasterCard
            title="Shops"
            total={shops.length}
            active={shops.filter(x=>x.status==="Active").length}
            inactive={shops.filter(x=>x.status==="Inactive").length}
            icon={<Store size={40} className="text-blue-700"/>}
            color="bg-blue-50 border-blue-200"
            path="/masters/shops"
          />

          

          <MasterCard
            title="Vehicles"
            total={vehicles.length}
            active={vehicles.filter(x=>x.status==="Active").length}
            inactive={vehicles.filter(x=>x.status==="Inactive").length}
            icon={<Truck size={40} className="text-orange-600"/>}
            color="bg-orange-50 border-orange-200"
            path="/masters/vehicles"
          />

          <MasterCard
            title="Employees"
            total={employees.length}
            active={employees.filter(x=>x.status==="Active").length}
            inactive={employees.filter(x=>x.status==="Inactive").length}
            icon={<Users size={40} className="text-purple-700"/>}
            color="bg-purple-50 border-purple-200"
            path="/masters/employees"
          />

        </div>

        {/* Second Row */}

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">

          <MasterCard
            title="Banks"
            total={banks.length}
            active={banks.filter(x=>x.status==="Active").length}
            inactive={banks.filter(x=>x.status==="Inactive").length}
            icon={<Building2 size={40} className="text-cyan-750"/>}
            color="bg-cyan-50 border-cyan-200"
            path="/masters/banks"
          />
          <MasterCard
            title="Farms"
            total={farms.length}
            active={farms.filter(x=>x.status==="Active").length}
            inactive={farms.filter(x=>x.status==="Inactive").length}
            icon={<Warehouse size={40} className="text-green-700"/>}
            color="bg-green-50 border-green-200"
            path="/masters/farms"
          />
          <MasterCard
            title="Bird Types"
            total={birdTypes.length}
            active={birdTypes.length}
            inactive={0}
            icon={<Bird size={40} className="text-yellow-600"/>}
            color="bg-yellow-50 border-yellow-200"
            path="/masters/bird-types"
          />

          <MasterCard
            title="Routes"
            total={0}
            active={0}
            inactive={0}
            icon={<MapPinned size={40} className="text-pink-600"/>}
            color="bg-pink-50 border-pink-200"
            path="/masters/routes"
          />

        </div>

      <MasterToolbar

  moduleName={moduleName}

  status={status}

  totalRecords={filteredData.length}

  onModuleChange={setModuleName}

  onStatusChange={setStatus}

  onExcel={exportExcel}

  onPdf={exportPdf}

/>
<MasterDataTable

  moduleName={moduleName}

  data={filteredData}

/>

      </div>

    </DashboardLayout>

  );

}

export default MastersPage;