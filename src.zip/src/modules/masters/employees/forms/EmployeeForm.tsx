import { useEffect, useState } from "react";
import type { Employee } from "../types/employee";

type EmployeeFormProps = {
  employee?: Employee | null;

  onSave: (employee: {
    employeeName: string;
    department:
      | "Driver"
      | "Supervisor"
      | "Loader"
      | "Accountant"
      | "Collection"
      | "Office Staff"
      | "Other";
    dob: string;
    mobile: string;
    aadhaarNumber: string;
    bankName: string;
    accountNumber: string;
    ifscCode: string;
    address: string;
    licenseNumber: string;
    licenseExpiry: string;
    joiningDate: string;
    salary: number;
    status: "Active" | "Inactive";
  }) => void;

  onCancel: () => void;
};

function EmployeeForm({
  employee,
  onSave,
  onCancel,
}: EmployeeFormProps) {

  const [employeeName, setEmployeeName] = useState("");

  const [department, setDepartment] = useState<
    | "Driver"
    | "Supervisor"
    | "Loader"
    | "Accountant"
    | "Collection"
    | "Office Staff"
    | "Other"
  >("Driver");

  const [dob, setDob] = useState("");

  const [mobile, setMobile] = useState("");

  const [aadhaarNumber, setAadhaarNumber] = useState("");

  const [bankName, setBankName] = useState("");

  const [accountNumber, setAccountNumber] = useState("");

  const [ifscCode, setIfscCode] = useState("");

  const [address, setAddress] = useState("");

  const [licenseNumber, setLicenseNumber] = useState("");

  const [licenseExpiry, setLicenseExpiry] = useState("");

  const [joiningDate, setJoiningDate] = useState("");

  const [salary, setSalary] = useState<number | "">("");

  const [status, setStatus] =
    useState<"Active" | "Inactive">("Active");

  useEffect(() => {

    if (employee) {

      setEmployeeName(employee.employeeName);
      setDepartment(employee.department);
      setDob(employee.dob);
      setMobile(employee.mobile);
      setAadhaarNumber(employee.aadhaarNumber);
      setBankName(employee.bankName);
      setAccountNumber(employee.accountNumber);
      setIfscCode(employee.ifscCode);
      setAddress(employee.address);
      setLicenseNumber(employee.licenseNumber);
      setLicenseExpiry(employee.licenseExpiry);
      setJoiningDate(employee.joiningDate);
      setSalary(employee.salary);
      setStatus(employee.status);

    } else {

      setEmployeeName("");
      setDepartment("Driver");
      setDob("");
      setMobile("");
      setAadhaarNumber("");
      setBankName("");
      setAccountNumber("");
      setIfscCode("");
      setAddress("");
      setLicenseNumber("");
      setLicenseExpiry("");
      setJoiningDate("");
      setSalary("");
      setStatus("Active");

    }

  }, [employee]);

  const handleSubmit = () => {

    if (
      !employeeName ||
      !mobile ||
      !aadhaarNumber ||
      !bankName ||
      !accountNumber ||
      !ifscCode ||
      !joiningDate
    ) {

      alert("Please fill all mandatory fields.");

      return;

    }

    if (!/^[0-9]{10}$/.test(mobile)) {

      alert("Mobile Number must be exactly 10 digits.");

      return;

    }

    if (!/^[0-9]{12}$/.test(aadhaarNumber)) {

      alert("Aadhaar Number must be exactly 12 digits.");

      return;

    }

    onSave({

      employeeName,

      department,

      dob,

      mobile,

      aadhaarNumber,

      bankName,

      accountNumber,

      ifscCode,

      address,

      licenseNumber,

      licenseExpiry,

      joiningDate,

      salary: Number(salary || 0),

      status,

    });

  };

  const showLicense =
    department === "Driver" ||
    department === "Collection";

  return (

  <div className="space-y-5">

    <div className="grid grid-cols-2 gap-5">

      {/* Employee Name */}

      <div>

        <label className="block mb-2 text-sm font-medium text-slate-700">
          <span className="text-red-500">*</span> Employee Name
        </label>

        <input
          value={employeeName}
          onChange={(e)=>setEmployeeName(e.target.value)}
          placeholder="Enter Employee Name"
          className="w-full border rounded-lg p-3"
        />

      </div>

      {/* Department */}

      <div>

        <label className="block mb-2 text-sm font-medium text-slate-700">
          <span className="text-red-500">*</span> Department
        </label>

        <select
          value={department}
          onChange={(e)=>setDepartment(e.target.value as any)}
          className="w-full border rounded-lg p-3"
        >
          <option>Driver</option>
          <option>Supervisor</option>
          <option>Loader</option>
          <option>Accountant</option>
          <option>Collection</option>
          <option>Office Staff</option>
          <option>Other</option>
        </select>

      </div>

      {/* DOB */}

      <div>

        <label className="block mb-2 text-sm font-medium text-slate-700">
          <span className="text-red-500">*</span> Date of Birth
        </label>

        <input
          type="date"
          value={dob}
          onChange={(e)=>setDob(e.target.value)}
          className="w-full border rounded-lg p-3"
        />

      </div>

      {/* Mobile */}

      <div>

        <label className="block mb-2 text-sm font-medium text-slate-700">
          <span className="text-red-500">*</span> Mobile Number
        </label>

        <input
          value={mobile}
          maxLength={10}
          onChange={(e)=>
            setMobile(
              e.target.value.replace(/\D/g,"")
            )
          }
          placeholder="Enter Mobile Number"
          className="w-full border rounded-lg p-3"
        />

      </div>

      {/* Aadhaar */}

      <div>

        <label className="block mb-2 text-sm font-medium text-slate-700">
          <span className="text-red-500">*</span> Aadhaar Number
        </label>

        <input
          value={aadhaarNumber}
          maxLength={12}
          onChange={(e)=>
            setAadhaarNumber(
              e.target.value.replace(/\D/g,"")
            )
          }
          placeholder="Enter Aadhaar Number"
          className="w-full border rounded-lg p-3"
        />

      </div>

      {/* Bank */}

      <div>

        <label className="block mb-2 text-sm font-medium text-slate-700">
          <span className="text-red-500">*</span> Bank Name
        </label>

        <input
          value={bankName}
          onChange={(e)=>setBankName(e.target.value)}
          placeholder="Enter Bank Name"
          className="w-full border rounded-lg p-3"
        />

      </div>

      {/* Account */}

      <div>

        <label className="block mb-2 text-sm font-medium text-slate-700">
          <span className="text-red-500">*</span> Account Number
        </label>

        <input
          value={accountNumber}
          onChange={(e)=>setAccountNumber(e.target.value)}
          placeholder="Enter Account Number"
          className="w-full border rounded-lg p-3"
        />

      </div>

      {/* IFSC */}

      <div>

        <label className="block mb-2 text-sm font-medium text-slate-700">
          <span className="text-red-500">*</span> IFSC Code
        </label>

        <input
          value={ifscCode}
          onChange={(e)=>setIfscCode(e.target.value.toUpperCase())}
          placeholder="Enter IFSC Code"
          className="w-full border rounded-lg p-3"
        />

      </div>

    </div>

    {/* Address */}

    <div>

      <label className="block mb-2 text-sm font-medium text-slate-700">
        Address
      </label>

      <textarea
        value={address}
        onChange={(e)=>setAddress(e.target.value)}
        placeholder="Enter Complete Address"
        className="w-full border rounded-lg p-3"
      />

    </div>

    {showLicense && (

      <div className="grid grid-cols-2 gap-5">

        <div>

          <label className="block mb-2 text-sm font-medium text-slate-700">
            <span className="text-red-500">*</span> License Number
          </label>

          <input
            value={licenseNumber}
            onChange={(e)=>setLicenseNumber(e.target.value)}
            placeholder="Enter License Number"
            className="w-full border rounded-lg p-3"
          />

        </div>

        <div>

          <label className="block mb-2 text-sm font-medium text-slate-700">
            <span className="text-red-500">*</span> License Expiry
          </label>

          <input
            type="date"
            value={licenseExpiry}
            onChange={(e)=>setLicenseExpiry(e.target.value)}
            className="w-full border rounded-lg p-3"
          />

        </div>

      </div>

    )}

    <div className="grid grid-cols-2 gap-5">

      <div>

        <label className="block mb-2 text-sm font-medium text-slate-700">
          <span className="text-red-500">*</span> Joining Date
        </label>

        <input
          type="date"
          value={joiningDate}
          onChange={(e)=>setJoiningDate(e.target.value)}
          className="w-full border rounded-lg p-3"
        />

      </div>

      <div>

        <label className="block mb-2 text-sm font-medium text-slate-700">
          Monthly Salary
        </label>

        <input
          type="number"
          value={salary}
          onChange={(e)=>
            setSalary(
              e.target.value === ""
                ? ""
                : Number(e.target.value)
            )
          }
          placeholder="Enter Monthly Salary"
          className="w-full border rounded-lg p-3"
        />

      </div>

    </div>

    <div>

      <label className="block mb-2 text-sm font-medium text-slate-700">
        Employee Status
      </label>

      <select
        value={status}
        onChange={(e)=>
          setStatus(e.target.value as "Active" | "Inactive")
        }
        className="w-full border rounded-lg p-3"
      >
        <option value="Active">Active</option>
        <option value="Inactive">Inactive</option>
      </select>

    </div>

    <div className="flex justify-end gap-3 pt-3">

      <button
        type="button"
        onClick={onCancel}
        className="px-6 py-2 border rounded-lg hover:bg-gray-100"
      >
        Cancel
      </button>

      <button
        type="button"
        onClick={handleSubmit}
        className="px-6 py-2 bg-green-700 hover:bg-green-800 text-white rounded-lg"
      >
        {employee ? "Update Employee" : "Save Employee"}
      </button>

    </div>

  </div>

);

}

export default EmployeeForm;