import EmployeeForm from "../forms/EmployeeForm";
import type { Employee } from "../types/employee";

type EmployeeDialogProps={

open:boolean;

onClose:()=>void;

onSave:(employee:any)=>void;

employee?:Employee|null;

};

function EmployeeDialog({

open,

onClose,

onSave,

employee,

}:EmployeeDialogProps){

if(!open) return null;

return(

<div className="fixed inset-0 bg-black/40 flex justify-center items-center z-50">

<div className="bg-white rounded-xl shadow-xl w-full max-w-5xl p-6 max-h-[90vh] overflow-y-auto">

<h2 className="text-2xl font-bold mb-6">

{employee?"Edit Employee":"Add Employee"}

</h2>

<EmployeeForm

employee={employee}

onSave={onSave}

onCancel={onClose}

/>

</div>

</div>

);

}

export default EmployeeDialog;