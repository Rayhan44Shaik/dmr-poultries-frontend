import { Pencil, Trash2 } from "lucide-react";
import type { Employee } from "../types/employee";

type EmployeeTableProps = {
  employees: Employee[];
  onEdit:(employee:Employee)=>void;
  onDelete:(id:number)=>void;
};

function EmployeeTable({

  employees,
  onEdit,
  onDelete,

}:EmployeeTableProps){

return(

<div className="bg-white rounded-xl shadow-sm overflow-hidden">

<table className="w-full">

<thead className="bg-slate-100">

<tr>

<th className="px-4 py-3 text-left">Emp No</th>

<th className="px-4 py-3 text-left">Employee</th>

<th className="px-4 py-3 text-left">Department</th>

<th className="px-4 py-3 text-left">Mobile</th>

<th className="px-4 py-3 text-left">Bank</th>

<th className="px-4 py-3 text-left">Salary</th>

<th className="px-4 py-3 text-center">Status</th>

<th className="px-4 py-3 text-center">Actions</th>

</tr>

</thead>

<tbody>

{employees.map(employee=>(

<tr
key={employee.id}
className="border-b hover:bg-slate-50"
>

<td className="px-4 py-3">

{employee.employeeNo}

</td>

<td className="px-4 py-3">

{employee.employeeName}

</td>

<td className="px-4 py-3">

{employee.department}

</td>

<td className="px-4 py-3">

{employee.mobile}

</td>

<td className="px-4 py-3">

{employee.bankName}

</td>

<td className="px-4 py-3">

₹ {employee.salary.toLocaleString()}

</td>

<td className="px-4 py-3 text-center">

<span
className={`px-3 py-1 rounded-full ${
employee.status==="Active"
?"bg-green-100 text-green-700"
:"bg-red-100 text-red-700"
}`}
>

{employee.status}

</span>

</td>

<td className="px-4 py-3">

<div className="flex justify-center gap-4">

<button

onClick={()=>onEdit(employee)}

className="text-blue-600"

>

<Pencil size={18}/>

</button>

<button

onClick={()=>onDelete(employee.id)}

className="text-red-600"

>

<Trash2 size={18}/>

</button>

</div>

</td>

</tr>

))}

</tbody>

</table>

</div>

);

}

export default EmployeeTable;