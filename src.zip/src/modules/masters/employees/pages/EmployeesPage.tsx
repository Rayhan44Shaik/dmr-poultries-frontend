import { useState } from "react";

import DashboardLayout from "../../../../layouts/DashboardLayout/DashboardLayout";

import EmployeeToolbar from "../components/EmployeeToolbar";
import EmployeeTable from "../components/EmployeeTable";
import EmployeeDialog from "../dialogs/EmployeeDialog";

import { useEmployees } from "../hooks/useEmployees";

function EmployeesPage() {

  const [showDialog, setShowDialog] = useState(false);

  const [editingEmployee, setEditingEmployee] = useState<any>(null);

  const [search, setSearch] = useState("");

  const { employees, saveEmployees } = useEmployees();

  const filteredEmployees = employees.filter((employee) => {

    const keyword = search.toLowerCase();

    return (

      employee.employeeName.toLowerCase().includes(keyword) ||

      employee.department.toLowerCase().includes(keyword) ||

      employee.mobile.includes(keyword) ||

      employee.aadhaarNumber.includes(keyword)

    );

  });

  const handleSaveEmployee = (employee:any)=>{

    const duplicateMobile = employees.some(

      e=>

      e.mobile===employee.mobile

      &&

      e.id!==editingEmployee?.id

    );

    if(duplicateMobile){

      alert("Mobile Number already exists.");

      return;

    }

    const duplicateAadhaar = employees.some(

      e=>

      e.aadhaarNumber===employee.aadhaarNumber

      &&

      e.id!==editingEmployee?.id

    );

    if(duplicateAadhaar){

      alert("Aadhaar Number already exists.");

      return;

    }

    if(editingEmployee){

      saveEmployees(

        employees.map(e=>

          e.id===editingEmployee.id

          ?{

            ...e,

            ...employee

          }

          :e

        )

      );

    }

    else{

      const newEmployee={

        id:Date.now(),

        employeeNo:employees.length+1,

        ...employee

      };

      saveEmployees([...employees,newEmployee]);

    }

    setEditingEmployee(null);

    setShowDialog(false);

  };

  const handleEditEmployee=(employee:any)=>{

    setEditingEmployee(employee);

    setShowDialog(true);

  };

  const handleDeleteEmployee=(id:number)=>{

    const ok=window.confirm(

      "Delete this Employee?"

    );

    if(!ok) return;

    saveEmployees(

      employees.filter(

        e=>e.id!==id

      )

    );

  };

  return(

<DashboardLayout>

<div className="space-y-6">

<div>

<h1 className="text-3xl font-bold">

Employees

</h1>

<p className="text-slate-500">

Manage all Employees

</p>

</div>

<EmployeeToolbar

search={search}

onSearchChange={setSearch}

onAddEmployee={()=>{

setEditingEmployee(null);

setShowDialog(true);

}}

/>

<p className="text-sm text-slate-500">

Showing {filteredEmployees.length} of {employees.length} Employees

</p>

<EmployeeTable

employees={filteredEmployees}

onEdit={handleEditEmployee}

onDelete={handleDeleteEmployee}

/>

<EmployeeDialog

open={showDialog}

onClose={()=>{

setEditingEmployee(null);

setShowDialog(false);

}}

onSave={handleSaveEmployee}

employee={editingEmployee}

/>

</div>

</DashboardLayout>

);

}

export default EmployeesPage;