export type Employee = {
  id: number;
  employeeNo: number;

  employeeName: string;

  department:
    | "Driver"
    | "Supervisor"
    | "Loader"
    | "Accountant"
    | "Collection"
    | "Office Staff"
    | "Other";

  dob: string;

  mobile: string;

  aadhaarNumber: string;

  bankName: string;

  accountNumber: string;

  ifscCode: string;

  address: string;

  licenseNumber: string;

  licenseExpiry: string;

  joiningDate: string;

  salary: number;

  status: "Active" | "Inactive";
};