import { useEffect, useState } from "react";
import type { BirdType } from "../types/birdType";

type BirdTypeFormProps = {
  birdType?: BirdType | null;

  onSave: (birdType: {
    birdType: string;
    averageWeight: number;
    description: string;
    status: "Active" | "Inactive";
  }) => void;

  onCancel: () => void;
};

function BirdTypeForm({
  birdType,
  onSave,
  onCancel,
}: BirdTypeFormProps) {

  const [birdName, setBirdName] = useState("");

  const [averageWeight, setAverageWeight] =
    useState<number | "">("");

  const [description, setDescription] =
    useState("");

  const [status, setStatus] =
    useState<"Active" | "Inactive">("Active");

  useEffect(() => {

    if (birdType) {

      setBirdName(birdType.birdType);

      setAverageWeight(
        birdType.averageWeight
      );

      setDescription(
        birdType.description
      );

      setStatus(
        birdType.status
      );

    }

    else {

      setBirdName("");

      setAverageWeight("");

      setDescription("");

      setStatus("Active");

    }

  }, [birdType]);

  const handleSubmit = () => {

    if (
      !birdName ||
      averageWeight === ""
    ) {

      alert(
        "Please fill all mandatory fields."
      );

      return;

    }

    onSave({

      birdType: birdName,

      averageWeight:
        Number(averageWeight),

      description,

      status,

    });

  };

  return (

    <div className="space-y-5">

      <div>

        <label className="block mb-2 text-sm font-medium text-slate-700">

          <span className="text-red-500">*</span> Bird Type

        </label>

        <input
          value={birdName}
          onChange={(e)=>
            setBirdName(e.target.value)
          }
          placeholder="Enter Bird Type"
          className="w-full border rounded-lg p-3"
        />

      </div>

      <div>

        <label className="block mb-2 text-sm font-medium text-slate-700">

          <span className="text-red-500">*</span> Average Weight (Kg)

        </label>

        <input
          type="number"
          step="0.1"
          value={averageWeight}
          onChange={(e)=>
            setAverageWeight(
              e.target.value === ""
                ? ""
                : Number(e.target.value)
            )
          }
          placeholder="Enter Average Weight"
          className="w-full border rounded-lg p-3"
        />

      </div>

      <div>

        <label className="block mb-2 text-sm font-medium text-slate-700">

          Description

        </label>

        <textarea
          value={description}
          onChange={(e)=>
            setDescription(
              e.target.value
            )
          }
          placeholder="Enter Description"
          className="w-full border rounded-lg p-3"
        />

      </div>

      <div>

        <label className="block mb-2 text-sm font-medium text-slate-700">

          Bird Type Status

        </label>

        <select
          value={status}
          onChange={(e)=>
            setStatus(
              e.target.value as
                "Active" | "Inactive"
            )
          }
          className="w-full border rounded-lg p-3"
        >

          <option value="Active">
            Active
          </option>

          <option value="Inactive">
            Inactive
          </option>

        </select>

      </div>

      <div className="flex justify-end gap-3">

        <button
          type="button"
          onClick={onCancel}
          className="px-6 py-2 border rounded-lg hover:bg-gray-100"
        >
          Cancel
        </button>

        <button
          type="button"
          onClick={handleSubmit}
          className="px-6 py-2 bg-green-700 hover:bg-green-800 text-white rounded-lg"
        >
          {birdType
            ? "Update Bird Type"
            : "Save Bird Type"}
        </button>

      </div>

    </div>

  );

}

export default BirdTypeForm;