import type { BirdType } from "../types/birdType";

export const initialBirdTypes: BirdType[] = [

  {
    id: 1,
    birdTypeNo: 1,
    birdType: "Broiler",
    averageWeight: 2.2,
    description: "Commercial Broiler Chicken",
    status: "Active",
  },

  {
    id: 2,
    birdTypeNo: 2,
    birdType: "Country Chicken",
    averageWeight: 1.6,
    description: "Native Country Breed",
    status: "Active",
  },

];