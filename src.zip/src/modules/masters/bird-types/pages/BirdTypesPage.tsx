import { useState } from "react";

import DashboardLayout from "../../../../layouts/DashboardLayout/DashboardLayout";

import BirdTypeToolbar from "../components/BirdTypeToolbar";
import BirdTypeTable from "../components/BirdTypeTable";
import BirdTypeDialog from "../dialogs/BirdTypeDialog";

import { useBirdTypes } from "../hooks/useBirdTypes";

function BirdTypesPage() {

  const [showDialog, setShowDialog] =
    useState(false);

  const [editingBird, setEditingBird] =
    useState<any>(null);

  const [search, setSearch] =
    useState("");

  const {
    birdTypes,
    saveBirdTypes,
  } = useBirdTypes();

  const filteredBirdTypes =
    birdTypes.filter((bird) => {

      const keyword =
        search.toLowerCase();

      return (

        bird.birdType
          .toLowerCase()
          .includes(keyword) ||

        bird.description
          .toLowerCase()
          .includes(keyword)

      );

    });

  const handleSaveBird = (
    bird: any
  ) => {

    const duplicate =
      birdTypes.some(

        (b) =>

          b.birdType
            .trim()
            .toLowerCase() ===
          bird.birdType
            .trim()
            .toLowerCase()

          &&

          b.id !==
          editingBird?.id

      );

    if (duplicate) {

      alert(
        "Bird Type already exists."
      );

      return;

    }

    if (editingBird) {

      saveBirdTypes(

        birdTypes.map((b) =>

          b.id ===
          editingBird.id

            ? {

                ...b,

                ...bird,

              }

            : b

        )

      );

    }

    else {

      const newBird = {

        id: Date.now(),

        birdTypeNo:
          birdTypes.length + 1,

        ...bird,

      };

      saveBirdTypes([
        ...birdTypes,
        newBird,
      ]);

    }

    setEditingBird(null);

    setShowDialog(false);

  };

  const handleDelete = (
    id: number
  ) => {

    const ok =
      window.confirm(
        "Delete this Bird Type?"
      );

    if (!ok) return;

    saveBirdTypes(

      birdTypes.filter(

        (b) => b.id !== id

      )

    );

  };

  return (

    <DashboardLayout>

      <div className="space-y-6">

        <div>

          <h1 className="text-3xl font-bold">

            Bird Types

          </h1>

          <p className="text-slate-500">

            Manage Bird Types

          </p>

        </div>

        <BirdTypeToolbar

          search={search}

          onSearchChange={setSearch}

          onAddBirdType={() => {

            setEditingBird(null);

            setShowDialog(true);

          }}

        />

        <p className="text-sm text-slate-500">

          Showing {filteredBirdTypes.length}
          {" "}of{" "}
          {birdTypes.length}
          {" "}Bird Types

        </p>

        <BirdTypeTable

          birdTypes={filteredBirdTypes}

          onEdit={(bird) => {

            setEditingBird(bird);

            setShowDialog(true);

          }}

          onDelete={handleDelete}

        />

        <BirdTypeDialog

          open={showDialog}

          onClose={() => {

            setEditingBird(null);

            setShowDialog(false);

          }}

          onSave={handleSaveBird}

          birdType={editingBird}

        />

      </div>

    </DashboardLayout>

  );

}

export default BirdTypesPage;