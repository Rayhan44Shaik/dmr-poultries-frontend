import BirdTypeForm from "../forms/BirdTypeForm";
import type { BirdType } from "../types/birdType";

type BirdTypeDialogProps = {

  open: boolean;

  onClose: () => void;

  onSave: (birdType: any) => void;

  birdType?: BirdType | null;

};

function BirdTypeDialog({

  open,

  onClose,

  onSave,

  birdType,

}: BirdTypeDialogProps) {

  if (!open) return null;

  return (

    <div className="fixed inset-0 bg-black/40 flex justify-center items-center z-50">

      <div className="bg-white rounded-xl shadow-xl w-full max-w-3xl p-6">

        <h2 className="text-2xl font-bold mb-6">

          {birdType ? "Edit Bird Type" : "Add Bird Type"}

        </h2>

        <BirdTypeForm

          birdType={birdType}

          onSave={onSave}

          onCancel={onClose}

        />

      </div>

    </div>

  );

}

export default BirdTypeDialog;