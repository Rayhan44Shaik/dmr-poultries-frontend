import { Pencil, Trash2 } from "lucide-react";
import type { Bank } from "../types/bank";

type BankTableProps = {
  banks: Bank[];
  onEdit: (bank: Bank) => void;
  onDelete: (id: number) => void;
};

function BankTable({
  banks,
  onEdit,
  onDelete,
}: BankTableProps) {

  return (

    <div className="bg-white rounded-xl shadow-sm overflow-hidden">

      <table className="w-full">

        <thead className="bg-slate-100">

          <tr>

            <th className="px-4 py-3 text-left">No</th>

            <th className="px-4 py-3 text-left">Bank Name</th>

            <th className="px-4 py-3 text-left">Branch</th>

            <th className="px-4 py-3 text-left">Account Number</th>

            <th className="px-4 py-3 text-left">IFSC Code</th>

            <th className="px-4 py-3 text-left">UPI ID</th>

            <th className="px-4 py-3 text-center">Status</th>

            <th className="px-4 py-3 text-center">Actions</th>

          </tr>

        </thead>

        <tbody>

          {banks.map((bank) => (

            <tr
              key={bank.id}
              className="border-b hover:bg-slate-50"
            >

              <td className="px-4 py-3">
                {bank.bankNo}
              </td>

              <td className="px-4 py-3">
                {bank.bankName}
              </td>

              <td className="px-4 py-3">
                {bank.branch}
              </td>

              <td className="px-4 py-3">
                {bank.accountNumber}
              </td>

              <td className="px-4 py-3">
                {bank.ifscCode}
              </td>

              <td className="px-4 py-3">
                {bank.upiId || "-"}
              </td>

              <td className="px-4 py-3 text-center">

                <span
                  className={`px-3 py-1 rounded-full ${
                    bank.status === "Active"
                      ? "bg-green-100 text-green-700"
                      : "bg-red-100 text-red-700"
                  }`}
                >
                  {bank.status}
                </span>

              </td>

              <td className="px-4 py-3">

                <div className="flex justify-center gap-4">

                  <button
                    onClick={() => onEdit(bank)}
                    className="text-blue-600 hover:text-blue-800"
                  >
                    <Pencil size={18} />
                  </button>

                  <button
                    onClick={() => onDelete(bank.id)}
                    className="text-red-600 hover:text-red-800"
                  >
                    <Trash2 size={18} />
                  </button>

                </div>

              </td>

            </tr>

          ))}

        </tbody>

      </table>

    </div>

  );

}

export default BankTable;