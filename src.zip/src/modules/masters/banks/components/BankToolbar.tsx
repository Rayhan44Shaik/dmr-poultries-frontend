import { Search, Plus } from "lucide-react";

type BankToolbarProps = {
  search: string;
  onSearchChange: (value: string) => void;
  onAddBank: () => void;
};

function BankToolbar({

  search,
  onSearchChange,
  onAddBank,

}: BankToolbarProps) {

  return (

    <div className="flex items-center justify-between mb-6">

      <div className="relative w-96">

        <Search
          size={18}
          className="absolute left-3 top-3 text-gray-400"
        />

        <input
          type="text"
          value={search}
          onChange={(e)=>onSearchChange(e.target.value)}
          placeholder="Search Bank..."
          className="w-full border rounded-lg pl-10 pr-4 py-2 focus:outline-none focus:ring-2 focus:ring-green-700"
        />

      </div>

      <button
        onClick={onAddBank}
        className="bg-green-700 hover:bg-green-800 text-white px-5 py-2 rounded-lg flex items-center gap-2"
      >

        <Plus size={18} />

        Add Bank

      </button>

    </div>

  );

}

export default BankToolbar;