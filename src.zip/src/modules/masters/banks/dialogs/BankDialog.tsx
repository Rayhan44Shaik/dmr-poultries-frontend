import BankForm from "../forms/BankForm";
import type { Bank } from "../types/bank";

type BankDialogProps = {

  open: boolean;

  onClose: () => void;

  onSave: (bank: any) => void;

  bank?: Bank | null;

};

function BankDialog({

  open,

  onClose,

  onSave,

  bank,

}: BankDialogProps) {

  if (!open) return null;

  return (

    <div className="fixed inset-0 bg-black/40 flex justify-center items-center z-50">

      <div className="bg-white rounded-xl shadow-xl w-full max-w-3xl p-6">

        <h2 className="text-2xl font-bold mb-6">

          {bank ? "Edit Bank" : "Add Bank"}

        </h2>

        <BankForm

          bank={bank}

          onSave={onSave}

          onCancel={onClose}

        />

      </div>

    </div>

  );

}

export default BankDialog;