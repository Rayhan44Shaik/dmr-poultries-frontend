import { useState } from "react";

import DashboardLayout from "../../../../layouts/DashboardLayout/DashboardLayout";

import BankToolbar from "../components/BankToolbar";
import BankTable from "../components/BankTable";
import BankDialog from "../dialogs/BankDialog";

import { useBanks } from "../hooks/useBanks";

function BanksPage() {

  const [showDialog, setShowDialog] = useState(false);

  const [editingBank, setEditingBank] = useState<any>(null);

  const [search, setSearch] = useState("");

  const { banks, saveBanks } = useBanks();

  const filteredBanks = banks.filter((bank)=>{

    const keyword = search.toLowerCase();

    return (

      bank.bankName.toLowerCase().includes(keyword) ||

      bank.branch.toLowerCase().includes(keyword) ||

      bank.ifscCode.toLowerCase().includes(keyword)

    );

  });

  const handleSaveBank=(bank:any)=>{

    const duplicate = banks.some(

      b=>

      b.accountNumber===bank.accountNumber

      &&

      b.id!==editingBank?.id

    );

    if(duplicate){

      alert("Account Number already exists.");

      return;

    }

    if(editingBank){

      saveBanks(

        banks.map(b=>

          b.id===editingBank.id

          ?{

            ...b,

            ...bank

          }

          :b

        )

      );

    }

    else{

      const newBank={

        id:Date.now(),

        bankNo:banks.length+1,

        ...bank

      };

      saveBanks([...banks,newBank]);

    }

    setEditingBank(null);

    setShowDialog(false);

  };

  const handleDelete=(id:number)=>{

    const ok=window.confirm(

      "Delete this Bank?"

    );

    if(!ok) return;

    saveBanks(

      banks.filter(

        b=>b.id!==id

      )

    );

  };

  return(

<DashboardLayout>

<div className="space-y-6">

<div>

<h1 className="text-3xl font-bold">

Banks

</h1>

<p className="text-slate-500">

Manage Company Banks

</p>

</div>

<BankToolbar

search={search}

onSearchChange={setSearch}

onAddBank={()=>{

setEditingBank(null);

setShowDialog(true);

}}

/>

<p className="text-sm text-slate-500">

Showing {filteredBanks.length} of {banks.length} Banks

</p>

<BankTable
  banks={filteredBanks}
  onEdit={(bank) => {
    setEditingBank(bank);
    setShowDialog(true);
  }}
  onDelete={handleDelete}
/>
<BankDialog

open={showDialog}

onClose={()=>{

setEditingBank(null);

setShowDialog(false);

}}

onSave={handleSaveBank}

bank={editingBank}

/>

</div>

</DashboardLayout>

);

}

export default BanksPage;