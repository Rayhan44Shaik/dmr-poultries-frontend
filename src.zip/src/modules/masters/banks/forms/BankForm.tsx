import { useEffect, useState } from "react";
import type { Bank } from "../types/bank";

type BankFormProps = {
  bank?: Bank | null;

  onSave: (bank: {
    bankName: string;
    branch: string;
    accountNumber: string;
    ifscCode: string;
    upiId: string;
    status: "Active" | "Inactive";
  }) => void;

  onCancel: () => void;
};

function BankForm({
  bank,
  onSave,
  onCancel,
}: BankFormProps) {

  const [bankName, setBankName] = useState("");

  const [branch, setBranch] = useState("");

  const [accountNumber, setAccountNumber] = useState("");

  const [ifscCode, setIfscCode] = useState("");

  const [upiId, setUpiId] = useState("");

  const [status, setStatus] =
    useState<"Active" | "Inactive">("Active");

  useEffect(() => {

    if (bank) {

      setBankName(bank.bankName);
      setBranch(bank.branch);
      setAccountNumber(bank.accountNumber);
      setIfscCode(bank.ifscCode);
      setUpiId(bank.upiId);
      setStatus(bank.status);

    } else {

      setBankName("");
      setBranch("");
      setAccountNumber("");
      setIfscCode("");
      setUpiId("");
      setStatus("Active");

    }

  }, [bank]);

  const handleSubmit = () => {

    if (
      !bankName ||
      !branch ||
      !accountNumber ||
      !ifscCode
    ) {

      alert("Please fill all mandatory fields.");

      return;

    }

    onSave({

      bankName,

      branch,

      accountNumber,

      ifscCode: ifscCode.toUpperCase(),

      upiId,

      status,

    });

  };

  return (

    <div className="space-y-5">

      <div>

        <label className="block mb-2 text-sm font-medium text-slate-700">
          <span className="text-red-500">*</span> Bank Name
        </label>

        <input
          value={bankName}
          onChange={(e)=>setBankName(e.target.value)}
          placeholder="Enter Bank Name"
          className="w-full border rounded-lg p-3"
        />

      </div>

      <div>

        <label className="block mb-2 text-sm font-medium text-slate-700">
          <span className="text-red-500">*</span> Branch
        </label>

        <input
          value={branch}
          onChange={(e)=>setBranch(e.target.value)}
          placeholder="Enter Branch Name"
          className="w-full border rounded-lg p-3"
        />

      </div>

      <div>

        <label className="block mb-2 text-sm font-medium text-slate-700">
          <span className="text-red-500">*</span> Account Number
        </label>

        <input
          value={accountNumber}
          onChange={(e)=>
            setAccountNumber(
              e.target.value.replace(/\D/g,"")
            )
          }
          placeholder="Enter Account Number"
          className="w-full border rounded-lg p-3"
        />

      </div>

      <div>

        <label className="block mb-2 text-sm font-medium text-slate-700">
          <span className="text-red-500">*</span> IFSC Code
        </label>

        <input
          value={ifscCode}
          onChange={(e)=>
            setIfscCode(
              e.target.value.toUpperCase()
            )
          }
          placeholder="Enter IFSC Code"
          className="w-full border rounded-lg p-3"
        />

      </div>

      <div>

        <label className="block mb-2 text-sm font-medium text-slate-700">
          UPI ID
        </label>

        <input
          value={upiId}
          onChange={(e)=>setUpiId(e.target.value)}
          placeholder="Enter UPI ID"
          className="w-full border rounded-lg p-3"
        />

      </div>

      <div>

        <label className="block mb-2 text-sm font-medium text-slate-700">
          Bank Status
        </label>

        <select
          value={status}
          onChange={(e)=>
            setStatus(e.target.value as "Active" | "Inactive")
          }
          className="w-full border rounded-lg p-3"
        >
          <option value="Active">Active</option>
          <option value="Inactive">Inactive</option>
        </select>

      </div>

      <div className="flex justify-end gap-3">

        <button
          type="button"
          onClick={onCancel}
          className="px-6 py-2 border rounded-lg"
        >
          Cancel
        </button>

        <button
          type="button"
          onClick={handleSubmit}
          className="px-6 py-2 bg-green-700 hover:bg-green-800 text-white rounded-lg"
        >
          {bank ? "Update Bank" : "Save Bank"}
        </button>

      </div>

    </div>

  );

}

export default BankForm;