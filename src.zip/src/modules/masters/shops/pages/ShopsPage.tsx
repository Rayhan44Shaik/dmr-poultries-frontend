import { useState } from "react";

import DashboardLayout from "../../../../layouts/DashboardLayout/DashboardLayout";

import ShopToolbar from "../components/ShopToolbar";
import ShopTable from "../components/ShopTable";
import ShopDialog from "../dialogs/ShopDialog";

import { useShops } from "../hooks/useShops";

function ShopsPage() {
  const [showDialog, setShowDialog] = useState(false);
  const [editingShop, setEditingShop] = useState<any>(null);
  const [search, setSearch] = useState("");

  const { shops, saveShops } = useShops();

  const filteredShops = shops.filter((shop) => {
    const keyword = search.toLowerCase();

    return (
      shop.shopName.toLowerCase().includes(keyword) ||
      shop.ownerName.toLowerCase().includes(keyword) ||
      shop.village.toLowerCase().includes(keyword) ||
      shop.phoneNumber.includes(keyword)
    );
  });

  const handleSaveShop = (shop: any) => {

    const duplicateShop = shops.some(
      (s) =>
        s.shopName.trim().toLowerCase() ===
          shop.shopName.trim().toLowerCase() &&
        s.id !== editingShop?.id
    );

    if (duplicateShop) {
      alert("Shop Name already exists.");
      return;
    }

    const duplicatePhone = shops.some(
      (s) =>
        s.phoneNumber === shop.phoneNumber &&
        s.id !== editingShop?.id
    );

    if (duplicatePhone) {
      alert("Phone Number already exists.");
      return;
    }

    if (editingShop) {

      saveShops(
        shops.map((s) =>
          s.id === editingShop.id
            ? {
                ...s,
                ...shop,
              }
            : s
        )
      );

    } else {

      const newShop = {
        id: Date.now(),
        shopNo: shops.length + 1,
        ...shop,
      };

      saveShops([...shops, newShop]);

    }

    setEditingShop(null);
    setShowDialog(false);
  };

  const handleEditShop = (shop: any) => {
    setEditingShop(shop);
    setShowDialog(true);
  };

  const handleDeleteShop = (id: number) => {

    const confirmDelete = window.confirm(
      "Are you sure you want to delete this shop?"
    );

    if (!confirmDelete) return;

    saveShops(
      shops.filter((shop) => shop.id !== id)
    );
  };

  return (
    <DashboardLayout>

      <div className="space-y-6">

        <div>

          <h1 className="text-3xl font-bold text-slate-800">
            Shops
          </h1>

          <p className="text-slate-500 mt-1">
            Manage all poultry shops.
          </p>

        </div>

        <ShopToolbar
          search={search}
          onSearchChange={setSearch}
          onAddShop={() => {

            setEditingShop(null);
            setShowDialog(true);

          }}
        />

        <p className="text-sm text-gray-500">
          Showing {filteredShops.length} of {shops.length} Shops
        </p>

        <ShopTable
          shops={filteredShops}
          onEdit={handleEditShop}
          onDelete={handleDeleteShop}
        />

        <ShopDialog
          open={showDialog}
          onClose={() => {

            setEditingShop(null);
            setShowDialog(false);

          }}
          onSave={handleSaveShop}
          shop={editingShop}
        />

      </div>

    </DashboardLayout>
  );
}

export default ShopsPage;