import { Pencil, Trash2 } from "lucide-react";
import type { Shop } from "../types/shop";

type ShopTableProps = {
  shops: Shop[];
  onEdit: (shop: Shop) => void;
  onDelete: (id: number) => void;
};

function ShopTable({
  shops,
  onEdit,
  onDelete,
}: ShopTableProps) {
  return (
    <div className="bg-white rounded-xl shadow-sm overflow-hidden">

      <table className="w-full">

        <thead className="bg-slate-100">
          <tr>
            <th className="px-6 py-4 text-left">Shop No</th>
            <th className="px-6 py-4 text-left">Shop Name</th>
            <th className="px-6 py-4 text-left">Owner</th>
            <th className="px-6 py-4 text-left">Village</th>
            <th className="px-6 py-4 text-left">Phone</th>
            <th className="px-6 py-4 text-center">Status</th>
            <th className="px-6 py-4 text-center">Actions</th>
          </tr>
        </thead>

        <tbody>

          {shops.map((shop) => (

            <tr
              key={shop.id}
              className="border-b hover:bg-slate-50"
            >

              <td className="px-6 py-4">{shop.shopNo}</td>

              <td className="px-6 py-4">{shop.shopName}</td>

              <td className="px-6 py-4">{shop.ownerName}</td>

              <td className="px-6 py-4">{shop.village}</td>

              <td className="px-6 py-4">{shop.phoneNumber}</td>

              <td className="px-6 py-4 text-center">

                <span
                  className={`px-3 py-1 rounded-full ${
                    shop.status === "Active"
                      ? "bg-green-100 text-green-700"
                      : "bg-red-100 text-red-700"
                  }`}
                >
                  {shop.status}
                </span>

              </td>

              <td className="px-6 py-4">

                <div className="flex justify-center gap-4">

                  <button
                    onClick={() => onEdit(shop)}
                    className="text-blue-600 hover:text-blue-800"
                    title="Edit Shop"
                  >
                    <Pencil size={18} />
                  </button>

                  <button
                    onClick={() => onDelete(shop.id)}
                    className="text-red-600 hover:text-red-800"
                    title="Delete Shop"
                  >
                    <Trash2 size={18} />
                  </button>

                </div>

              </td>

            </tr>

          ))}

        </tbody>

      </table>

    </div>
  );
}

export default ShopTable;