import type { Shop } from "../types/shop";

export const initialShops: Shop[] = [
  {
    id: 1,
    shopNo: 1,
    shopName: "Sneha Chicken Center",
    ownerName: "Ruhulla",
    phoneNumber: "9876543210",
    village: "Guntur",
    address: "Main Road",
    status: "Active",
  },

  {
    id: 2,
    shopNo: 2,
    shopName: "Star Chicken",
    ownerName: "Ahmed",
    phoneNumber: "9988776655",
    village: "Tenali",
    address: "Bus Stand",
    status: "Active",
  },

  {
    id: 3,
    shopNo: 3,
    shopName: "Fresh Poultry Mart",
    ownerName: "Ramesh",
    phoneNumber: "9123456789",
    village: "Vijayawada",
    address: "Market",
    status: "Active",
  },

  {
    id: 4,
    shopNo: 4,
    shopName: "Royal Chicken",
    ownerName: "Kareem",
    phoneNumber: "9012345678",
    village: "Narasaraopet",
    address: "Center",
    status: "Inactive",
  },
];