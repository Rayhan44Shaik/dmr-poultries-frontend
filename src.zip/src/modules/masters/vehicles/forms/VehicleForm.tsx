import { useEffect, useState } from "react";
import type { Vehicle } from "../types/vehicle";

type VehicleFormProps = {
  vehicle?: Vehicle | null;

  onSave: (vehicle: {
    vehicleNumber: string;
    vehicleType: string;
    noOfBoxes: number;
    birdCapacity: number;
    capacityKg: number;
    trackingId: string;
    fastagBank: string;
    engineNumber: string;
    chassisNumber: string;
    insuranceExpiry: string;
    permitExpiry: string;
    fitnessExpiry: string;
    status: "Active" | "Inactive";
  }) => void;

  onCancel: () => void;
};

function VehicleForm({
  vehicle,
  onSave,
  onCancel,
}: VehicleFormProps) {

  const [vehicleNumber, setVehicleNumber] = useState("");
  const [vehicleType, setVehicleType] = useState("");

  const [noOfBoxes, setNoOfBoxes] = useState<number | "">("");
  const [birdCapacity, setBirdCapacity] = useState<number | "">("");
  const [capacityKg, setCapacityKg] = useState<number | "">("");

  const [trackingId, setTrackingId] = useState("");
  const [fastagBank, setFastagBank] = useState("");
  const [engineNumber, setEngineNumber] = useState("");
  const [chassisNumber, setChassisNumber] = useState("");

  const [insuranceExpiry, setInsuranceExpiry] = useState("");
  const [permitExpiry, setPermitExpiry] = useState("");
  const [fitnessExpiry, setFitnessExpiry] = useState("");

  const [status, setStatus] =
    useState<"Active" | "Inactive">("Active");

  useEffect(() => {

    if (vehicle) {

      setVehicleNumber(vehicle.vehicleNumber);
      setVehicleType(vehicle.vehicleType);

      setNoOfBoxes(vehicle.noOfBoxes);
      setBirdCapacity(vehicle.birdCapacity);
      setCapacityKg(vehicle.capacityKg);

      setTrackingId(vehicle.trackingId);
      setFastagBank(vehicle.fastagBank);

      setEngineNumber(vehicle.engineNumber);
      setChassisNumber(vehicle.chassisNumber);

      setInsuranceExpiry(vehicle.insuranceExpiry);
      setPermitExpiry(vehicle.permitExpiry);
      setFitnessExpiry(vehicle.fitnessExpiry);

      setStatus(vehicle.status);

    } else {

      setVehicleNumber("");
      setVehicleType("");

      setNoOfBoxes("");
      setBirdCapacity("");
      setCapacityKg("");

      setTrackingId("");
      setFastagBank("");

      setEngineNumber("");
      setChassisNumber("");

      setInsuranceExpiry("");
      setPermitExpiry("");
      setFitnessExpiry("");

      setStatus("Active");

    }

  }, [vehicle]);

  const handleSubmit = () => {

    if (
      !vehicleNumber ||
      noOfBoxes === "" ||
      birdCapacity === "" ||
      !trackingId ||
      !fastagBank ||
      !engineNumber ||
      !chassisNumber
    ) {

      alert("Please fill all mandatory fields.");
      return;

    }

    onSave({

      vehicleNumber,
      vehicleType,

      noOfBoxes: Number(noOfBoxes),
      birdCapacity: Number(birdCapacity),
      capacityKg: Number(capacityKg || 0),

      trackingId,
      fastagBank,

      engineNumber,
      chassisNumber,

      insuranceExpiry,
      permitExpiry,
      fitnessExpiry,

      status,

    });

  };

  return (

    <div className="space-y-5">
      <div className="grid grid-cols-2 gap-5">
              {/* Vehicle Number */}

        <div>
          <label className="block mb-2 text-sm font-medium text-slate-700">
            Vehicle Number <span className="text-red-500">*</span>
          </label>

          <input
            value={vehicleNumber}
            onChange={(e) => setVehicleNumber(e.target.value)}
            placeholder="Enter Vehicle Number"
            className="w-full border rounded-lg p-3"
          />
        </div>

        {/* Vehicle Type */}

        <div>
          <label className="block mb-2 text-sm font-medium text-slate-700">
            Vehicle Type
          </label>

          <input
            value={vehicleType}
            onChange={(e) => setVehicleType(e.target.value)}
            placeholder="Mini Truck / Pickup / Bolero"
            className="w-full border rounded-lg p-3"
          />
        </div>

        {/* No of Boxes */}

        <div>
          <label className="block mb-2 text-sm font-medium text-slate-700">
            No. of Boxes <span className="text-red-500">*</span>
          </label>

          <input
            type="number"
            value={noOfBoxes}
            onChange={(e) =>
              setNoOfBoxes(
                e.target.value === ""
                  ? ""
                  : Number(e.target.value)
              )
            }
            placeholder="Enter Number of Boxes"
            className="w-full border rounded-lg p-3"
          />
        </div>

        {/* Bird Capacity */}

        <div>
          <label className="block mb-2 text-sm font-medium text-slate-700">
            Bird Capacity <span className="text-red-500">*</span>
          </label>

          <input
            type="number"
            value={birdCapacity}
            onChange={(e) =>
              setBirdCapacity(
                e.target.value === ""
                  ? ""
                  : Number(e.target.value)
              )
            }
            placeholder="Enter Bird Capacity"
            className="w-full border rounded-lg p-3"
          />
        </div>

        {/* Capacity */}

        <div>
          <label className="block mb-2 text-sm font-medium text-slate-700">
            Capacity (Kg)
          </label>

          <input
            type="number"
            value={capacityKg}
            onChange={(e) =>
              setCapacityKg(
                e.target.value === ""
                  ? ""
                  : Number(e.target.value)
              )
            }
            placeholder="Enter Capacity in Kg"
            className="w-full border rounded-lg p-3"
          />
        </div>

        {/* Tracking */}

        <div>
          <label className="block mb-2 text-sm font-medium text-slate-700">
            Tracking ID <span className="text-red-500">*</span>
          </label>

          <input
            value={trackingId}
            onChange={(e) => setTrackingId(e.target.value)}
            placeholder="Enter GPS Tracking ID"
            className="w-full border rounded-lg p-3"
          />
        </div>

        {/* Fastag */}

        <div>
          <label className="block mb-2 text-sm font-medium text-slate-700">
            Fastag Bank <span className="text-red-500">*</span>
          </label>

          <input
            value={fastagBank}
            onChange={(e) => setFastagBank(e.target.value)}
            placeholder="HDFC / ICICI / SBI"
            className="w-full border rounded-lg p-3"
          />
        </div>

        {/* Engine */}

        <div>
          <label className="block mb-2 text-sm font-medium text-slate-700">
            Engine Number <span className="text-red-500">*</span>
          </label>

          <input
            value={engineNumber}
            onChange={(e) => setEngineNumber(e.target.value)}
            placeholder="Enter Engine Number"
            className="w-full border rounded-lg p-3"
          />
        </div>

        {/* Chassis */}

        <div>
          <label className="block mb-2 text-sm font-medium text-slate-700">
            Chassis Number <span className="text-red-500">*</span>
          </label>

          <input
            value={chassisNumber}
            onChange={(e) => setChassisNumber(e.target.value)}
            placeholder="Enter Chassis Number"
            className="w-full border rounded-lg p-3"
          />
        </div>

        {/* Insurance */}

        <div>
          <label className="block mb-2 text-sm font-medium text-slate-700">
            Insurance Expiry
          </label>

          <input
            type="date"
            value={insuranceExpiry}
            onChange={(e) => setInsuranceExpiry(e.target.value)}
            className="w-full border rounded-lg p-3"
          />
        </div>

        {/* Permit */}

        <div>
          <label className="block mb-2 text-sm font-medium text-slate-700">
            Permit Expiry
          </label>

          <input
            type="date"
            value={permitExpiry}
            onChange={(e) => setPermitExpiry(e.target.value)}
            className="w-full border rounded-lg p-3"
          />
        </div>

        {/* Fitness */}

        <div>
          <label className="block mb-2 text-sm font-medium text-slate-700">
            Fitness Expiry
          </label>

          <input
            type="date"
            value={fitnessExpiry}
            onChange={(e) => setFitnessExpiry(e.target.value)}
            className="w-full border rounded-lg p-3"
          />
        </div>

      </div>

      <div>
        <label className="block mb-2 text-sm font-medium text-slate-700">
          Vehicle Status
        </label>

        <select
          value={status}
          onChange={(e) =>
            setStatus(e.target.value as "Active" | "Inactive")
          }
          className="w-full border rounded-lg p-3"
        >
          <option value="Active">Active</option>
          <option value="Inactive">Inactive</option>
        </select>
      </div>

      <div className="flex justify-end gap-3 pt-3">

        <button
          onClick={onCancel}
          className="px-6 py-2 border rounded-lg hover:bg-gray-100"
        >
          Cancel
        </button>

        <button
          onClick={handleSubmit}
          className="px-6 py-2 bg-green-700 hover:bg-green-800 text-white rounded-lg"
        >
          {vehicle ? "Update Vehicle" : "Save Vehicle"}
        </button>

      </div>

    </div>

  );

}

export default VehicleForm;