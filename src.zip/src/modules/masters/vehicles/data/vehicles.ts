import type { Vehicle } from "../types/vehicle";

export const initialVehicles: Vehicle[] = [
  {
    id: 1,
    vehicleNo: 1,
    vehicleNumber: "AP39TX1234",
    vehicleType: "Tata Ace",
    noOfBoxes: 120,
    birdCapacity: 1800,
    capacityKg: 2500,
    trackingId: "GPS001",
    fastagBank: "HDFC Bank",
    engineNumber: "ENG123456",
    chassisNumber: "CHS123456",
    insuranceExpiry: "2027-04-20",
    permitExpiry: "2027-03-15",
    fitnessExpiry: "2027-06-10",
    status: "Active",
  },

  {
    id: 2,
    vehicleNo: 2,
    vehicleNumber: "AP07AB4567",
    vehicleType: "Mahindra Bolero Pickup",
    noOfBoxes: 90,
    birdCapacity: 1400,
    capacityKg: 1800,
    trackingId: "GPS002",
    fastagBank: "Union Bank",
    engineNumber: "ENG654321",
    chassisNumber: "CHS654321",
    insuranceExpiry: "2026-12-10",
    permitExpiry: "2026-11-01",
    fitnessExpiry: "2027-01-25",
    status: "Active",
  },
];