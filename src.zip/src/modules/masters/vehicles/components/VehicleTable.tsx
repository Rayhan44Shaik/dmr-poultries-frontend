import { Pencil, Trash2 } from "lucide-react";
import type { Vehicle } from "../types/vehicle";

type VehicleTableProps = {
  vehicles: Vehicle[];
  onEdit: (vehicle: Vehicle) => void;
  onDelete: (id: number) => void;
};

function VehicleTable({
  vehicles,
  onEdit,
  onDelete,
}: VehicleTableProps) {
  return (
    <div className="bg-white rounded-xl shadow-sm overflow-hidden">

      <table className="w-full">

        <thead className="bg-slate-100">

          <tr>

            <th className="px-4 py-3 text-left">No</th>

            <th className="px-4 py-3 text-left">Vehicle Number</th>

            <th className="px-4 py-3 text-left">Type</th>

            <th className="px-4 py-3 text-left">Boxes</th>

            <th className="px-4 py-3 text-left">Bird Capacity</th>

            <th className="px-4 py-3 text-left">Tracking ID</th>

            <th className="px-4 py-3 text-center">Status</th>

            <th className="px-4 py-3 text-center">Actions</th>

          </tr>

        </thead>

        <tbody>

          {vehicles.map((vehicle) => (

            <tr
              key={vehicle.id}
              className="border-b hover:bg-slate-50"
            >

              <td className="px-4 py-3">
                {vehicle.vehicleNo}
              </td>

              <td className="px-4 py-3">
                {vehicle.vehicleNumber}
              </td>

              <td className="px-4 py-3">
                {vehicle.vehicleType}
              </td>

              <td className="px-4 py-3">
                {vehicle.noOfBoxes}
              </td>

              <td className="px-4 py-3">
                {vehicle.birdCapacity}
              </td>

              <td className="px-4 py-3">
                {vehicle.trackingId}
              </td>

              <td className="px-4 py-3 text-center">

                <span
                  className={`px-3 py-1 rounded-full ${
                    vehicle.status === "Active"
                      ? "bg-green-100 text-green-700"
                      : "bg-red-100 text-red-700"
                  }`}
                >
                  {vehicle.status}
                </span>

              </td>

              <td className="px-4 py-3">

                <div className="flex justify-center gap-4">

                  <button
                    onClick={() => onEdit(vehicle)}
                    className="text-blue-600 hover:text-blue-800"
                  >
                    <Pencil size={18} />
                  </button>

                  <button
                    onClick={() => onDelete(vehicle.id)}
                    className="text-red-600 hover:text-red-800"
                  >
                    <Trash2 size={18} />
                  </button>

                </div>

              </td>

            </tr>

          ))}

        </tbody>

      </table>

    </div>
  );
}

export default VehicleTable;