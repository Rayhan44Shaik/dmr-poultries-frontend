import { useState } from "react";

import DashboardLayout from "../../../../layouts/DashboardLayout/DashboardLayout";

import VehicleToolbar from "../components/VehicleToolbar";
import VehicleTable from "../components/VehicleTable";
import VehicleDialog from "../dialogs/VehicleDialog";

import { useVehicles } from "../hooks/useVehicles";

function VehiclesPage() {

  const [showDialog, setShowDialog] = useState(false);

  const [editingVehicle, setEditingVehicle] = useState<any>(null);

  const [search, setSearch] = useState("");

  const { vehicles, saveVehicles } = useVehicles();

  const filteredVehicles = vehicles.filter((vehicle) => {

    const keyword = search.toLowerCase();

    return (

      vehicle.vehicleNumber.toLowerCase().includes(keyword) ||

      vehicle.vehicleType.toLowerCase().includes(keyword) ||

      vehicle.trackingId.toLowerCase().includes(keyword) ||

      vehicle.fastagBank.toLowerCase().includes(keyword)

    );

  });

  const handleSaveVehicle = (vehicle: any) => {

    // Duplicate Vehicle Number

    const duplicateVehicle = vehicles.some(

      (v) =>

        v.vehicleNumber.trim().toLowerCase() ===
          vehicle.vehicleNumber.trim().toLowerCase() &&

        v.id !== editingVehicle?.id

    );

    if (duplicateVehicle) {

      alert("Vehicle Number already exists.");

      return;

    }

    // Duplicate Tracking ID

    const duplicateTracking = vehicles.some(

      (v) =>

        v.trackingId.trim().toLowerCase() ===
          vehicle.trackingId.trim().toLowerCase() &&

        v.id !== editingVehicle?.id

    );

    if (duplicateTracking) {

      alert("Tracking ID already exists.");

      return;

    }

    if (editingVehicle) {

      saveVehicles(

        vehicles.map((v) =>

          v.id === editingVehicle.id

            ? {

                ...v,

                ...vehicle,

              }

            : v

        )

      );

    } else {

      const newVehicle = {

        id: Date.now(),

        vehicleNo: vehicles.length + 1,

        ...vehicle,

      };

      saveVehicles([

        ...vehicles,

        newVehicle,

      ]);

    }

    setEditingVehicle(null);

    setShowDialog(false);

  };

  const handleEditVehicle = (vehicle: any) => {

    setEditingVehicle(vehicle);

    setShowDialog(true);

  };

  const handleDeleteVehicle = (id: number) => {

    const ok = window.confirm(

      "Delete this Vehicle?"

    );

    if (!ok) return;

    saveVehicles(

      vehicles.filter(

        (v) => v.id !== id

      )

    );

  };

  return (

    <DashboardLayout>

      <div className="space-y-6">

        <div>

          <h1 className="text-3xl font-bold text-slate-800">

            Vehicles

          </h1>

          <p className="text-slate-500 mt-1">

            Manage all poultry vehicles.

          </p>

        </div>

        <VehicleToolbar

          search={search}

          onSearchChange={setSearch}

          onAddVehicle={() => {

            setEditingVehicle(null);

            setShowDialog(true);

          }}

        />

        <p className="text-sm text-slate-500">

          Showing {filteredVehicles.length} of {vehicles.length} Vehicles

        </p>

        <VehicleTable

          vehicles={filteredVehicles}

          onEdit={handleEditVehicle}

          onDelete={handleDeleteVehicle}

        />

        <VehicleDialog

          open={showDialog}

          onClose={() => {

            setEditingVehicle(null);

            setShowDialog(false);

          }}

          onSave={handleSaveVehicle}

          vehicle={editingVehicle}

        />

      </div>

    </DashboardLayout>

  );

}

export default VehiclesPage;