import VehicleForm from "../forms/VehicleForm";
import type { Vehicle } from "../types/vehicle";

type VehicleDialogProps = {
  open: boolean;
  onClose: () => void;
  onSave: (vehicle: any) => void;
  vehicle?: Vehicle | null;
};

function VehicleDialog({
  open,
  onClose,
  onSave,
  vehicle,
}: VehicleDialogProps) {

  if (!open) return null;

  return (
    <div className="fixed inset-0 bg-black/40 flex justify-center items-center z-50">

      <div className="bg-white rounded-xl shadow-xl w-full max-w-3xl p-6">

        <h2 className="text-2xl font-bold mb-6">

          {vehicle ? "Edit Vehicle" : "Add Vehicle"}

        </h2>

        <VehicleForm
          vehicle={vehicle}
          onSave={onSave}
          onCancel={onClose}
        />

      </div>

    </div>
  );
}

export default VehicleDialog;