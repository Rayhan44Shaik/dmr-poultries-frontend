import FarmForm from "../forms/FarmForm";
import type { Farm } from "../types/farm";

type FarmDialogProps = {

  open:boolean;

  onClose:()=>void;

  onSave:(farm:any)=>void;

  farm?:Farm|null;

};

function FarmDialog({

  open,

  onClose,

  onSave,

  farm,

}:FarmDialogProps){

if(!open) return null;

return(

<div className="fixed inset-0 bg-black/40 flex justify-center items-center z-50">

<div className="bg-white rounded-xl shadow-xl w-full max-w-xl p-6">

<h2 className="text-2xl font-bold mb-6">

{farm?"Edit Farm":"Add Farm"}

</h2>

<FarmForm

farm={farm}

onSave={onSave}

onCancel={onClose}

/>

</div>

</div>

);

}

export default FarmDialog;