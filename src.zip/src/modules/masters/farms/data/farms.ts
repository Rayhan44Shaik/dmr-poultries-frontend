import type { Farm } from "../types/farm";

export const initialFarms: Farm[] = [
  {
    id: 1,
    farmNo: 1,
    farmName: "Suguna Farm",
    ownerName: "Ramesh",
    supervisorName: "Kumar",
    phoneNumber: "9876543210",
    village: "Tenali",
    address: "Near Bus Stand",
    capacity: 5000,
    status: "Active",
  },

  {
    id: 2,
    farmNo: 2,
    farmName: "Sri Lakshmi Farms",
    ownerName: "Kareem",
    supervisorName: "Rahim",
    phoneNumber: "9988776655",
    village: "Guntur",
    address: "Main Road",
    capacity: 7000,
    status: "Active",
  },

  {
    id: 3,
    farmNo: 3,
    farmName: "Fresh Poultry Farm",
    ownerName: "Ahmed",
    supervisorName: "Sadiq",
    phoneNumber: "9123456789",
    village: "Narasaraopet",
    address: "Near Highway",
    capacity: 4500,
    status: "Inactive",
  },

  {
    id: 4,
    farmNo: 4,
    farmName: "Royal Farms",
    ownerName: "Basha",
    supervisorName: "Ravi",
    phoneNumber: "9012345678",
    village: "Vijayawada",
    address: "Industrial Area",
    capacity: 6500,
    status: "Active",
  },
];