import { Pencil, Trash2 } from "lucide-react";
import type { Farm } from "../types/farm";

type FarmTableProps = {
  farms: Farm[];
  onEdit: (farm: Farm) => void;
  onDelete: (id: number) => void;
};

function FarmTable({
  farms,
  onEdit,
  onDelete,
}: FarmTableProps) {
  return (
    <div className="bg-white rounded-xl shadow-sm overflow-hidden">

      <table className="w-full">

        <thead className="bg-slate-100">

          <tr>

            <th className="px-6 py-4 text-left">Farm No</th>

            <th className="px-6 py-4 text-left">Farm Name</th>

            <th className="px-6 py-4 text-left">Owner</th>

            <th className="px-6 py-4 text-left">Supervisor</th>

            <th className="px-6 py-4 text-left">Village</th>

            <th className="px-6 py-4 text-left">Phone</th>

            <th className="px-6 py-4 text-center">Status</th>

            <th className="px-6 py-4 text-center">Actions</th>

          </tr>

        </thead>

        <tbody>

          {farms.map((farm) => (

            <tr
              key={farm.id}
              className="border-b hover:bg-slate-50"
            >

              <td className="px-6 py-4">{farm.farmNo}</td>

              <td className="px-6 py-4">{farm.farmName}</td>

              <td className="px-6 py-4">{farm.ownerName}</td>

              <td className="px-6 py-4">{farm.supervisorName}</td>

              <td className="px-6 py-4">{farm.village}</td>

              <td className="px-6 py-4">{farm.phoneNumber}</td>

              <td className="px-6 py-4 text-center">

                <span
                  className={`px-3 py-1 rounded-full ${
                    farm.status === "Active"
                      ? "bg-green-100 text-green-700"
                      : "bg-red-100 text-red-700"
                  }`}
                >
                  {farm.status}
                </span>

              </td>

              <td className="px-6 py-4">

                <div className="flex justify-center gap-4">

                  <button
                    onClick={() => onEdit(farm)}
                    className="text-blue-600 hover:text-blue-800"
                  >
                    <Pencil size={18} />
                  </button>

                  <button
                    onClick={() => onDelete(farm.id)}
                    className="text-red-600 hover:text-red-800"
                  >
                    <Trash2 size={18} />
                  </button>

                </div>

              </td>

            </tr>

          ))}

        </tbody>

      </table>

    </div>
  );
}

export default FarmTable;