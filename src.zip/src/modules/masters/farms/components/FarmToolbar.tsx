import { Search, Plus } from "lucide-react";

type FarmToolbarProps = {
  search: string;
  onSearchChange: (value: string) => void;
  onAddFarm: () => void;
};

function FarmToolbar({
  search,
  onSearchChange,
  onAddFarm,
}: FarmToolbarProps) {
  return (
    <div className="flex items-center justify-between mb-6">

      <div className="relative w-96">

        <Search
          size={18}
          className="absolute left-3 top-3 text-gray-400"
        />

        <input
          type="text"
          value={search}
          onChange={(e) =>
            onSearchChange(e.target.value)
          }
          placeholder="Search Farm..."
          className="w-full border rounded-lg pl-10 pr-4 py-2 focus:outline-none focus:ring-2 focus:ring-green-600"
        />

      </div>

      <button
        onClick={onAddFarm}
        className="bg-green-700 hover:bg-green-800 text-white px-5 py-2 rounded-lg flex items-center gap-2"
      >
        <Plus size={18} />
        Add Farm
      </button>

    </div>
  );
}

export default FarmToolbar;