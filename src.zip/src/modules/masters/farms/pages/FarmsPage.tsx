import { useState } from "react";

import DashboardLayout from "../../../../layouts/DashboardLayout/DashboardLayout";

import FarmToolbar from "../components/FarmToolbar";
import FarmTable from "../components/FarmTable";
import FarmDialog from "../dialogs/FarmDialog";

import { useFarms } from "../hooks/useFarms";

function FarmsPage() {

  const [showDialog, setShowDialog] = useState(false);
  const [editingFarm, setEditingFarm] = useState<any>(null);
  const [search, setSearch] = useState("");

  const { farms, saveFarms } = useFarms();

  const filteredFarms = farms.filter((farm) => {

    const keyword = search.toLowerCase();

    return (

      farm.farmName.toLowerCase().includes(keyword) ||

      farm.ownerName.toLowerCase().includes(keyword) ||

      farm.supervisorName.toLowerCase().includes(keyword) ||

      farm.village.toLowerCase().includes(keyword) ||

      farm.phoneNumber.includes(keyword)

    );

  });

  const handleSaveFarm = (farm:any)=>{

    const duplicateFarm = farms.some(

      f=>

      f.farmName.trim().toLowerCase()===farm.farmName.trim().toLowerCase()

      &&

      f.id!==editingFarm?.id

    );

    if(duplicateFarm){

      alert("Farm Name already exists.");

      return;

    }

    const duplicatePhone=farms.some(

      f=>

      f.phoneNumber===farm.phoneNumber

      &&

      f.id!==editingFarm?.id

    );

    if(duplicatePhone){

      alert("Phone Number already exists.");

      return;

    }

    if(editingFarm){

      saveFarms(

        farms.map(f=>

          f.id===editingFarm.id

          ?{

            ...f,

            ...farm

          }

          :f

        )

      );

    }

    else{

      const newFarm={

        id:Date.now(),

        farmNo:farms.length+1,

        ...farm

      };

      saveFarms([...farms,newFarm]);

    }

    setEditingFarm(null);

    setShowDialog(false);

  };

  const handleEditFarm=(farm:any)=>{

    setEditingFarm(farm);

    setShowDialog(true);

  };

  const handleDeleteFarm=(id:number)=>{

    const ok=window.confirm(

      "Delete this Farm?"

    );

    if(!ok) return;

    saveFarms(

      farms.filter(

        f=>f.id!==id

      )

    );

  };

  return(

<DashboardLayout>

<div className="space-y-6">

<div>

<h1 className="text-3xl font-bold">

Farms

</h1>

<p className="text-slate-500">

Manage all Farms

</p>

</div>

<FarmToolbar

search={search}

onSearchChange={setSearch}

onAddFarm={()=>{

setEditingFarm(null);

setShowDialog(true);

}}

/>

<p className="text-sm text-slate-500">

Showing {filteredFarms.length} of {farms.length} Farms

</p>

<FarmTable

farms={filteredFarms}

onEdit={handleEditFarm}

onDelete={handleDeleteFarm}

/>

<FarmDialog

open={showDialog}

onClose={()=>{

setEditingFarm(null);

setShowDialog(false);

}}

onSave={handleSaveFarm}

farm={editingFarm}

/>

</div>

</DashboardLayout>

);

}

export default FarmsPage;