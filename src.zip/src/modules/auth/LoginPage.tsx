import { useNavigate } from "react-router-dom";

function LoginPage() {

  const navigate = useNavigate();

  return (
    <div className="min-h-screen flex items-center justify-center bg-slate-100">

      <div className="bg-white shadow-xl rounded-2xl p-10 w-[450px]">

        <h1 className="text-5xl font-bold text-center text-green-700">
          DMR Poultries
        </h1>

        <p className="text-center text-gray-500 mt-5 text-xl">
          Welcome Back
        </p>

        <button
          onClick={() => navigate("/dashboard")}
          className="mt-10 w-full bg-green-700 hover:bg-green-800 transition text-white text-2xl py-4 rounded-xl"
        >
          Login
        </button>

      </div>

    </div>
  );
}

export default LoginPage;