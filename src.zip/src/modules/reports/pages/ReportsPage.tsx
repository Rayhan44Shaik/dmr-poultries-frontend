function ReportsPage() {
  return (
    <div className="p-8">
      <h1 className="text-3xl font-bold">Reports</h1>
      <p className="text-gray-500 mt-2">
        Reports Module
      </p>
    </div>
  );
}

export default ReportsPage;